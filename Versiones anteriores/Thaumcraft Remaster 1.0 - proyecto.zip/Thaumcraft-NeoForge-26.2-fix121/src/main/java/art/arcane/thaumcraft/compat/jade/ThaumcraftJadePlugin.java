package art.arcane.thaumcraft.compat.jade;

import art.arcane.thaumcraft.Thaumcraft;
import art.arcane.thaumcraft.block.CrucibleBlock;
import art.arcane.thaumcraft.block.EssentiaCentrifugeBlock;
import art.arcane.thaumcraft.block.EssentiaJarBlock;
import art.arcane.thaumcraft.block.EssentiaSmelterBlock;
import art.arcane.thaumcraft.block.EssentiaTubeBlock;
import art.arcane.thaumcraft.block.InfusionMatrixBlock;
import art.arcane.thaumcraft.block.ThaumatoriumBlock;
import art.arcane.thaumcraft.blockentity.CrucibleBlockEntity;
import art.arcane.thaumcraft.blockentity.EssentiaCentrifugeBlockEntity;
import art.arcane.thaumcraft.blockentity.EssentiaJarBlockEntity;
import art.arcane.thaumcraft.blockentity.EssentiaSmelterBlockEntity;
import art.arcane.thaumcraft.blockentity.EssentiaTubeBlockEntity;
import art.arcane.thaumcraft.blockentity.InfusionMatrixBlockEntity;
import art.arcane.thaumcraft.blockentity.ThaumatoriumBlockEntity;
import snownee.jade.api.IWailaClientRegistration;
import snownee.jade.api.IWailaCommonRegistration;
import snownee.jade.api.IWailaPlugin;
import snownee.jade.api.WailaPlugin;

/**
 * Optional Jade integration (only loaded by Jade itself). Each provider can be switched off in Jade's plugin settings
 * (Thaumcraft section).
 */
@WailaPlugin(Thaumcraft.MOD_ID)
public final class ThaumcraftJadePlugin implements IWailaPlugin {
    @Override public void register(IWailaCommonRegistration r) {
        r.registerBlockDataProvider(TcProviders.JAR.server(), EssentiaJarBlockEntity.class);
        r.registerBlockDataProvider(TcProviders.CRUCIBLE.server(), CrucibleBlockEntity.class);
        r.registerBlockDataProvider(TcProviders.INFUSION.server(), InfusionMatrixBlockEntity.class);
        r.registerBlockDataProvider(TcProviders.TUBE.server(), EssentiaTubeBlockEntity.class);
        r.registerBlockDataProvider(TcProviders.CENTRIFUGE.server(), EssentiaCentrifugeBlockEntity.class);
        r.registerBlockDataProvider(TcProviders.SMELTER.server(), EssentiaSmelterBlockEntity.class);
        r.registerBlockDataProvider(TcProviders.THAUMATORIUM.server(), ThaumatoriumBlockEntity.class);
    }

    @Override public void registerClient(IWailaClientRegistration r) {
        r.registerBlockComponent(TcProviders.JAR.client(), EssentiaJarBlock.class);
        r.registerBlockComponent(TcProviders.CRUCIBLE.client(), CrucibleBlock.class);
        r.registerBlockComponent(TcProviders.INFUSION.client(), InfusionMatrixBlock.class);
        r.registerBlockComponent(TcProviders.TUBE.client(), EssentiaTubeBlock.class);
        r.registerBlockComponent(TcProviders.CENTRIFUGE.client(), EssentiaCentrifugeBlock.class);
        r.registerBlockComponent(TcProviders.SMELTER.client(), EssentiaSmelterBlock.class);
        r.registerBlockComponent(TcProviders.THAUMATORIUM.client(), ThaumatoriumBlock.class);
        r.registerEntityComponent(GolemProvider.INSTANCE, art.arcane.thaumcraft.golems.GolemEntity.class);
    }
}
