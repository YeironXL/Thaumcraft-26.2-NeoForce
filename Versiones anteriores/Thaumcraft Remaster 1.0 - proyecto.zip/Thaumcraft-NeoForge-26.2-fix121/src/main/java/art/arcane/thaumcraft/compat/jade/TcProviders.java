package art.arcane.thaumcraft.compat.jade;

import art.arcane.thaumcraft.Thaumcraft;
import art.arcane.thaumcraft.blockentity.CrucibleBlockEntity;
import art.arcane.thaumcraft.blockentity.EssentiaCentrifugeBlockEntity;
import art.arcane.thaumcraft.blockentity.EssentiaJarBlockEntity;
import art.arcane.thaumcraft.blockentity.EssentiaSmelterBlockEntity;
import art.arcane.thaumcraft.blockentity.EssentiaTubeBlockEntity;
import art.arcane.thaumcraft.blockentity.InfusionMatrixBlockEntity;
import art.arcane.thaumcraft.blockentity.ThaumatoriumBlockEntity;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;
import snownee.jade.api.ui.Element;

/**
 * The Thaumcraft Jade providers. Values are gathered on the server (block entities sync little of this to clients) and
 * shown as aspect icons and text lines.
 */
final class TcProviders {
    /** One provider: a server half filling the tag and a client half turning it into lines. */
    record Provider(Identifier uid, BiConsumer<CompoundTag, BlockAccessor> serverFill, Client clientLines) {
        ServerPart server() { return new ServerPart(uid, serverFill); }
        ClientPart client() { return new ClientPart(uid, clientLines); }
    }
    /** Jade requires the data and component providers to be separate objects. */
    record ServerPart(Identifier uid, BiConsumer<CompoundTag, BlockAccessor> fill) implements IServerDataProvider<BlockAccessor> {
        @Override public Identifier getUid() { return uid; }
        @Override public void appendServerData(CompoundTag data, BlockAccessor accessor) { fill.accept(data, accessor); }
    }
    record ClientPart(Identifier uid, Client lines) implements IBlockComponentProvider {
        @Override public Identifier getUid() { return uid; }
        @Override public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) { lines.append(tooltip, accessor.getServerData()); }
    }
    interface Client { void append(ITooltip tooltip, CompoundTag data); }

    private static Identifier id(String path) { return Identifier.fromNamespaceAndPath(Thaumcraft.MOD_ID, path); }

    static void putAspects(CompoundTag data, String key, Map<String, Integer> aspects) {
        var tag = new CompoundTag();
        aspects.forEach((a, n) -> { if (n != null && n > 0) tag.putInt(a, n); });
        data.put(key, tag);
    }

    static Map<String, Integer> aspects(CompoundTag data, String key) {
        var out = new LinkedHashMap<String, Integer>();
        var tag = data.getCompoundOrEmpty(key);
        for (String k : tag.keySet()) out.put(k, tag.getIntOr(k, 0));
        return out;
    }

    /** Aspect icons, eight per line. */
    static void addAspects(ITooltip tooltip, Map<String, Integer> aspects) {
        List<Element> row = new ArrayList<>();
        for (var e : aspects.entrySet()) {
            row.add(new AspectElement(e.getKey(), e.getValue()));
            if (row.size() == 8) { tooltip.add(new ArrayList<>(row)); row.clear(); }
        }
        if (!row.isEmpty()) tooltip.add(row);
    }

    private static Component aspectName(String aspect) {
        return Component.literal(cap(aspect)).withStyle(s -> s.withColor(art.arcane.thaumcraft.aspect.AspectRegistry.color(aspect)));
    }

    static final Provider JAR = new Provider(id("jar"), (data, acc) -> {
        if (!(acc.getBlockEntity() instanceof EssentiaJarBlockEntity jar)) return;
        data.putString("aspect", jar.aspect());
        data.putInt("amount", jar.contents().amount());
        data.putInt("capacity", jar.capacity());
        data.putString("filter", jar.filter());
    }, (tooltip, data) -> {
        String aspect = data.getStringOr("aspect", "");
        int amount = data.getIntOr("amount", 0), cap = data.getIntOr("capacity", 0);
        String filter = data.getStringOr("filter", "");
        if (!aspect.isEmpty() && amount > 0) {
            tooltip.add(new AspectElement(aspect, amount));
            tooltip.append(Component.literal(" ").append(aspectName(aspect)).append(Component.literal("  " + amount + " / " + cap).withStyle(ChatFormatting.GRAY)));
        } else if (data.contains("amount")) tooltip.add(Component.translatable("jade.thaumcraft.empty").withStyle(ChatFormatting.GRAY));
        if (!filter.isEmpty()) tooltip.add(Component.translatable("jade.thaumcraft.label", aspectName(filter)));
    });

    static final Provider CRUCIBLE = new Provider(id("crucible"), (data, acc) -> {
        if (!(acc.getBlockEntity() instanceof CrucibleBlockEntity c)) return;
        var m = c.mixture();
        data.putInt("water", m.water());
        data.putInt("heat", m.heat());
        data.putBoolean("boiling", m.boiling());
        putAspects(data, "aspects", m.aspects());
    }, (tooltip, data) -> {
        if (!data.contains("heat")) return;
        int water = data.getIntOr("water", 0), heat = data.getIntOr("heat", 0);
        if (water <= 0) tooltip.add(Component.translatable("jade.thaumcraft.crucible.dry").withStyle(ChatFormatting.GRAY));
        else if (data.getBooleanOr("boiling", false)) tooltip.add(Component.translatable("jade.thaumcraft.crucible.boiling").withStyle(ChatFormatting.GOLD));
        else tooltip.add(Component.translatable("jade.thaumcraft.crucible.heating", Math.min(100, heat * 100 / 151)).withStyle(ChatFormatting.GRAY));
        var aspects = aspects(data, "aspects");
        if (!aspects.isEmpty()) {
            int total = aspects.values().stream().mapToInt(Integer::intValue).sum();
            tooltip.add(Component.translatable("jade.thaumcraft.crucible.essentia", total).withStyle(total > 500 ? ChatFormatting.RED : ChatFormatting.GRAY));
            addAspects(tooltip, aspects);
        }
    });

    static final Provider INFUSION = new Provider(id("infusion"), (data, acc) -> {
        if (!(acc.getBlockEntity() instanceof InfusionMatrixBlockEntity m)) return;
        data.putBoolean("active", m.active);
        data.putBoolean("crafting", m.crafting);
        data.putFloat("stability", m.stability);
        data.putString("level", m.getStability().name());
        data.putInt("instability", m.recipeInstability());
        data.putInt("items", m.recipeIngredients().size());
        putAspects(data, "essentia", m.recipeEssentia());
    }, (tooltip, data) -> {
        if (!data.contains("active")) return;
        if (!data.getBooleanOr("active", false)) { tooltip.add(Component.translatable("jade.thaumcraft.infusion.inactive").withStyle(ChatFormatting.GRAY)); return; }
        String level = data.getStringOr("level", "STABLE");
        ChatFormatting color = switch (level) { case "VERY_STABLE" -> ChatFormatting.GREEN; case "STABLE" -> ChatFormatting.DARK_GREEN; case "UNSTABLE" -> ChatFormatting.GOLD; default -> ChatFormatting.RED; };
        tooltip.add(Component.translatable("jade.thaumcraft.infusion.stability", Component.translatable("jade.thaumcraft.stability." + level.toLowerCase(java.util.Locale.ROOT)).withStyle(color),
                String.format(java.util.Locale.ROOT, "%.1f", data.getFloatOr("stability", 0))));
        if (data.getBooleanOr("crafting", false)) {
            int inst = Math.min(5, data.getIntOr("instability", 0) / 2);
            // TC6's tc.inst.N strings carry colour codes meant for the light book page (e.g. §1 dark blue); use readable colours on Jade's dark panel.
            ChatFormatting ic = switch (inst) { case 0 -> ChatFormatting.AQUA; case 1 -> ChatFormatting.BLUE; case 2 -> ChatFormatting.LIGHT_PURPLE; case 3 -> ChatFormatting.YELLOW; case 4 -> ChatFormatting.GOLD; default -> ChatFormatting.RED; };
            String instText = ChatFormatting.stripFormatting(net.minecraft.client.resources.language.I18n.get("tc.inst." + inst));
            tooltip.add(Component.translatable("tc.inst").append(Component.literal(instText).withStyle(ic)));
            var essentia = aspects(data, "essentia");
            int items = data.getIntOr("items", 0);
            if (essentia.isEmpty() && items == 0) tooltip.add(Component.translatable("jade.thaumcraft.infusion.finishing").withStyle(ChatFormatting.LIGHT_PURPLE));
            else {
                tooltip.add(Component.translatable("jade.thaumcraft.infusion.remaining", items).withStyle(ChatFormatting.GRAY));
                addAspects(tooltip, essentia);
            }
        }
    });

    static final Provider TUBE = new Provider(id("tube"), (data, acc) -> {
        if (!(acc.getBlockEntity() instanceof EssentiaTubeBlockEntity t)) return;
        putAspects(data, "aspects", t.contents());
        data.putString("filter", t.filter());
        data.putInt("suction", t.suction());
        data.putBoolean("open", t.open());
        data.putString("kind", t.kind().name());
    }, (tooltip, data) -> {
        if (!data.contains("kind")) return;
        var aspects = aspects(data, "aspects");
        if (aspects.isEmpty()) tooltip.add(Component.translatable("jade.thaumcraft.empty").withStyle(ChatFormatting.GRAY));
        else addAspects(tooltip, aspects);
        String filter = data.getStringOr("filter", "");
        if (!filter.isEmpty()) tooltip.add(Component.translatable("jade.thaumcraft.filter", aspectName(filter)));
        if ("VALVE".equals(data.getStringOr("kind", "")) && !data.getBooleanOr("open", true)) tooltip.add(Component.translatable("jade.thaumcraft.tube.closed").withStyle(ChatFormatting.RED));
        int suction = data.getIntOr("suction", 0);
        if (suction > 0) tooltip.add(Component.translatable("jade.thaumcraft.suction", suction).withStyle(ChatFormatting.DARK_GRAY));
    });

    static final Provider CENTRIFUGE = new Provider(id("centrifuge"), (data, acc) -> {
        if (!(acc.getBlockEntity() instanceof EssentiaCentrifugeBlockEntity c)) return;
        data.putString("input", c.input());
        data.putString("output", c.aspect());
        data.putInt("remaining", c.remaining());
        data.putBoolean("paused", c.paused());
    }, (tooltip, data) -> {
        if (!data.contains("input")) return;
        String in = data.getStringOr("input", ""), out = data.getStringOr("output", "");
        if (!in.isEmpty()) {
            tooltip.add(new AspectElement(in, 1));
            tooltip.append(Component.literal(" ").append(Component.translatable("jade.thaumcraft.centrifuge.processing", aspectName(in), 100 - data.getIntOr("remaining", 0) * 100 / 39)));
        }
        if (!out.isEmpty()) {
            tooltip.add(new AspectElement(out, 1));
            tooltip.append(Component.literal(" ").append(Component.translatable("jade.thaumcraft.centrifuge.output", aspectName(out))));
        }
        if (in.isEmpty() && out.isEmpty()) tooltip.add(Component.translatable("jade.thaumcraft.empty").withStyle(ChatFormatting.GRAY));
        if (data.getBooleanOr("paused", false)) tooltip.add(Component.translatable("jade.thaumcraft.paused").withStyle(ChatFormatting.RED));
    });

    static final Provider SMELTER = new Provider(id("smelter"), (data, acc) -> {
        if (!(acc.getBlockEntity() instanceof EssentiaSmelterBlockEntity s)) return;
        data.putInt("total", s.total());
        data.putInt("efficiency", s.efficiencyPercent());
        int dur = s.cookDuration();
        data.putInt("progress", dur > 0 ? Math.min(100, s.cook() * 100 / dur) : 0);
    }, (tooltip, data) -> {
        if (!data.contains("total")) return;
        tooltip.add(Component.translatable("jade.thaumcraft.smelter.essentia", data.getIntOr("total", 0)).withStyle(ChatFormatting.GRAY));
        int p = data.getIntOr("progress", 0);
        if (p > 0) tooltip.add(Component.translatable("jade.thaumcraft.progress", p).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("jade.thaumcraft.smelter.efficiency", data.getIntOr("efficiency", 0)).withStyle(ChatFormatting.DARK_GRAY));
    });

    static final Provider THAUMATORIUM = new Provider(id("thaumatorium"), (data, acc) -> {
        if (!(acc.getBlockEntity() instanceof ThaumatoriumBlockEntity t)) return;
        putAspects(data, "essentia", t.essentia);
    }, (tooltip, data) -> {
        var essentia = aspects(data, "essentia");
        if (!essentia.isEmpty()) addAspects(tooltip, essentia);
    });

    static String cap(String a) { return a.isEmpty() ? a : Character.toUpperCase(a.charAt(0)) + a.substring(1); }

    private TcProviders() {}
}
