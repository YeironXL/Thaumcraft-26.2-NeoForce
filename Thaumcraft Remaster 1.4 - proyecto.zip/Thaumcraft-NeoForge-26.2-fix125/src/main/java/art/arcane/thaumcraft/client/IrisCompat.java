package art.arcane.thaumcraft.client;

import com.mojang.blaze3d.pipeline.RenderPipeline;

/**
 * Iris (optional) only draws render pipelines it knows. Thaumcraft's own pipelines (aura nodes, beams, rifts, its
 * particle layers, golem x-ray) are told which shader-pack program to use, through Iris' public API by reflection
 * so Iris stays an optional dependency. Without this, shader packs drop them ("Missing program ... in override list").
 */
public final class IrisCompat {
    private static boolean done;

    /** Glowing, unlit effects (nodes, beams, rift) go through the beacon-beam program; particles and golems their own. */
    public static void register() {
        if (done || !net.neoforged.fml.ModList.get().isLoaded("iris")) return;
        done = true;
        try {
            Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Class<?> prog = Class.forName("net.irisshaders.iris.api.v0.IrisProgram");
            Object iris = api.getMethod("getInstance").invoke(null);
            var assign = api.getMethod("assignPipeline", RenderPipeline.class, prog);
            Class<?> shadowProg = Class.forName("net.irisshaders.iris.api.v0.IrisShadowProgram");
            var assignShadow = api.getMethod("assignPipelineShadow", RenderPipeline.class, shadowProg);
            @SuppressWarnings({"unchecked", "rawtypes"})
            Object shadowGlow = Enum.valueOf((Class) shadowProg, "SHADOW_LIGHTNING");
            int n = 0;
            for (var e : java.util.Map.of(
                    art.arcane.thaumcraft.client.fx.beam.TcBeams.class, "BEACON_BEAM",
                    art.arcane.thaumcraft.client.render.entity.FluxRiftRenderer.class, "BEACON_BEAM",
                    art.arcane.thaumcraft.client.fx.TcParticleLayers.class, "PARTICLES_TRANSLUCENT",
                    art.arcane.thaumcraft.golems.client.GolemRenderer.class, "ENTITIES_TRANSLUCENT").entrySet()) {
                @SuppressWarnings({"unchecked", "rawtypes"})
                Object program = Enum.valueOf((Class) prog, e.getValue().equals("BEACON_BEAM") ? System.getProperty("thaumcraft.irisGlow", "BEACON_BEAM") : e.getValue());
                for (var f : e.getKey().getDeclaredFields()) {
                    if (f.getType() != RenderPipeline.class || !java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                    f.setAccessible(true);
                    RenderPipeline p = (RenderPipeline) f.get(null);
                    if (p == null || !p.getLocation().getNamespace().equals("thaumcraft")) continue;
                    // shadow pass: glowing effects (beams, nodes, rift) are drawn like lightning there
                    if (e.getValue().equals("BEACON_BEAM")) try { assignShadow.invoke(iris, p, shadowGlow); } catch (java.lang.reflect.InvocationTargetException ignored) {}
                    try { assign.invoke(iris, p, program); n++; }
                    catch (java.lang.reflect.InvocationTargetException already) { /* already matched (pipelines derived from one we assigned) */ }
                }
            }
            System.out.println("[Thaumcraft] Iris: " + n + " render pipelines assigned to shader programs");
        } catch (ReflectiveOperationException | RuntimeException ex) {
            System.out.println("[Thaumcraft] Iris pipeline assignment failed: " + (ex.getCause() != null ? ex.getCause() : ex));
        }
    }

    private static long checkedAt;
    private static boolean depthGlow;
    private static java.lang.reflect.Method packName, inUse;
    private static Object irisApi;

    /**
     * Bliss (a Chocapic13 edit) drops every beacon-program vertex whose colour alpha is below 1 (it only keeps the
     * solid core of vanilla beams), which hides all of Thaumcraft's glows. While a Bliss pack is active the glows are
     * sent opaque with the fade folded into their colour. Re-checked once a second (packs can be switched in game).
     */
    public static boolean depthGlow() {
        long now = System.nanoTime();
        if (now - checkedAt < 1_000_000_000L && checkedAt != 0) return depthGlow;
        checkedAt = now;
        depthGlow = false;
        if (!net.neoforged.fml.ModList.get().isLoaded("iris")) return false;
        try {
            if (packName == null) {
                packName = Class.forName("net.irisshaders.iris.Iris").getMethod("getCurrentPackName");
                Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
                irisApi = api.getMethod("getInstance").invoke(null);
                inUse = api.getMethod("isShaderPackInUse");
            }
            if (!(Boolean) inUse.invoke(irisApi)) return false;
            Object name = packName.invoke(null);
            depthGlow = name != null && name.toString().toLowerCase(java.util.Locale.ROOT).contains("bliss")
                    || Boolean.getBoolean("thaumcraft.depthGlow");
        } catch (ReflectiveOperationException | RuntimeException ex) { depthGlow = false; }
        return depthGlow;
    }

    private static java.lang.reflect.Method shadowPass;
    /** True while a shader pack renders its shadow map: glows must not be drawn there (they would cast square shadows). */
    public static boolean shadowPass() {
        if (!net.neoforged.fml.ModList.get().isLoaded("iris")) return false;
        try {
            if (shadowPass == null) {
                Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
                if (irisApi == null) irisApi = api.getMethod("getInstance").invoke(null);
                shadowPass = api.getMethod("isRenderingShadowPass");
            }
            return (Boolean) shadowPass.invoke(irisApi);
        } catch (ReflectiveOperationException | RuntimeException ex) { return false; }
    }

    private IrisCompat() {}
}
