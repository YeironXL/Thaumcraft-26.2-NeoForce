package art.arcane.thaumcraft.crafting;

import art.arcane.thaumcraft.ModItems;
import art.arcane.thaumcraft.registry.ModRecipes;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

/** TC6 RecipeTripleMeatTreat: one sugar and three different meat chunks, nothing else. */
public final class TripleMeatTreatRecipe extends CustomRecipe {
    public static final TripleMeatTreatRecipe INSTANCE = new TripleMeatTreatRecipe();
    private static Set<Item> chunks() {
        return Set.of(ModItems.CHUNK_BEEF.get(), ModItems.CHUNK_CHICKEN.get(), ModItems.CHUNK_PORK.get(), ModItems.CHUNK_FISH.get(),
                ModItems.CHUNK_RABBIT.get(), ModItems.CHUNK_MUTTON.get());
    }
    @Override public boolean matches(CraftingInput input, Level level) {
        boolean sugar = false;
        Set<Item> meats = new HashSet<>(), kinds = chunks();
        for (int i = 0; i < input.size(); i++) {
            ItemStack s = input.getItem(i);
            if (s.isEmpty()) continue;
            if (s.is(Items.SUGAR)) { if (sugar) return false; sugar = true; }
            else if (kinds.contains(s.getItem())) { if (!meats.add(s.getItem()) || meats.size() > 3) return false; }
            else return false;
        }
        return sugar && meats.size() == 3;
    }
    @Override public ItemStack assemble(CraftingInput input) { return new ItemStack(ModItems.TRIPLE_MEAT_TREAT.get()); }
    @Override public RecipeSerializer<TripleMeatTreatRecipe> getSerializer() { return ModRecipes.TRIPLE_MEAT_TREAT.get(); }
}
