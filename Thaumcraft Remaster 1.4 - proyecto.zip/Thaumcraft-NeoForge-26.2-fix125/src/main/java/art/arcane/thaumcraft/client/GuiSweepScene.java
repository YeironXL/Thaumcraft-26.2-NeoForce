package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.ModBlocks;
import art.arcane.thaumcraft.ModItems;
import art.arcane.thaumcraft.registry.ModEntities;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.common.NeoForge;

import java.io.File;
import java.util.List;
import java.util.function.Supplier;

/**
 * Development aid (-Dthaumcraft.guiSweep=all|name,name...): opens every Thaumcraft screen in turn and saves a screenshot
 * of it at each GUI scale (1, 2, 3, 4 and auto) to screenshots/gui_&lt;name&gt;_&lt;scale&gt;.png, then quits.
 */
public final class GuiSweepScene {
    private static final int[] SCALES = java.util.Arrays.stream(System.getProperty("thaumcraft.guiSweepScales", "1,2,3,4,0").split(",")).mapToInt(Integer::parseInt).toArray();
    private static final List<String> ALL = List.of("arcane_workbench", "research_table", "deconstruction_table", "smelter_basic", "wand_workbench",
            "spa", "potion_sprayer", "void_siphon", "thaumatorium", "golem_builder", "focus_pouch", "hand_mirror", "pech", "turret", "seal",
            "logistics", "book_map", "book_page", "inventory_hud");
    private static int ticks, index = -1, k, wait;
    private static boolean scaled;
    private static List<String> queue;

    public static void register() {
        String arg = System.getProperty("thaumcraft.guiSweep");
        if (arg == null) return;
        queue = arg.equals("all") ? ALL : List.of(arg.split(","));
        NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post e) -> tick(Minecraft.getInstance()));
    }

    /** Per screen: open, wait; then for each scale: set it, wait 8 ticks, save a screenshot. */
    private static void tick(Minecraft mc) {
        if (mc.player == null || mc.getSingleplayerServer() == null) return;
        if (++ticks == 60) prepare(mc);
        if (ticks < 120) return;
        if (wait > 0) { wait--; return; }
        if (index < 0 || k >= SCALES.length) {
            if (index >= 0 && mc.gui.screen() != null) mc.player.closeContainer();
            mc.gui.setScreen(null);
            if (index >= 0 && SCALES[0] != 0 && System.getProperty("thaumcraft.guiSweepScales") != null) { mc.options.guiScale().set(SCALES[0]); mc.resizeGui(); }
            if (++index >= queue.size()) { System.out.println("[GUISWEEP] done"); mc.stop(); return; }
            k = 0; scaled = false;
            open(mc, queue.get(index));
            wait = Integer.getInteger("thaumcraft.guiSweepWait", 40);
            return;
        }
        String name = queue.get(index);
        int s = SCALES[k];
        if (!scaled) {
            mc.options.guiScale().set(s);
            mc.resizeGui();
            scaled = true;
            wait = 8;
            return;
        }
        String tag = s == 0 ? "auto" : String.valueOf(s);
        Screenshot.grab(mc.gameDirectory, "gui_" + name + "_" + (System.getProperty("thaumcraft.guiSweepScales") != null ? k + "-" : "") + tag + ".png", mc.gameRenderer.mainRenderTarget(), 1, msg -> {});
        System.out.println("[GUISWEEP] " + name + " scale=" + tag + " real=" + mc.getWindow().getGuiScale() + " screen="
                + (mc.gui.screen() == null ? "none" : mc.gui.screen().getClass().getSimpleName()) + " window=" + mc.getWindow().getWidth() + "x" + mc.getWindow().getHeight());
        k++; scaled = false;
    }

    private static void server(Minecraft mc, java.util.function.Consumer<ServerPlayer> r) {
        var server = mc.getSingleplayerServer();
        server.execute(() -> { ServerPlayer sp = server.getPlayerList().getPlayer(mc.player.getUUID()); if (sp != null) r.accept(sp); });
    }

    private static final java.util.Map<String, BlockPos> PLACED = new java.util.concurrent.ConcurrentHashMap<>();
    private static final java.util.Map<String, Integer> SPAWNED = new java.util.concurrent.ConcurrentHashMap<>();

    /** Place every block screen's block (and the pech and turret) well before opening them, as a player would. */
    private static void prepare(Minecraft mc) {
        server(mc, sp -> {
            int i = 0;
            for (String name : queue) {
                var b = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getOptional(net.minecraft.resources.Identifier.fromNamespaceAndPath("thaumcraft", name));
                if (b.isEmpty() || b.get() == Blocks.AIR) continue;
                BlockPos pos = sp.blockPosition().offset(-8 + 2 * (i++), 0, 4);
                sp.level().setBlock(pos.below(), Blocks.STONE.defaultBlockState(), 3);
                sp.level().setBlock(pos, b.get().defaultBlockState(), 3);
                PLACED.put(name, pos);
            }
            var pe = ModEntities.PECH.get().create(sp.level(), EntitySpawnReason.COMMAND);
            pe.snapTo(sp.getX() - 3, sp.getY(), sp.getZ() - 3, 180, 0); pe.setNoAi(true); pe.setTamed(true);
            sp.level().addFreshEntity(pe); SPAWNED.put("pech", pe.getId());
            var tu = ModEntities.TURRET_BASIC.get().create(sp.level(), EntitySpawnReason.COMMAND);
            tu.snapTo(sp.getX() + 3, sp.getY(), sp.getZ() - 3, 0, 0); tu.setNoAi(true);
            tu.setValidSpawn(); tu.setOwnerId(sp.getUUID()); tu.setOwned(true);
            sp.level().addFreshEntity(tu); SPAWNED.put("turret", tu.getId());
        });
    }

    private static void open(Minecraft mc, String name) {
        if (name.startsWith("look_")) { // Jade: put the block at eye level two blocks south and look straight at it
            String id = name.substring(5);
            server(mc, sp -> {
                var b = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getValue(net.minecraft.resources.Identifier.fromNamespaceAndPath("thaumcraft", id));
                BlockPos pos = BlockPos.containing(sp.getX(), sp.getEyeY(), sp.getZ() + 2);
                for (int x = -1; x <= 1; x++) for (int y = -1; y <= 3; y++) sp.level().setBlock(pos.offset(x, y, 0), Blocks.AIR.defaultBlockState(), 3);
                sp.level().setBlock(pos, b.defaultBlockState(), 3);
                if (id.equals("condenser")) for (int y = 1; y <= 2; y++) sp.level().setBlock(pos.above(y), ModBlocks.CONDENSER_LATTICE.get().defaultBlockState(), 3);
                if (sp.level().getBlockEntity(pos) instanceof art.arcane.thaumcraft.blockentity.TcBannerBlockEntity tb) tb.setAspect("ignis");
                if (sp.level().getBlockEntity(pos) instanceof art.arcane.thaumcraft.blockentity.BrainJarBlockEntity bj) { bj.xp = 640; bj.sync(); }
            });
            mc.player.setYRot(0); mc.player.setXRot(0);
            return;
        }
        switch (name) {
            case "book_map" -> mc.gui.setScreen(new art.arcane.thaumcraft.client.book.ResearchBrowserScreen());
            case "book_page" -> mc.gui.setScreen(new art.arcane.thaumcraft.client.book.ResearchPageScreen("FIRSTSTEPS", new art.arcane.thaumcraft.client.book.ResearchBrowserScreen()));
            case "research_theory" -> server(mc, sp -> {
                // a theory in progress with cards on the table: the screen's smallest texts
                BlockPos pos = sp.blockPosition().offset(6, 0, 4);
                sp.level().setBlock(pos.below(), Blocks.STONE.defaultBlockState(), 3);
                sp.level().setBlock(pos, ModBlocks.RESEARCH_TABLE.get().defaultBlockState(), 3);
                if (sp.level().getBlockEntity(pos) instanceof net.minecraft.world.Container c) { c.setItem(0, new ItemStack(ModItems.SCRIBING_TOOLS.get())); c.setItem(1, new ItemStack(net.minecraft.world.item.Items.PAPER, 64)); }
                sp.level().getBlockState(pos).useWithoutItem(sp.level(), sp, new BlockHitResult(Vec3.atCenterOf(pos), Direction.NORTH, pos, false));
                if (sp.containerMenu instanceof art.arcane.thaumcraft.menu.ResearchTableMenu m) {
                    boolean a1 = m.clickMenuButton(sp, m.button(0));
                    boolean a2 = m.clickMenuButton(sp, m.button(2));
                    m.broadcastChanges();
                    System.out.println("[GUISWEEP] theory start=" + a1 + " draw=" + a2);
                }
            });
            case "inventory_hud" -> {
                // in-game HUD: caster (vis dial), harness gauge, warp; no screen
                server(mc, sp -> {
                    sp.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.CASTER_BASIC.get()));
                    sp.setItemSlot(net.minecraft.world.entity.EquipmentSlot.CHEST, new ItemStack(ModItems.HOVER_HARNESS.get()));
                });
            }
            case "focus_pouch" -> server(mc, sp -> { sp.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.FOCUS_POUCH.get())); sp.getMainHandItem().use(sp.level(), sp, InteractionHand.MAIN_HAND); });
            case "hand_mirror" -> server(mc, sp -> sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new art.arcane.thaumcraft.menu.HandMirrorMenu(id, inv), Component.translatable("item.thaumcraft.hand_mirror"))));
            case "logistics" -> server(mc, sp -> art.arcane.thaumcraft.golems.logistics.LogisticsMenu.open(sp, null, null));
            case "seal" -> server(mc, sp -> {
                BlockPos pos = sp.blockPosition().offset(0, -1, 3);
                art.arcane.thaumcraft.golems.seals.SealHandler.addSealEntity(sp.level(), pos, Direction.UP, new art.arcane.thaumcraft.golems.seals.SealPickup(), sp);
                var se = art.arcane.thaumcraft.golems.seals.SealHandler.getSealEntity(sp.level(), new art.arcane.thaumcraft.golems.seals.SealPos(pos, Direction.UP));
                if (se != null) art.arcane.thaumcraft.golems.seals.SealMenu.open(sp, se);
                else System.out.println("[GUISWEEP] seal not placed");
            });
            case "pech" -> server(mc, sp -> {
                var pe = sp.level().getEntity(SPAWNED.get("pech"));
                if (pe != null) sp.interactOn(pe, InteractionHand.MAIN_HAND, pe.position());
            });
            case "turret" -> server(mc, sp -> {
                var tu = sp.level().getEntity(SPAWNED.get("turret"));
                System.out.println("[GUISWEEP] turret " + tu);
                if (tu != null) sp.interactOn(tu, InteractionHand.MAIN_HAND, tu.position());
            });
            default -> server(mc, sp -> {
                BlockPos pos = PLACED.get(name);
                if (pos == null) { System.out.println("[GUISWEEP] nothing placed for " + name); return; }
                var r = sp.level().getBlockState(pos).useWithoutItem(sp.level(), sp, new BlockHitResult(Vec3.atCenterOf(pos), Direction.NORTH, pos, false));
                System.out.println("[GUISWEEP] use " + name + " -> " + r);
            });
        }
    }
    private GuiSweepScene() {}
}
