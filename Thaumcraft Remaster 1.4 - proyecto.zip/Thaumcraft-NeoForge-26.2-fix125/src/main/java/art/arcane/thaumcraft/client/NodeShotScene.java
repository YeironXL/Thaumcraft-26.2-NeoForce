package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.aura.node.AuraNodeGen;
import art.arcane.thaumcraft.aura.node.NodeType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.common.NeoForge;

/** Development aid (-Dthaumcraft.nodeShot=tag): a row of aura nodes of every type, screenshot by day and by night. */
public final class NodeShotScene {
    private static int ticks;
    private static BlockPos base;

    public static void register() {
        if (System.getProperty("thaumcraft.nodeShot") == null) return;
        NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post e) -> tick(Minecraft.getInstance()));
    }

    private static void cmd(Minecraft mc, String c) {
        var s = mc.getSingleplayerServer();
        s.execute(() -> s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withSuppressedOutput(), c));
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null || mc.getSingleplayerServer() == null) return;
        ticks++;
        String tag = System.getProperty("thaumcraft.nodeShot");
        if (ticks == 60) { // a fresh spot per run so earlier runs leave nothing in the picture
            var s = mc.getSingleplayerServer();
            int h = Math.floorMod(tag.hashCode(), 200);
            s.execute(() -> { var p = s.getPlayerList().getPlayers().getFirst(); p.setGameMode(GameType.SPECTATOR);
                p.teleportTo(s.overworld(), 50000 + h * 64, 160, 50000, java.util.Set.of(), 0, 8, true); });
        }
        if (ticks == 200) {
            if (!mc.gui.hud.isHidden()) mc.gui.hud.toggle();
            var s = mc.getSingleplayerServer();
            s.execute(() -> {
                var l = s.overworld();
                var p = s.getPlayerList().getPlayers().getFirst();
                base = new BlockPos(p.getBlockX(), 150, p.getBlockZ());
                for (int x = -10; x <= 6; x++) for (int z = 0; z <= 8; z++) for (int y = -1; y <= 6; y++)
                    l.setBlock(base.offset(x, y, z), y == -1 ? Blocks.GRASS_BLOCK.defaultBlockState() : Blocks.AIR.defaultBlockState(), 2);
                NodeType[] types = NodeType.values();
                for (int i = 0; i < types.length; i++)
                    AuraNodeGen.place(l, base.offset(-5 + i * 2, 2, 5), types[i], null, RandomSource.create(i), false);
                // a vanilla beacon beside the row, to compare with how the pack draws real beacon beams
                for (int bx = -1; bx <= 1; bx++) for (int bz = -1; bz <= 1; bz++) l.setBlock(base.offset(bx - 8, -1, bz + 5), Blocks.IRON_BLOCK.defaultBlockState(), 2);
                for (int bx = -1; bx <= 1; bx++) for (int bz = -1; bz <= 1; bz++) l.setBlock(base.offset(bx - 8, 0, bz + 5), Blocks.AIR.defaultBlockState(), 2);
                l.setBlock(base.offset(-8, 0, 5), Blocks.BEACON.defaultBlockState(), 2);
                var rift = new art.arcane.thaumcraft.entity.FluxRiftEntity(art.arcane.thaumcraft.registry.ModEntities.FLUX_RIFT.get(), l);
                rift.snapTo(base.getX() + 0.5, base.getY() + 4.5, base.getZ() + 8.5, 0, 0);
                rift.setRiftSeed(7); rift.setRiftSize(40); rift.setRiftStability(100);
                l.addFreshEntity(rift);
                p.teleportTo(l, base.getX() + 0.5, base.getY() + 2.5, base.getZ() - 3.5, java.util.Set.of(), 0, 8, true);
            });
            cmd(mc, "gamerule advance_time false");
            cmd(mc, "time set noon"); cmd(mc, "weather clear");
        }
        if (ticks == 500) Screenshot.grab(mc.gameDirectory, "nodes_" + tag + "_day.png", mc.gameRenderer.mainRenderTarget(), 1, m -> {});
        if (ticks == 510) cmd(mc, "time set midnight");
        if (ticks == 700) Screenshot.grab(mc.gameDirectory, "nodes_" + tag + "_night.png", mc.gameRenderer.mainRenderTarget(), 1, m -> {});
        if (ticks == 720) { System.out.println("[NODESHOT] done"); mc.stop(); }
    }

    private NodeShotScene() {}
}
