package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.worldgen.BarrowDenGen;
import art.arcane.thaumcraft.worldgen.EldritchObeliskGen;
import art.arcane.thaumcraft.worldgen.SinisterShrinesGen;
import art.arcane.thaumcraft.worldgen.StructuresV2;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.common.NeoForge;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

/**
 * Development aid (-Dthaumcraft.structPreview=1): finds a fitting biome for each structure, builds it twice on the
 * real terrain - original on the left (west), improved version on the right (east) - and screenshots the pair from
 * the front, from above, from the side, then each one cut open.
 */
public final class StructPreviewScene {
    private record Shot(String name, double x, double y, double z, float yaw, float pitch) {}
    private record Site(String id, int sep, Predicate<Holder<Biome>> biome) {}
    private static final List<Site> SITES = List.of(
            new Site("barrow", 16, BarrowDenGen::biome),
            new Site("altar", 9, b -> b.is(Biomes.DARK_FOREST)),
            new Site("sinister", 10, b -> b.is(Biomes.SWAMP)),
            new Site("eldritch", 13, b -> b.is("site".equals(System.getProperty("thaumcraft.structPreview")) ? Biomes.FOREST : Biomes.PLAINS)));
    private static final boolean SITE = "site".equals(System.getProperty("thaumcraft.structPreview"));
    private static int ticks, site = -1, wait;
    private static BlockPos centre, origin;
    private static final List<Runnable> plan = new ArrayList<>();

    public static void register() {
        if (System.getProperty("thaumcraft.structPreview") == null) return;
        NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post e) -> tick(Minecraft.getInstance()));
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null || mc.getSingleplayerServer() == null) return;
        if (++ticks < 80) return;
        if (origin == null) origin = mc.player.blockPosition();
        if (wait > 0) { wait--; return; }
        if (plan.isEmpty()) {
            if (++site >= SITES.size()) { System.out.println("[STRUCT] done"); mc.stop(); return; }
            schedule(mc, SITES.get(site));
        }
        plan.removeFirst().run();
    }

    private static void server(Minecraft mc, java.util.function.Consumer<ServerLevel> r) {
        var s = mc.getSingleplayerServer();
        s.execute(() -> r.accept(s.overworld()));
    }

    private static void tp(ServerLevel l, double x, double y, double z, float yaw, float pitch) {
        l.getServer().getPlayerList().getPlayers().forEach(p -> p.teleportTo(l, x, y, z, java.util.Set.of(), yaw, pitch, true));
    }

    private static void cmd(ServerLevel l, String c) {
        l.getServer().getCommands().performPrefixedCommand(l.getServer().createCommandSourceStack().withSuppressedOutput(), c);
    }

    private static void schedule(Minecraft mc, Site s) {
        if (!mc.gui.hud.isHidden()) mc.gui.hud.toggle();
        // 1. find the biome and go there so the chunks load
        plan.add(() -> { server(mc, l -> {
            cmd(l, "time set noon"); cmd(l, "weather clear"); cmd(l, "gamerule advance_time false");
            l.getServer().getPlayerList().getPlayers().forEach(p -> { p.setGameMode(GameType.SPECTATOR); p.getInventory().clearContent(); });
            var found = l.findClosestBiome3d(s.biome(), origin.offset(30000 + site * 1500, 0, 30000), 6400, 32, 64);
            BlockPos at = found == null ? origin.offset(30000 + site * 1500, 0, 30000) : found.getFirst();
            centre = new BlockPos(at.getX(), 100, at.getZ());
            System.out.println("[STRUCT] " + s.id() + " biome at " + at);
            tp(l, at.getX(), 160, at.getZ(), 0, 90);
        }); wait = 160; });
        // 2. pick the flattest dry spot nearby, then build original (west) and improved (east)
        plan.add(() -> { server(mc, l -> {
            if (SITE) { // real generator path: the site finder picks the spot, only the new structure is built
                int[] p = switch (s.id()) { case "barrow" -> new int[]{BarrowDenGen.RADIUS, 3, 0}; case "sinister" -> new int[]{4, 2, 2}; case "eldritch" -> new int[]{5, 2, 0}; default -> new int[]{4, 2, 0}; };
                BlockPos found = null;
                outer:
                for (int r = 0; r <= 64; r += 8) for (int i = -r; i <= r; i += 8) for (int j = -r; j <= r; j += 8) {
                    if (Math.max(Math.abs(i), Math.abs(j)) != r) continue;
                    BlockPos t = StructuresV2.site(l, centre.getX() + i, centre.getZ() + j, p[0], p[1], p[2]);
                    if (t != null && s.biome().test(l.getBiome(t))) { found = t; break outer; }
                }
                if (found == null) { System.out.println("[STRUCT] " + s.id() + " no valid site"); found = StructuresV2.ground(l, centre.getX(), centre.getZ()); }
                centre = found;
                Random rr = new Random(1234L);
                switch (s.id()) {
                    case "barrow" -> StructuresV2.barrowDen(l, rr, found, false);
                    case "altar" -> StructuresV2.wispAltar(l, rr, found);
                    case "sinister" -> StructuresV2.obelisk(l, rr, found, true);
                    default -> StructuresV2.eldritchObelisk(l, rr, found);
                }
                System.out.println("[STRUCT] " + s.id() + " site " + found);
                return;
            }
            BlockPos best = centre; int bestScore = Integer.MAX_VALUE;
            for (int i = -2; i <= 2; i++) for (int j = -2; j <= 2; j++) {
                int x = centre.getX() + i * 20, z = centre.getZ() + j * 20;
                int lo = 999, hi = -999; boolean wet = false;
                for (int dx = -s.sep() - 8; dx <= s.sep() + 8; dx += 4) for (int dz = -8; dz <= 8; dz += 4) {
                    BlockPos g = ground(l, x + dx, z + dz);
                    lo = Math.min(lo, g.getY()); hi = Math.max(hi, g.getY());
                    if (!l.getFluidState(g.above()).isEmpty() || !l.getFluidState(g).isEmpty()) wet = true;
                }
                int score = (hi - lo) + (wet ? 6 : 0) + (s.biome().test(l.getBiome(new BlockPos(x, hi, z))) ? 0 : 20);
                if (score < bestScore) { bestScore = score; best = new BlockPos(x, hi, z); }
            }
            centre = ground(l, best.getX(), best.getZ());
            BlockPos a = ground(l, centre.getX() - s.sep(), centre.getZ()), b = ground(l, centre.getX() + s.sep(), centre.getZ());
            // clear trees around both spots (same for both) so the camera can see them
            for (int x = -s.sep() - 12; x <= s.sep() + 12; x++) for (int z = -14; z <= 14; z++) for (int y = -2; y <= 30; y++) {
                BlockPos q = centre.offset(x, y, z); var st = l.getBlockState(q);
                if (st.is(net.minecraft.tags.BlockTags.LOGS) || st.is(net.minecraft.tags.BlockTags.LEAVES) || st.is(Blocks.RED_MUSHROOM_BLOCK) || st.is(Blocks.BROWN_MUSHROOM_BLOCK) || st.is(Blocks.MUSHROOM_STEM))
                    l.setBlock(q, Blocks.AIR.defaultBlockState(), 2);
            }
            a = ground(l, a.getX(), a.getZ()); b = ground(l, b.getX(), b.getZ());
            long seed = 1234L;
            switch (s.id()) {
                case "barrow" -> { BarrowDenGen.build(l, new Random(seed), a); StructuresV2.barrowDen(l, new Random(seed), b, l.getBiome(b).is(net.minecraft.tags.BiomeTags.IS_SAVANNA)); }
                case "altar" -> { SinisterShrinesGen.wispAltar(l, new Random(seed), a); StructuresV2.wispAltar(l, new Random(seed), b); }
                case "sinister" -> { SinisterShrinesGen.obelisk(l, new Random(seed), a); StructuresV2.obelisk(l, new Random(seed), b, true); }
                default -> { System.setProperty("thaumcraft.originalStructures","true"); EldritchObeliskGen.generate(l, new Random(seed), a); System.clearProperty("thaumcraft.originalStructures"); StructuresV2.eldritchObelisk(l, new Random(seed), b); }
            }
            System.out.println("[STRUCT] " + s.id() + " built at " + a + " / " + b + " (score " + bestScore + ")");
        }); wait = 60; });
        double d = SITE ? s.sep() + 8 : s.sep() * 1.35 + 7;
        shoot(mc, s, () -> new Shot("1_frente", centre.getX() + 0.5, centre.getY() + d * 0.42, centre.getZ() + d, 180, 22));
        shoot(mc, s, () -> new Shot("2_arriba", centre.getX() + 0.5, centre.getY() + d * 1.05, centre.getZ() + d * 0.45, 180, 62));
        shoot(mc, s, () -> new Shot("3_lado", centre.getX() + d * 0.8, centre.getY() + d * 0.3, centre.getZ() + d * 0.75, 135, 16));
        // 3. cut both open (south half removed) and look at each one from inside the cut
        if (!SITE && !s.id().equals("eldritch")) {
            plan.add(() -> { server(mc, l -> {
                for (int x = -s.sep() - 13; x <= s.sep() + 13; x++) for (int z = 1; z <= 16; z++) for (int y = -9; y <= 18; y++)
                    l.setBlock(centre.offset(x, y, z), Blocks.AIR.defaultBlockState(), 2);
            }); wait = 40; });
            int dist = s.id().equals("barrow") ? 15 : 9;
            float pitch = s.id().equals("barrow") ? 8 : 18;
            double eye = s.id().equals("barrow") ? -1 : 3;
            shoot(mc, s, () -> new Shot("4_corte_original", centre.getX() - s.sep() + 0.5, centre.getY() + eye, centre.getZ() + dist, 180, pitch));
            shoot(mc, s, () -> new Shot("5_corte_mejorado", centre.getX() + s.sep() + 0.5, centre.getY() + eye, centre.getZ() + dist, 180, pitch));
        }
    }

    private static BlockPos ground(ServerLevel l, int x, int z) {
        return new BlockPos(x, l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1, z);
    }

    private static void shoot(Minecraft mc, Site s, java.util.function.Supplier<Shot> shot) {
        String[] name = new String[1];
        plan.add(() -> { Shot sh = shot.get(); name[0] = sh.name(); server(mc, l -> tp(l, sh.x(), sh.y(), sh.z(), sh.yaw(), sh.pitch())); wait = 220; });
        plan.add(() -> {
            Screenshot.grab(mc.gameDirectory, "struct_" + (site + 1) + "_" + s.id() + "_" + name[0] + ".png", mc.gameRenderer.mainRenderTarget(), 1, m -> {});
            System.out.println("[STRUCT] shot " + s.id() + " " + name[0]);
            wait = 10;
        });
    }

    private StructPreviewScene() {}
}
