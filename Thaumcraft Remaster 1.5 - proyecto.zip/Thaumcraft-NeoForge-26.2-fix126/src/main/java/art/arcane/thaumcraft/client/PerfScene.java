package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.ModBlocks;
import art.arcane.thaumcraft.aura.node.AuraNodeGen;
import art.arcane.thaumcraft.aura.node.NodeType;
import art.arcane.thaumcraft.block.EssentiaTubeBlock;
import art.arcane.thaumcraft.blockentity.EssentiaJarBlockEntity;
import art.arcane.thaumcraft.registry.ModEntities;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Development aid (-Dthaumcraft.perfTest=1): measures the server tick time of an empty platform and of the same
 * platform with many nodes, essentia tubes moving essentia, Thaumcraft golems and (for comparison) vanilla iron golems.
 */
public final class PerfScene {
    private record Scenario(String name, Consumer<ServerLevel> build) {}
    private static final int WARMUP = 200, MEASURE = 600;
    private static BlockPos base;
    private static int ticks, scenario = -1, phase, phaseTicks;
    private static long tickStart, sum, max;
    private static int samples;
    private static final List<String> results = new ArrayList<>();
    private static final List<EssentiaJarBlockEntity> sources = new ArrayList<>();

    public static void register() {
        if (System.getProperty("thaumcraft.perfTest") == null) return;
        NeoForge.EVENT_BUS.addListener((ServerTickEvent.Pre e) -> tickStart = System.nanoTime());
        NeoForge.EVENT_BUS.addListener((ServerTickEvent.Post e) -> {
            if (phase != 2) return;
            long t = System.nanoTime() - tickStart;
            sum += t; max = Math.max(max, t); samples++;
        });
        NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post e) -> tick(Minecraft.getInstance()));
    }

    private static final List<Scenario> SCENARIOS = List.of(
            new Scenario("base (plataforma vacia)", l -> {}),
            new Scenario("400 nodos de aura", l -> {
                for (int i = 0; i < 20; i++) for (int j = 0; j < 20; j++)
                    AuraNodeGen.place(l, base.offset(-30 + i * 3, 3, -30 + j * 3), NodeType.NORMAL, null, RandomSource.create(i * 31 + j), false);
            }),
            new Scenario("1200 tubos con esencia (100 lineas)", l -> {
                sources.clear();
                for (int i = 0; i < 10; i++) for (int j = 0; j < 10; j++) {
                    BlockPos b = base.offset(-30 + i * 6, 0, -30 + j * 6);
                    l.setBlock(b, ModBlocks.ALEMBIC.get().defaultBlockState(), 3);
                    if (l.getBlockEntity(b) instanceof EssentiaJarBlockEntity a) { a.insert("ignis", 32); sources.add(a); }
                    var tube = ModBlocks.TUBE.get().defaultBlockState().setValue(EssentiaTubeBlock.FACING, Direction.UP);
                    for (int y = 1; y <= 10; y++) l.setBlock(b.above(y), tube, 3);      // up from the alembic
                    l.setBlock(b.offset(1, 10, 0), tube, 3);                              // across
                    l.setBlock(b.offset(1, 9, 0), tube, 3);                               // down onto the jar's lid
                    l.setBlock(b.offset(1, 8, 0), ModBlocks.JAR_NORMAL.get().defaultBlockState(), 3);
                }
            }),
            new Scenario("100 golems de Thaumcraft", l -> {
                for (int i = 0; i < 10; i++) for (int j = 0; j < 10; j++) {
                    var g = ModEntities.GOLEM.get().create(l, EntitySpawnReason.SPAWN_ITEM_USE);
                    g.snapTo(base.getX() - 30 + i * 6 + 0.5, base.getY(), base.getZ() - 30 + j * 6 + 0.5, 0, 0);
                    g.setOwned(true); g.setValidSpawn(); g.initialSpawn();
                    l.addFreshEntity(g);
                }
            }),
            new Scenario("100 golems de hierro (vanilla, referencia)", l -> {
                for (int i = 0; i < 10; i++) for (int j = 0; j < 10; j++) {
                    var g = EntityTypes.IRON_GOLEM.create(l, EntitySpawnReason.COMMAND);
                    g.snapTo(base.getX() - 30 + i * 6 + 0.5, base.getY(), base.getZ() - 30 + j * 6 + 0.5, 0, 0);
                    l.addFreshEntity(g);
                }
            }));

    private static void server(Minecraft mc, Consumer<ServerLevel> r) {
        var s = mc.getSingleplayerServer();
        s.execute(() -> r.accept(s.overworld()));
    }

    private static void clear(ServerLevel l) {
        l.getEntitiesOfClass(Entity.class, new AABB(base).inflate(48), en -> !(en instanceof net.minecraft.server.level.ServerPlayer)).forEach(Entity::discard);
        for (int x = -34; x <= 34; x++) for (int z = -34; z <= 34; z++) {
            for (int y = 0; y <= 15; y++) l.setBlock(base.offset(x, y, z), Blocks.AIR.defaultBlockState(), 2);
            l.setBlock(base.offset(x, -1, z), Blocks.STONE.defaultBlockState(), 2);
        }
        // a low wall keeps the golems on the platform
        for (int x = -34; x <= 34; x++) for (int z = -34; z <= 34; z++)
            if (Math.abs(x) == 34 || Math.abs(z) == 34) for (int y = 0; y <= 2; y++) l.setBlock(base.offset(x, y, z), Blocks.STONE.defaultBlockState(), 2);
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null || mc.getSingleplayerServer() == null) return;
        ticks++;
        if (ticks == 60) server(mc, l -> {
            var p = l.getServer().getPlayerList().getPlayers().getFirst();
            p.setGameMode(GameType.SPECTATOR);
            base = new BlockPos(5000, 120, 5000);
            p.teleportTo(l, 5000.5, 140, 4970.5, java.util.Set.of(), 0, 30, true);
            l.getServer().getCommands().performPrefixedCommand(l.getServer().createCommandSourceStack().withSuppressedOutput(), "gamerule spawn_mobs false");
        });
        if (ticks < 240) return;
        if (phase == 0) { // build the next scenario
            if (++scenario >= SCENARIOS.size()) {
                System.out.println("[PERF] ===== resultados =====");
                results.forEach(r -> System.out.println("[PERF] " + r));
                mc.stop(); phase = 9; return;
            }
            Scenario sc = SCENARIOS.get(scenario);
            server(mc, l -> { clear(l); sc.build().accept(l); });
            phase = 1; phaseTicks = 0; return;
        }
        if (phase == 1 && ++phaseTicks >= WARMUP) { phase = 2; phaseTicks = 0; sum = 0; max = 0; samples = 0; return; }
        if (phase == 2) {
            // keep the tube columns supplied so essentia keeps flowing during the measurement
            if (phaseTicks % 100 == 0 && !sources.isEmpty()) server(mc, l -> sources.forEach(a -> a.insert("ignis", 16)));
            if (++phaseTicks >= MEASURE) {
                String r = String.format("%-45s media %.2f ms/tick, peor %.2f ms (%d ticks)", SCENARIOS.get(scenario).name(), sum / 1e6 / Math.max(1, samples), max / 1e6, samples);
                results.add(r); System.out.println("[PERF] " + r);
                if (SCENARIOS.get(scenario).name().startsWith("1200")) server(mc, l -> {
                    int full = 0; for (int i = 0; i < 10; i++) for (int j = 0; j < 10; j++)
                        if (l.getBlockEntity(base.offset(-30 + i * 6 + 1, 8, -30 + j * 6)) instanceof EssentiaJarBlockEntity jar && jar.contents().amount() > 0) full++;
                    System.out.println("[PERF] frascos que recibieron esencia: " + full + "/100");
                });
                sources.clear();
                phase = 0;
            }
        }
    }

    private PerfScene() {}
}
