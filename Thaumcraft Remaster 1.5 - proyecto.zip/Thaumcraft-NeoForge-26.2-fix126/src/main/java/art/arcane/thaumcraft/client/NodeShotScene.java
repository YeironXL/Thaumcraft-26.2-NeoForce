package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.aura.node.AuraNodeGen;
import art.arcane.thaumcraft.aura.node.NodeType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.common.NeoForge;

/** Development aid (-Dthaumcraft.nodeShot=tag): a row of aura nodes of every type, screenshot by day and by night. */
public final class NodeShotScene {
    private static int ticks;
    private static BlockPos base;

    public static void register() {
        if (System.getProperty("thaumcraft.nodeShot") == null) return;
        NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post e) -> tick(Minecraft.getInstance()));
    }

    private static void cmd(Minecraft mc, String c) {
        var s = mc.getSingleplayerServer();
        s.execute(() -> s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withSuppressedOutput(), c));
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null || mc.getSingleplayerServer() == null) return;
        ticks++;
        String tag = System.getProperty("thaumcraft.nodeShot");
        if (ticks == 60) { // a fresh spot per run so earlier runs leave nothing in the picture
            var s = mc.getSingleplayerServer();
            int h = Math.floorMod(tag.hashCode(), 200);
            s.execute(() -> { var p = s.getPlayerList().getPlayers().getFirst(); p.setGameMode(GameType.SPECTATOR);
                p.teleportTo(s.overworld(), 50000 + h * 64, 160, 50000, java.util.Set.of(), 0, 8, true); });
        }
        if (tag.startsWith("crystal")) { crystals(mc); return; }
        if (tag.startsWith("trims")) { trims(mc); return; }
        if (tag.startsWith("fx") && ticks > 250 && base != null) effects(mc);
        if (ticks == 200) {
            if (!mc.gui.hud.isHidden()) mc.gui.hud.toggle();
            var s = mc.getSingleplayerServer();
            s.execute(() -> {
                var l = s.overworld();
                var p = s.getPlayerList().getPlayers().getFirst();
                base = new BlockPos(p.getBlockX(), 150, p.getBlockZ());
                for (int x = -10; x <= 6; x++) for (int z = 0; z <= 8; z++) for (int y = -1; y <= 6; y++)
                    l.setBlock(base.offset(x, y, z), y == -1 ? Blocks.GRASS_BLOCK.defaultBlockState() : Blocks.AIR.defaultBlockState(), 2);
                NodeType[] types = NodeType.values();
                for (int i = 0; i < types.length; i++)
                    AuraNodeGen.place(l, base.offset(-5 + i * 2, 2, 5), types[i], null, RandomSource.create(i), false);
                // a vanilla beacon beside the row, to compare with how the pack draws real beacon beams
                for (int bx = -1; bx <= 1; bx++) for (int bz = -1; bz <= 1; bz++) l.setBlock(base.offset(bx - 8, -1, bz + 5), Blocks.IRON_BLOCK.defaultBlockState(), 2);
                for (int bx = -1; bx <= 1; bx++) for (int bz = -1; bz <= 1; bz++) l.setBlock(base.offset(bx - 8, 0, bz + 5), Blocks.AIR.defaultBlockState(), 2);
                l.setBlock(base.offset(-8, 0, 5), Blocks.BEACON.defaultBlockState(), 2);
                var rift = new art.arcane.thaumcraft.entity.FluxRiftEntity(art.arcane.thaumcraft.registry.ModEntities.FLUX_RIFT.get(), l);
                rift.snapTo(base.getX() + 0.5, base.getY() + 4.5, base.getZ() + 8.5, 0, 0);
                rift.setRiftSeed(7); rift.setRiftSize(40); rift.setRiftStability(100);
                l.addFreshEntity(rift);
                if (tag.startsWith("fx")) { // a golem standing beside the row of nodes
                    var g = art.arcane.thaumcraft.registry.ModEntities.GOLEM.get().create(l, net.minecraft.world.entity.EntitySpawnReason.SPAWN_ITEM_USE);
                    g.snapTo(base.getX() + 4.5, base.getY(), base.getZ() + 3.5, 180, 0);
                    g.setOwned(true); g.setValidSpawn(); g.setOwnerId(p.getUUID()); g.setNoAi(true);
                    l.addFreshEntity(g);
                }
                p.teleportTo(l, base.getX() + 0.5, base.getY() + 2.5, base.getZ() - 3.5, java.util.Set.of(), 0, 8, true);
            });
            cmd(mc, "gamerule advance_time false");
            cmd(mc, "time set noon"); cmd(mc, "weather clear");
        }
        if (ticks == 500) Screenshot.grab(mc.gameDirectory, "nodes_" + tag + "_day.png", mc.gameRenderer.mainRenderTarget(), 1, m -> {});
        if (ticks == 510) cmd(mc, "time set midnight");
        if (ticks == 700) Screenshot.grab(mc.gameDirectory, "nodes_" + tag + "_night.png", mc.gameRenderer.mainRenderTarget(), 1, m -> {});
        if (ticks == 720) { System.out.println("[NODESHOT] done"); mc.stop(); }
    }

    /** -PnodeShot=crystal: crystals on the floor, sides and ceiling of a small room; the camera aims at each in turn with the HUD on. */
    /** -PnodeShot=fx...: keep a primal arc bolt (beam pipeline) and Thaumcraft particles (particle layers) going. */
    private static void effects(Minecraft mc) {
        double x = base.getX() + 0.5, y = base.getY(), z = base.getZ() + 3.5;
        var r = mc.level.getRandom();
        if (ticks % 4 == 0) art.arcane.thaumcraft.client.fx.FXDispatcher.arcBolt(x - 4, y + 0.5, z, x - 2, y + 3.5, z + 1, 0.6f, 0.4f, 1.0f, 0.15f);
        for (int i = 0; i < 3; i++) {
            art.arcane.thaumcraft.client.fx.FXDispatcher.sparkle((float) (x - 1 + r.nextGaussian() * 0.3), (float) (y + 1.2 + r.nextGaussian() * 0.3), (float) z, 1.0f, 0.5f, 1.0f);
            art.arcane.thaumcraft.client.fx.FXDispatcher.drawWispyMotes(x + 1 + r.nextGaussian() * 0.3, y + 1, z, 0, 0.03, 0, 30, 0.3f, 0.9f, 1.0f, -0.01f);
            art.arcane.thaumcraft.client.fx.FXDispatcher.drawFireMote((float) (x + 2.5 + r.nextGaussian() * 0.2), (float) (y + 0.6), (float) z, 0, 0.04f, 0, 1.0f, 0.5f, 0.1f, 0.9f, 2.0f);
        }
    }

    /** -PnodeShot=trims: three armour stands wearing armour trimmed with thaumium, void metal and brass. */
    private static void trims(Minecraft mc) {
        var s = mc.getSingleplayerServer();
        if (ticks == 60) s.execute(() -> { var p = s.getPlayerList().getPlayers().getFirst(); p.setGameMode(GameType.SPECTATOR);
            p.teleportTo(s.overworld(), 3000.5, 152, 3000.5, java.util.Set.of(), 0, 8, true); });
        if (ticks == 200) s.execute(() -> {
            var l = s.overworld(); var p = s.getPlayerList().getPlayers().getFirst();
            base = new BlockPos(3000, 150, 3000);
            for (int x = -5; x <= 5; x++) for (int z = -2; z <= 6; z++) for (int y = -1; y <= 4; y++)
                l.setBlock(base.offset(x, y, z), y == -1 ? Blocks.STONE.defaultBlockState() : Blocks.AIR.defaultBlockState(), 2);
            var mats = l.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.TRIM_MATERIAL);
            var pats = l.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.TRIM_PATTERN);
            String[] m = {"thaumium", "void", "brass"};
            net.minecraft.world.item.Item[][] sets = {
                {net.minecraft.world.item.Items.DIAMOND_HELMET, net.minecraft.world.item.Items.DIAMOND_CHESTPLATE, net.minecraft.world.item.Items.DIAMOND_LEGGINGS, net.minecraft.world.item.Items.DIAMOND_BOOTS},
                {net.minecraft.world.item.Items.NETHERITE_HELMET, net.minecraft.world.item.Items.NETHERITE_CHESTPLATE, net.minecraft.world.item.Items.NETHERITE_LEGGINGS, net.minecraft.world.item.Items.NETHERITE_BOOTS},
                {net.minecraft.world.item.Items.IRON_HELMET, net.minecraft.world.item.Items.IRON_CHESTPLATE, net.minecraft.world.item.Items.IRON_LEGGINGS, net.minecraft.world.item.Items.IRON_BOOTS}};
            var slots = new net.minecraft.world.entity.EquipmentSlot[]{net.minecraft.world.entity.EquipmentSlot.HEAD, net.minecraft.world.entity.EquipmentSlot.CHEST, net.minecraft.world.entity.EquipmentSlot.LEGS, net.minecraft.world.entity.EquipmentSlot.FEET};
            for (int i = 0; i < 3; i++) {
                var stand = net.minecraft.world.entity.EntityTypes.ARMOR_STAND.create(l, net.minecraft.world.entity.EntitySpawnReason.COMMAND);
                stand.snapTo(base.getX() - 2 + i * 2 + 0.5, base.getY(), base.getZ() + 3.5, 180, 0);
                var mat = mats.getOrThrow(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.TRIM_MATERIAL, net.minecraft.resources.Identifier.fromNamespaceAndPath("thaumcraft", m[i])));
                for (int k = 0; k < 4; k++) {
                    var stack = new net.minecraft.world.item.ItemStack(sets[i][k]);
                    var pat = pats.getOrThrow(k < 2 ? net.minecraft.world.item.equipment.trim.TrimPatterns.SENTRY : net.minecraft.world.item.equipment.trim.TrimPatterns.RIB);
                    stack.set(net.minecraft.core.component.DataComponents.TRIM, new net.minecraft.world.item.equipment.trim.ArmorTrim(mat, pat));
                    stand.setItemSlot(slots[k], stack);
                }
                l.addFreshEntity(stand);
            }
            p.teleportTo(l, base.getX() + 0.5, base.getY() + 0.6, base.getZ() + 0.3, java.util.Set.of(), 0, 8, true);
        });
        if (ticks == 210) { cmd(mc, "time set noon"); if (!mc.gui.hud.isHidden()) mc.gui.hud.toggle(); }
        if (ticks == 420) Screenshot.grab(mc.gameDirectory, "trims.png", mc.gameRenderer.mainRenderTarget(), 1, m -> {});
        if (ticks == 440) { System.out.println("[NODESHOT] done"); mc.stop(); }
    }

    private static void crystals(Minecraft mc) {
        var s = mc.getSingleplayerServer();
        int[][] shots = {{0, 1, 2, 35}, {1, 3, 3, -35}, {2, -1, 2, 0}};   // which crystal, camera dy/dz, pitch
        if (ticks == 200) s.execute(() -> {
            var l = s.overworld(); var p = s.getPlayerList().getPlayers().getFirst();
            p.setGameMode(GameType.CREATIVE); p.getInventory().clearContent();
            base = new BlockPos(p.getBlockX(), 150, p.getBlockZ());
            for (int x = -3; x <= 3; x++) for (int z = -1; z <= 6; z++) for (int y = -1; y <= 4; y++)
                l.setBlock(base.offset(x, y, z), (y == -1 || y == 4 || z == 6) ? Blocks.STONE.defaultBlockState() : Blocks.AIR.defaultBlockState(), 2);
            var up = art.arcane.thaumcraft.ModBlocks.CRYSTAL_AER.get().defaultBlockState().setValue(art.arcane.thaumcraft.block.CrystalClusterBlock.SIZE, 3);
            l.setBlock(base.offset(-1, 0, 4), up, 2);
            l.setBlock(base.offset(1, 3, 4), up.setValue(net.minecraft.world.level.block.AmethystClusterBlock.FACING, net.minecraft.core.Direction.DOWN), 2);
            l.setBlock(base.offset(0, 1, 5), up.setValue(net.minecraft.world.level.block.AmethystClusterBlock.FACING, net.minecraft.core.Direction.NORTH), 2);
        });
        for (int i = 0; i < 3; i++) {
            int t = 300 + i * 120;
            int[][] cam = {{-1, 2, 2, 38}, {1, 1, 2, -50}, {0, 1, 2, 0}};
            int[] c = cam[i];
            if (ticks == t) s.execute(() -> { var p = s.getPlayerList().getPlayers().getFirst();
                p.teleportTo(s.overworld(), base.getX() + c[0] + 0.5, base.getY() + c[1] - 1.62 + 0.5, base.getZ() + c[2] + 0.5, java.util.Set.of(), 0, c[3], true);
                p.getAbilities().flying = true; p.onUpdateAbilities(); });
            if (ticks == t + 100) Screenshot.grab(mc.gameDirectory, "crystal_" + i + ".png", mc.gameRenderer.mainRenderTarget(), 1, m -> {});
        }
        if (ticks == 700) { System.out.println("[NODESHOT] done"); mc.stop(); }
    }

    private NodeShotScene() {}
}
