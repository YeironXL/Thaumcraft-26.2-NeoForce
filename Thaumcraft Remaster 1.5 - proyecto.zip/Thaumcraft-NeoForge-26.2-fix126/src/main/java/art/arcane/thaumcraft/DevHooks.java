package art.arcane.thaumcraft;

/**
 * Development scenes (screenshots, exploration, debug setups) are left out of the published jar. They are registered
 * by name so the mod runs the same whether they are present (development) or not (release).
 */
public final class DevHooks {
    public static void register(String className) {
        try {
            Class.forName(className).getMethod("register").invoke(null);
        } catch (ClassNotFoundException absentInRelease) {
            // not shipped: nothing to do
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Could not register development hook " + className, e);
        }
    }

    private DevHooks() {}
}
