package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.ModBlocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.common.NeoForge;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Development aid (-Dthaumcraft.explore=1): lets the normal world generator place Thaumcraft structures in fresh terrain
 * (plains, dark forest, swamp far from anything explored), finds them by their unique blocks and screenshots each one.
 */
public final class ExploreScene {
    private record Area(String name, Predicate<Holder<Biome>> biome) {}
    private record Found(String kind, BlockPos pos) {}
    private static final List<Area> AREAS = List.of(new Area("llanura", b -> b.is(Biomes.PLAINS)),
            new Area("sabana", b -> b.is(net.minecraft.tags.BiomeTags.IS_SAVANNA)),
            new Area("bosque_oscuro", b -> b.is(Biomes.DARK_FOREST)), new Area("pantano", b -> b.is(Biomes.SWAMP)));
    private static final int R = 12; // chunks each way: 25 x 25 = 625 chunks per area
    private static int ticks, wait;
    private static final List<Runnable> plan = new ArrayList<>();
    private static final List<Found> found = new ArrayList<>();
    private static boolean planned;
    private static volatile boolean busy;

    public static void register() {
        if (System.getProperty("thaumcraft.explore") == null) return;
        NeoForge.EVENT_BUS.addListener((ClientTickEvent.Post e) -> tick(Minecraft.getInstance()));
    }

    private static void server(Minecraft mc, java.util.function.Consumer<ServerLevel> r) {
        var s = mc.getSingleplayerServer();
        s.execute(() -> r.accept(s.overworld()));
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null || mc.getSingleplayerServer() == null) return;
        if (++ticks < 80) return;
        if (!planned) { planned = true; schedule(mc); }
        if (busy || wait > 0) { if (!busy) wait--; return; }
        if (!plan.isEmpty()) plan.removeFirst().run();
    }

    private static String kind(BlockState s) {
        if (s.is(ModBlocks.ELDRITCH_ALTAR.get())) return "obelisco_eldritch";
        if (s.is(ModBlocks.PEDESTAL_ANCIENT.get())) return "altar_wisps";
        if (s.is(Blocks.POLISHED_BLACKSTONE_BRICK_WALL)) return "obelisco_siniestro";
        if (s.is(Blocks.CHISELED_TUFF_BRICKS)) return "tumulo";
        return null;
    }

    private static void schedule(Minecraft mc) {
        if (!mc.gui.hud.isHidden()) mc.gui.hud.toggle();
        for (int a = 0; a < AREAS.size(); a++) {
            Area area = AREAS.get(a);
            int ai = a;
            plan.add(() -> { busy = true; server(mc, l -> {
                var p = l.getServer().getPlayerList().getPlayers().getFirst();
                p.setGameMode(GameType.SPECTATOR);
                l.getServer().getCommands().performPrefixedCommand(l.getServer().createCommandSourceStack().withSuppressedOutput(), "time set noon");
                var start = p.blockPosition().offset(400000 + ai * 20000, 0, -350000);
                var hit = l.findClosestBiome3d(area.biome(), start, 6400, 32, 64);
                BlockPos c = hit == null ? start : hit.getFirst();
                int cx = c.getX() >> 4, cz = c.getZ() >> 4, n = 0;
                long t0 = System.currentTimeMillis();
                for (int i = -R; i <= R; i++) for (int j = -R; j <= R; j++) { l.getChunk(cx + i, cz + j, ChunkStatus.FULL, true); n++; }
                int before = found.size();
                for (int i = -R + 1; i < R; i++) for (int j = -R + 1; j < R; j++) {
                    for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
                        int wx = ((cx + i) << 4) + x, wz = ((cz + j) << 4) + z;
                        int top = l.getHeight(Heightmap.Types.WORLD_SURFACE, wx, wz);
                        for (int y = top - 14; y <= top + 2; y++) {
                            String k = kind(l.getBlockState(new BlockPos(wx, y, wz)));
                            if (k == null) continue;
                            BlockPos fp = new BlockPos(wx, y, wz);
                            if (found.stream().noneMatch(f -> f.pos().distManhattan(fp) < 24)) found.add(new Found(k, fp));
                        }
                    }
                }
                System.out.println("[EXPLORE] " + area.name() + " at " + c + ": " + n + " chunks in " + (System.currentTimeMillis() - t0) + " ms, found " + found.subList(before, found.size()) + " stats " + art.arcane.thaumcraft.worldgen.StructuresV2.STATS);
                busy = false;
            }); wait = 40; });
        }
        plan.add(() -> {
            System.out.println("[EXPLORE] total " + found);
            int i = 0;
            for (Found f : found) {
                if (i >= 14) break;
                int idx = i++;
                plan.add(() -> { server(mc, l -> { var p = l.getServer().getPlayerList().getPlayers().getFirst();
                    p.teleportTo(l, f.pos().getX() + 0.5, f.pos().getY() + 14, f.pos().getZ() + 22.5, java.util.Set.of(), 180, 30, true); }); wait = 260; });
                plan.add(() -> { Screenshot.grab(mc.gameDirectory, "explore_" + idx + "_" + f.kind() + "_a.png", mc.gameRenderer.mainRenderTarget(), 1, m -> {}); wait = 5; });
                plan.add(() -> { server(mc, l -> { var p = l.getServer().getPlayerList().getPlayers().getFirst();
                    p.teleportTo(l, f.pos().getX() + 14.5, f.pos().getY() + 5, f.pos().getZ() + 0.5, java.util.Set.of(), 90, 12, true); }); wait = 200; });
                plan.add(() -> { Screenshot.grab(mc.gameDirectory, "explore_" + idx + "_" + f.kind() + "_b.png", mc.gameRenderer.mainRenderTarget(), 1, m -> {}); wait = 5; });
            }
            plan.add(() -> { System.out.println("[EXPLORE] done"); mc.stop(); });
        });
    }

    private ExploreScene() {}
}
