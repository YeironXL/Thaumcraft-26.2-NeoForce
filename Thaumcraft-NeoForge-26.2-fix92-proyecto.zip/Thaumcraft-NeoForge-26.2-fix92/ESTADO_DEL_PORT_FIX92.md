# Fix92 — carta Celestial

Carta Celestial añadida al mazo normal cuando CELESTIALSCANNING está completada y hay puntos de categoría. Fija dos variantes diferentes de notas0..12 y la categoría con más puntos al repartir; conserva esas selecciones al guardar. Consume ambas notas de manera atómica y una inspiración. Recompensa25..50 puntos. Sol aumenta penaltyStart; Luna concede un bonusDraw; estrellas añaden0..5 de corrupción temporal y el doble de conocimiento Eldritch. No duplica consumo al reactivar una carta elegida. Componentes nativos de notas, sin usar metadata antiguo.

Menú transmite ambas variantes con sus datos existentes; texto de requisitos localizable y trece nombres españoles. Carta marcada funcional en la lista de contenido.

Referencia CardCelestial de TC6 BETA26. El motor de mazo moderno conserva su implementación de azar; no certifica coincidencia exacta de semillas/distribución con todo el mazo original.

Diez tests de servidor aprobados, incluyendo investigación requerida, coste atómico con una nota ausente, recompensa/rango, Sol/Luna/estrellas, replay y persistencia de pares repartidos. Prueba del cliente verifica nombre/requisitos y captura la carta. No acredita early game íntegro ni recorrido manual conectado.
