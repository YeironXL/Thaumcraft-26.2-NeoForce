# Fix90 — cristales en suelo, paredes y techo

La generación de cristales comprueba ahora las seis orientaciones de soporte en cada espacio de cueva, comenzando por una orientación aleatoria. Antes solo intentaba UP (suelo), por lo que rechazaba paredes y techo aunque el bloque admitiera esos soportes. Se conservan seis aspectos primales, tamaño, rango vertical y frecuencia del feature existente. Solo afecta chunks nuevos.

Referencia: ThaumcraftWorldGenerator del TC6 permite espacios de cueva adyacentes a roca; no es una réplica completa de su densidad, selección por bioma ni agrupación.

Prueba invoca el feature real seis veces con un único soporte de piedra por orientación, comprueba posición y orientación generadas y loot con aspecto y tamaño. Las diez pruebas del servidor aprobadas. Esto prueba el feature en una cueva controlada, no una partida completa ni la distribución natural de un mundo recién generado.

Early game todavía abierto: suministro natural completo y recorrido conectado; cobertura de investigación/escaneos y fidelidad de contenido siguen pendientes.
