package art.arcane.thaumcraft.registry;

import art.arcane.thaumcraft.Thaumcraft;
import art.arcane.thaumcraft.aspect.AspectRegistry;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModComponents {
    private static final DeferredRegister<DataComponentType<?>> TYPES = DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, Thaumcraft.MOD_ID);
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<String>> ASPECT = TYPES.register("aspect", () -> DataComponentType.<String>builder()
            .persistent(Codec.STRING.validate(value -> AspectRegistry.get(value) == null ? DataResult.error(() -> "Unknown aspect " + value) : DataResult.success(value)))
            .networkSynchronized(ByteBufCodecs.STRING_UTF8).build());
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<art.arcane.thaumcraft.essentia.EssentiaContents>> ESSENTIA = TYPES.register("essentia", () -> DataComponentType.<art.arcane.thaumcraft.essentia.EssentiaContents>builder()
            .persistent(art.arcane.thaumcraft.essentia.EssentiaContents.CODEC)
            .networkSynchronized(ByteBufCodecs.fromCodec(art.arcane.thaumcraft.essentia.EssentiaContents.CODEC)).build());
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<art.arcane.thaumcraft.focus.TouchFireFocus>> TOUCH_FIRE_FOCUS = TYPES.register("touch_fire_focus", () -> DataComponentType.<art.arcane.thaumcraft.focus.TouchFireFocus>builder()
            .persistent(art.arcane.thaumcraft.focus.TouchFireFocus.CODEC)
            .networkSynchronized(ByteBufCodecs.fromCodec(art.arcane.thaumcraft.focus.TouchFireFocus.CODEC)).build());
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<net.minecraft.world.item.component.ItemContainerContents>> EQUIPPED_FOCUS = TYPES.register("equipped_focus", () -> DataComponentType.<net.minecraft.world.item.component.ItemContainerContents>builder()
            .persistent(net.minecraft.world.item.component.ItemContainerContents.CODEC)
            .networkSynchronized(net.minecraft.world.item.component.ItemContainerContents.STREAM_CODEC).build());
    public static void register(IEventBus bus) { TYPES.register(bus); }
    private ModComponents() {}
}
