# Estado del port — fix74

Añadidas páginas de fabricación normal con cuadrícula al Thaumonomicon, junto a las arcanas de fix73. Usa la cuadrícula propia del atlas original gui_researchbook_overlay.png (UV60,15;51x52, escala2), resultado encima y cantidades nativas. Las páginas normales no dibujan costes de vis ni cristales.

Resolución exacta contra el JSON de recetas enviado en la compilación. Ingredientes simples comprobados contra el registro: referencias ausentes, tags todavía sin resolver o patrones fuera de3x3 se omiten completos. Evita presentar casillas vacías como una receta terminada. Acceso continúa limitado a la etapa actual de una investigación accesible y conserva el regreso al libro.

No implementa todavía ingredientes rotatorios por tag, fabricación sin forma, aliases, grupos, addenda, crisol, infusión ni planos. No certifica toda la lectura de recetas ni equivalencia de los datapacks de servidores externos.

Compilación de producción y diez pruebas requeridas del servidor aprobadas. Cliente nativo aprobado: placa de hierro con patrón BBB y resultado de3 unidades, omisión de referencias ausentes/tags sin resolver, regresión de página arcana y navegación. Captura final inspeccionada: título, cuadrícula, cantidad del resultado y controles visibles.
