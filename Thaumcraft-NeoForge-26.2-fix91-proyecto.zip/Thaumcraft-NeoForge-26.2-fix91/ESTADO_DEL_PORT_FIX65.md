# Estado del port — fix65

Carta Programación de TC6: concede exactamente 25 puntos de Golemancia y cuesta 1 inspiración. Al elegirla consume 1 papel adicional y 2 usos de tinta en total: el uso propio de la carta y el uso común de activación, conforme CardScripting y ContainerResearchTable originales.

Disponible tras completar UNLOCKGOLEMANCY. Guarda la carta elegida con la sesión, mantiene propietario y revisión contra clics repetidos. Si falta papel o quedan menos de dos usos de tinta, rechaza sin modificar recursos, inspiración ni puntos. Texto español e inglés con costes explícitos, conservando la presentación de cartas y la fuente serif aprobada.

Comprobación del servidor: costes reales de la mesa, recursos insuficientes, guardado, recompensa, repetición y desbloqueo. El catálogo pasa a 17 de las 35 cartas inventariadas; no equivale a completar Golemancia ni el early game. Las cartas restantes, recetas ilustradas completas, haces del manipulador, gólems e infusión integrada siguen pendientes.

Validación final: compilación de producción y migración aprobadas; diez pruebas requeridas del servidor aprobadas. Cliente nativo aprobado, incluido nombre español de la nueva carta, sin errores de tareas GUI. No se certifica todavía partida manual completa ni paridad integral del original.
