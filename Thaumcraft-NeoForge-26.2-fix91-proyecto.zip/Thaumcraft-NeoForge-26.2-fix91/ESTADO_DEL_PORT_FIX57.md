# Estado del port — fix57

## Cambios

Espuma del crisol con los fotogramas 64–66 del atlas original, tono gris azulado, duración de 4–6 ticks y tamaño/gravedad de crucibleFroth. Se emite sobre la superficie del modelo de agua actual únicamente con agua y calor superior a 150. La emisión visual cada cinco ticks usa un azar independiente del de recetas/derrames. No modifica consumo, productos ni progresión.

## Verificación

Proveedor registrado en cliente, geometría nativa y caducidad comprobadas. Captura de burbuja y estallido revisada. Diez pruebas requeridas de integración del servidor y compilación de producción con regresiones de migración. Recursos de verificación excluidos del JAR.

## Límites

Frecuencia y transparencia adaptadas al motor moderno. Quedan burbujas de colores por aspecto, rebose por exceso, mezcla aditiva exacta y revisión del efecto integrado dentro del mundo. Se documentaron fotogramas concretos de la guía de alquimia; no se vio el episodio completo ni se acredita paridad total.
