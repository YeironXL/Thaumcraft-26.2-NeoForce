# Estado del port — fix67

Carta Revelación de TC6, contrastada con CardRevelation y la conversión de TileResearchTable: cuesta 1 inspiración, concede 30 puntos de Sobrenatural y otros 5–10 en una categoría aleatoria. Añade 5 de distorsión temporal y 1 normal; no añade distorsión permanente. Aumenta en uno penaltyStart, lo que permite que una categoría adicional de la teoría final evite la reducción de dos tercios.

La carta aparece después de completar UNLOCKELDRITCH y respeta categorías rechazadas. Los puntos aleatorios se sortean al activar, como en TC6, mientras que la elección y el umbral de conversión se guardan con la sesión. La revisión y el vaciado de elecciones impiden aplicarla dos veces.

Los valores de distorsión saturan en el máximo entero para no desbordarse. La interfaz en español e inglés describe el coste, la distorsión y el efecto sobre la conversión. Se conservan la tipografía serif y las cartas verticales.

Esta carta usa los contadores de distorsión existentes; no implementa los eventos originales de distorsión ni certifica la etapa Sobrenatural. El catálogo pasa a 19 de las 35 cartas inventariadas. Siguen pendientes early game completo, infusión integrada, gólems y los efectos visuales indicados en la auditoría.

Validación final: compilación de producción y migración aprobadas; diez pruebas requeridas del servidor aprobadas. La carta pasó 50 comparaciones de recompensas, distorsión y conversión final. Cliente nativo aprobado sin errores de tareas GUI; nombre y descripción españoles verificados, captura de la carta inspeccionada.
