# Estado del port — fix68

Cartas Verdad y Comprensión de TC6, contrastadas con CardTruth y CardRealization. Ambas cuestan 1 inspiración y requieren completar UNLOCKELDRITCH para aparecer en el mazo normal; respetan las categorías rechazadas.

Verdad concede 10–25 puntos de Sobrenatural, 1 robo adicional y 3 de distorsión temporal. Comprensión concede 15 puntos de Sobrenatural y dos premios independientes de 5–10 en categorías aleatorias, que pueden coincidir entre sí o con Sobrenatural. Añade 5 de distorsión temporal y tiene un 50 % de probabilidad de añadir 1 de distorsión normal.

Ninguna cambia la distorsión permanente ni el umbral de conversión de la teoría. Las recompensas se sortean al activar, como en el original. La carta elegida, puntos, inspiración y robos adicionales permanecen al guardar la sesión; la revisión y el vaciado de elecciones impiden repetir la activación. La distorsión satura en el máximo entero para evitar desbordamientos.

Se conservan las cartas verticales, icono original de Sobrenatural y fuente serif aprobada. Textos español e inglés describen efectos y riesgos concretos. Los títulos se ajustan al ancho de la palabra más larga para evitar que Comprensión se corte por la mitad; los títulos de varias palabras conservan el reparto en líneas.

El catálogo pasa a 21 de las 35 cartas inventariadas. Las ayudas y cartas restantes, los eventos originales de distorsión, la infusión integrada y los gólems siguen pendientes. Este cambio no certifica etapa Sobrenatural ni early game completos.

Validación final: compilación de producción y migración aprobadas; diez pruebas requeridas del servidor aprobadas, incluidas cien comparaciones de efectos originales de Verdad y Comprensión. Cliente nativo aprobado sin errores de tareas GUI. Captura final de las tres cartas de Sobrenatural inspeccionada: Comprensión se muestra completa en una línea con la fuente serif.
