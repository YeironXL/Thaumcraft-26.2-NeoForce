# Estado del port — fix62

La lectura del Thaumonomicon conserva los párrafos separados por BR y los saltos de página PAGE del texto original. La paginación automática respeta esos límites: el siguiente segmento empieza en otra página física, aunque quede espacio libre en la anterior. Conserva páginas vacías explícitas para mantener la alineación de la doble página.

Los descriptores IMG de textura, recorte y escala ya no aparecen como frases dentro del libro. Se reserva separación en el texto; el renderizado de esas ilustraciones sigue pendiente. LINE y DIV se adaptan como separación de líneas/párrafos, sin reproducir todavía sus ornamentos originales.

Se mantiene la fuente serif aprobada. No cambia requisitos, costes ni reglas de progreso del servidor. La verificación del cliente comprueba separación de párrafos, límite de página explícito, páginas vacías y eliminación del descriptor interno de una ilustración.

Referencia: GuiResearchPage.parsePages de TC6 1.12.2 BETA26 y el texto conservado de sus traducciones. La lectura completa con ilustraciones y recetas no se considera terminada.

Validación: compilación de producción, migración, comprobaciones de paginación del cliente, captura de lectura inspeccionada y las diez pruebas requeridas del servidor aprobadas.
