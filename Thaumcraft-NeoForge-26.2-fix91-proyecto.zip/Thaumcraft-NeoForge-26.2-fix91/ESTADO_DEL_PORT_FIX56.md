# Estado del port — fix56

## Cambios

El primer foco de fuego usa su secuencia de partículas original (fotogramas 640–649), con diez ticks de duración, alfa 0,7, gravedad −0,2, tamaño y frenado tomados de FocusEffectFire de TC6. El atlas original se conserva byte por byte en su ruta adaptada al cargador moderno. No cambia daño, costes, alcance, enfriamiento ni reglas de investigación.

## Verificación

Registro y proveedor cargados en cliente, geometría translúcida nativa y caducidad comprobados. Captura de los diez fotogramas revisada. Diez pruebas de integración del servidor aprobadas y compilación de producción con verificaciones de migración. Fuentes y recursos de verificación excluidos del JAR de producción.

## Límites

La transparencia emplea la capa nativa moderna. La mezcla aditiva exacta del motor de TC6, una revisión del lanzamiento dentro del mundo y los haces/cristales animados del manipulador siguen pendientes. Esta entrega no acredita paridad total de efectos ni cierre del early game. Se registraron cuatro escenas concretas de la guía de auromancia, sin afirmar haber visto el episodio completo.
