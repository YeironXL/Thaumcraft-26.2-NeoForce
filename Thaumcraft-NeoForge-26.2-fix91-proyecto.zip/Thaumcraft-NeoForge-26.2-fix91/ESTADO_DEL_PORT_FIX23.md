# Thaumcraft NeoForge 26.2 — fix23

Avance sobre fix22. No es todavía una implementación completa de Thaumcraft 6.1.BETA26.

## Cambios

- Horno Infernal en la mano: modelo de objeto independiente reducido de 48 a 16 unidades y poses estándar de Minecraft. El modelo colocado conserva su tamaño de estructura. Se comprueban las dimensiones del modelo horneado en todos los contextos, incluidas ambas manos y perspectivas.
- Thaumometer: textura de scanner correcta; antes apuntaba por error a las gafas.

- Etapas de investigación persistentes; una investigación conocida y una terminada son estados distintos.
- Soporte de requisitos con etapa (`FIRSTSTEPS@1`) y expresiones de investigación AND/OR. Los identificadores `!gotdream` y `!gotthaumonomicon` conservan literalmente el signo `!`.
- Petición de avance desde el Thaumonomicon. El servidor comprueba clave, etapa esperada, posesión del libro y requisitos. Una petición repetida no vuelve a cobrar el coste.
- Registro persistente de fabricación mediante eventos del servidor y transformaciones de Salis Mundus.
- Conocimiento por tipo/categoría, en unidades internas originales: 16 para observación y 32 para teoría. El avance valida todos los costes antes de retirar objetos/conocimiento.
- Requisitos de objetos simples con cantidades; duplicados agregados antes del cobro. Las variantes con metadata, NBT y etiquetas antiguas aún no migradas bloquean el avance.
- El libro muestra la etapa actual, recibe actualizaciones sin perder la selección y mantiene cerrada la pantalla si una respuesta llega después de cerrarla.
- Visibilidad de investigaciones ocultas según descubrimiento/prerrequisitos, incluidos los artículos iniciales de las categorías; concesiones de investigaciones hermanas desde los datos originales.
- Escaneo de bloques con aspectos conocidos: observaciones mediante la fórmula y pesos de las siete categorías originales. Escaneos repetidos o bloques sin aspectos no conceden conocimiento.
- Recoger Crystal Essence marca el descubrimiento inicial. Despertar después concede una sola vez el diario de sueños, con páginas originales adaptadas al componente de libro moderno.
- Salis Mundus: biblioteca consumida al obtener el libro, requisito del sueño, transformación de mesa con `FIRSTSTEPS@1` y caldero con `UNLOCKALCHEMY@1`, respeto del modo agachado y permisos de uso. Estas transformaciones son inmediatas; no incluyen aún el efecto diferido original.

## Validación

`gradlew.bat build --offline` ejecuta pruebas de persistencia, costes, etapas, fabricación, prerrequisitos, concesiones, visibilidad, fórmula de observaciones y protección ante peticiones repetidas. El cliente de verificación prueba el inventario del Hungry Chest y captura el Thaumonomicon con Minecraft real. Las clases de prueba se excluyen del JAR final.

Falta validar en una partida el recorrido completo de eventos (recogida, sueño, transformaciones y paquetes), inventarios multijugador y servidor dedicado. La prueba de inventario emplea objetos de prueba, no entidades/tolvas colocadas.

## Límites y siguiente trabajo

La mesa arcana y el crisol siguen siendo esqueletos. Transformarlos no implementa sus recetas ni permite todavía terminar el inicio en supervivencia: falta fabricar el Thaumometer con vis/cristales. Crystal Essence todavía necesita sus variantes/componentes y una receta funcional de Salis Mundus. El escaneo de entidades/objetos, las teorías/cartas, la generación del mundo y el resto de sistemas siguen pendientes.

Se mantienen los cambios visuales, creativo y Hungry Chest de fix22; consultar `ESTADO_DEL_PORT.md` para ese historial y el inventario general de pendientes.

Referencia: reconstrucción comunitaria de Thaumcraft 6 en https://github.com/TheDarkTower314/Thaumcraft-6-Source-Code, commit 954022bb777b7546281fb36df8522f0ba6b43f81. No es una publicación oficial de Azanor.

Requiere Minecraft 26.2, NeoForge 26.2.0.88 y Java 25. Compilar: `gradlew.bat build`. Desarrollo: `gradlew.bat runClient`.
