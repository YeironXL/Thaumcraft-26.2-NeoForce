# Thaumcraft NeoForge 26.2 — fix27

Las cinco variantes de tubos pendientes ya tienen transporte funcional y recetas nativas. Continúa sobre fix26. El resto del mod aún está en proceso de portado.

## Variantes

- Válvula: cierre manual y cierre con redstone; reapertura al retirar la señal. El lado del mando no conecta. Conserva estado manual y estado anterior de redstone.
- Filtro: se configura con un cristal, frasco lleno o tarro con esencia, sin consumirlo. Solo deja pasar el aspecto elegido y transmite succión compatible. Guarda el filtro; su color se sincroniza al cliente.
- Restricción: transmite la mitad de la succión recibida.
- Direccional: obtiene succión desde la salida y permite transferir esencia solo hacia esa cara. El anillo dorado identifica la salida.
- Depósito/buffer: capacidad total de diez unidades de varios aspectos. Selecciona el aspecto solicitado por el receptor y respeta consumidores con mayor succión. Tiene regulación independiente por cara: normal, succión 1 y succión 0.
- Fuelles orientados hacia el depósito: 32 puntos de succión por fuelle activo. Una señal de redstone sobre el fuelle lo desactiva para este uso. El regulador de cada cara puede reducir o anular esa succión.
- Todos los tubos permiten cerrar conexiones por cara; entre tubos vecinos se actualizan ambos extremos. Contenido y ajustes persisten al guardar/cargar el mundo. La lectura admite el formato `stored` de fix26.
- Recetas originales para las cinco variantes y fuelles. El creativo conserva su orden temático.
- Geometría de conexiones, indicadores de válvula abierta/cerrada, color del filtro, sonidos de válvula/configuración y humo durante conflictos de succión.

## Controles adaptados

Estos controles de mano vacía permiten configurar la red mientras el sistema completo del guantelete sigue pendiente.

- Válvula: clic con mano vacía sobre el centro abre/cierra. La orientación del mando se establece al colocarla.
- Direccional: clic con mano vacía sobre el centro cambia la salida entre las seis direcciones.
- Filtro: clic con una muestra de aspecto lo configura. Agachado con mano vacía elimina el filtro.
- Conexiones: clic con mano vacía sobre un tramo lateral alterna su conexión. En tubos normales, direccionales y válvulas, agacharse permite actuar sobre la cara del centro cuando el tramo está cerrado. En filtros y depósitos, clic sobre la cara del centro también alterna la conexión.
- Depósito: agachado con mano vacía sobre una cara alterna su regulador entre normal, 1 y 0. La regulación afecta la succión; no es una tapa que bloquee también la salida.
- Cada configuración muestra información de contenido, succión y ajustes en el chat.

## Comprobaciones

- Dos GameTests en mundo desechable: cadena de destilación de fix26 y pruebas específicas de variantes.
- Filtro rechaza un aspecto incorrecto y acepta el correcto. Configuración mediante la interacción real con un frasco, sin consumir la muestra.
- Válvula con redstone, reapertura y cierre manual sin fugas.
- Restrictor reduce 32 a 16; direccional bloquea el retorno y permite el sentido correcto.
- Depósito de diez unidades con dos aspectos, salida del aspecto solicitado, fuelle, tres regulaciones y persistencia.
- El cliente carga geometría no vacía para 6.547 estados de bloques, incluidos todos los estados de las variantes. Se mantienen las comprobaciones de las caras/altura del líquido de los tarros.
- Compilación de producción y regresiones de migración. No se incluyen clases de verificación en el JAR.

Las animaciones exactas del mando y de los fuelles del original no están reproducidas: se usan indicadores estáticos y sonidos. La comprobación automatizada de geometría no sustituye una revisión visual manual dentro de una partida. Esta entrega termina el comportamiento de transporte de las variantes, no el resto de funcionalidades del mod ni los usos de fuelles en otras máquinas.
