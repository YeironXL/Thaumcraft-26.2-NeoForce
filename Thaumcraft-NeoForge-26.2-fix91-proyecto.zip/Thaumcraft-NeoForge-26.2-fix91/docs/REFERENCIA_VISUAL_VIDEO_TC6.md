# Referencia visual en video — Thaumcraft TC6

Video aportado por el usuario: https://www.youtube.com/watch?v=KgBnmFzYOFk
Playlist: https://www.youtube.com/playlist?list=PLnKuVFOfCrfp31GKSKalnWHDCB_HICju5
Título verificado en YouTube: Thaumcraft 6 | Tutorial Completo | Parte 1 "Fundamentals" (Español) | Minecraft 1.10.2 | Danymaddox.
Duración mostrada: 39:01. Playlist: 15 episodios. Los primeros episodios se presentan como 1.10.2; los episodios de revisión posteriores se presentan como 6.1/1.12.2. No identificar automáticamente esta primera parte con BETA26.

## Escenas inspeccionadas en el navegador

- 04:37: navegador de investigación sobre fondo azul oscuro/estelar, marco, nodos conectados. Fix54 recupera fondo, marcos, posiciones, iconos y navegación por mapa; animaciones avanzadas pendientes.
- 07:48: entrada de First Steps en libro abierto de dos páginas, texto y requisitos. Fix54 dedica ambas páginas a una entrada; requisitos iconográficos y recetas ilustradas pendientes.
- 08:33: mesa arcana verde sobre madera, rejilla y cristales circulares, salida a la derecha, inventario debajo. La distribución de fix53 recupera este patrón del código TC6 original. No se compara el panel externo de recetas mostrado por otros mods.
- 12:22: investigación sobre madera con dos cartas de papel verticales, indicadores de inspiración arriba e inventario abajo. Fix55 adapta las opciones a tres cartas verticales con papel, categoría y coste de inspiración. Conserva datos del servidor; animaciones y disposición exacta original pendientes.
- 19:30: escena de mundo con vegetación y un panel informativo de bloque procedente de otro mod. No copiar ese HUD externo como si fuera parte de Thaumcraft.

Se revisaron escenas concretas y la transcripción automática para localizar momentos; no se ha visto de principio a fin ni inspeccionado visualmente cada episodio. La transcripción tiene errores de reconocimiento y no se usa para fijar costes ni mecánicas.

## Prioridad artística tras fix53

1. Mapa de investigaciones del Thaumonomicon con fondo, nodos, líneas y categorías del original.
2. Lectura de entradas en doble página de pergamino, flechas y requisitos iconográficos.
3. Cartas verticales de investigación, inspiración y animación de selección.
4. Auromancia, alquimia, artificio, infusión y gólems, contrastados con los episodios correspondientes y el código 1.12.2–BETA26.

Se mantiene la tipografía serif aprobada por el usuario. La referencia funcional final sigue siendo 1.12.2–6.1.BETA26; el video sirve de referencia visual y de recorrido. Las apariencias de mods externos y las diferencias entre betas deben separarse.

## Catálogo de la playlist

Los títulos y enlaces se leyeron en la playlist; «pendiente» significa que todavía no se verificaron fotogramas del episodio.

| Episodio | Enlace | Revisión visual |
|---|---|---|
| Fundamentals (1.10.2) | https://www.youtube.com/watch?v=KgBnmFzYOFk | Escenas 04:37, 07:48, 08:33 y 12:22 inspeccionadas |
| Auromancy (1.10.2) | https://www.youtube.com/watch?v=W5gUFrDOqss | Escenas 14:11, 19:44, 22:34 y 25:23 inspeccionadas |
| Alchemy (1.10.2) | https://www.youtube.com/watch?v=mPnltxzIIuQ | Escenas 03:17, 03:22 y 06:45 inspeccionadas |
| Artefacts (1.10.2) | https://www.youtube.com/watch?v=U8H5PbaXPMU | Escenas 03:17, aprox. 06:34 y 09:51 inspeccionadas |
| Infusion (1.10.2) | https://www.youtube.com/watch?v=XVVhe6KL4lk | Fotogramas 07:35, 11:22 y 18:57 inspeccionados |
| Golemancy (1.10.2) | https://www.youtube.com/watch?v=78pTIeE5pQw | Fotogramas 09:17, 23:12 y 37:08 inspeccionados |
| Beta 4, 5, 6 | https://www.youtube.com/watch?v=RR-zMp_43Hc | Pendiente |
| Beta 7 | https://www.youtube.com/watch?v=31N1zUfhlfk | Pendiente |
| Beta 8 | https://www.youtube.com/watch?v=XMVDgOqaDzk | Pendiente |
| Beta 10–13 (1.12.2) | https://www.youtube.com/watch?v=VP2zRfYQiDA | Pendiente |
| Beta 13–16 (1.12.2) | https://www.youtube.com/watch?v=E0MpI665LUI | Pendiente |
| Beta 17 (1.12.2) | https://www.youtube.com/watch?v=I8JFCwGGQD4 | Pendiente |
| Beta 18 y 19 (1.12.2) | https://www.youtube.com/watch?v=jWfXACWGoB8 | Pendiente |
| Beta 20–24 (1.12.2) | https://www.youtube.com/watch?v=BHbDnBbCx08 | Fotogramas 05:02, 12:36 y 20:10 inspeccionados |
| Beta 25 (1.12.2) | https://www.youtube.com/watch?v=CfBYyTmMmuY | Fotogramas 03:10, 07:56 y 12:42 inspeccionados |


## Auromancia — escenas inspeccionadas en fix56

Video W5gUFrDOqss, reproductor de 28:12, Minecraft 1.10.2 (beta anterior a la referencia funcional BETA26).

- 14:11: manipulador trabajando, cristales visibles alrededor y haces luminosos entre ellos y el centro. Estos efectos de fabricación todavía faltan en el port.
- 19:44: modelo del manipulador sobre su soporte; detrás aparece otra estación trabajando. No confundir esa estación con el foco sostenido.
- 22:34: vista general del mundo y recorrido de demostración; el fotograma aislado no permite certificar una animación de lanzamiento.
- 25:23: demostración de intercambio de bloques en una plataforma con criaturas cercanas; esa función no se considera implementada por esta revisión.

La secuencia de fuego de fix56 procede de FocusEffectFire.renderParticleFX y FXGeneric/ParticleEngine de la fuente TC6 1.12.2, no de una deducción de estos cuatro fotogramas. No se ha visto el episodio completo. Los quince enlaces del catálogo se reconfirmaron con los enlaces de la playlist visibles en YouTube.


## Alquimia — escenas inspeccionadas en fix57

Video mPnltxzIIuQ, reproductor 33:47, Minecraft 1.10.2. Solo se inspeccionaron estos fotogramas:

- Aproximadamente 03:17: crisol colocado con agua azul, burbuja visible sobre la superficie y polvo de piedra luminosa en mano. La escena se contrastó con TileCrucible.drawEffects y FXDispatcher.crucibleFroth de BETA26.
- 03:22: doble página del libro, entrada Alchemical Metallurgy y selector lateral; no es una vista del crisol.
- 06:45: vista de un personaje en una estructura de piedra; no permite verificar una animación de alquimia.

Fix57 recupera únicamente la espuma caliente con fotogramas originales. No certifica el efecto completo mostrado en la guía ni que todas las partículas de aspecto/derrames estén implementadas. El fotograma del crisol se revisó antes de pausar el reproductor; la pausa mostró 03:14, por lo que se conserva el tiempo aproximado de la captura (03:17).


## Artificio — escenas inspeccionadas en fix58

Video U8H5PbaXPMU, reproductor 32:53, Minecraft 1.10.2. Se revisaron estos fotogramas, sin ver el episodio completo:

- 03:17: inventario creativo y jugador con equipo; no acredita que todos los objetos ni las armaduras estén portados. El buscador de recetas visible pertenece a otro mod.
- Aproximadamente 06:34 (salto al 20%): jugador en una escena exterior de demostración. No se extraen mecánicas de crecimiento del subtítulo automático.
- Aproximadamente 09:51 (salto al 30%): mapa sobre fondo morado estelar, conexiones curvas y categorías con iconos en el borde. La escena muestra focos de auromancia dentro del episodio de artificio; no etiquetar ese árbol como Artifice.

Fix58 contrasta los marcos e iconos con GuiResearchBrowser.GuiCategoryButton y la condición de acceso con GuiResearchBrowser.initGui. Se conserva una disposición horizontal adaptada al tamaño actual; disposición lateral exacta, conexiones curvas y marcadores de novedades siguen pendientes.


## Infusión — escenas inspeccionadas en fix60

Video XVVhe6KL4lk, duración 37:55, Minecraft 1.10.2 (beta anterior a BETA26). Se revisaron únicamente estos fotogramas pausados:

- 07:35: altar de infusión con matriz de símbolos morados, pilares y pedestales oscuros, velas amarillas y haces verdes entrando en la zona del altar. Un fotograma no determina duración ni función exacta de los haces.
- 11:22: vista cercana de pilares y matriz, velas alrededor y espejo en la pared. No se confirma una animación completa ni su temporización.
- 18:57: exposición de armaduras sobre soportes junto a objetos altos y una zona del altar. No permite certificar todas las propiedades del equipo.

No se vio el episodio completo. Los modelos registrados o sus recursos conservados no acreditan funcionamiento, animación ni estabilidad del sistema de infusión. La guía continúa como referencia visual; las mecánicas finales deben contrastarse con BETA26.

Fix60 recupera las conexiones del mapa desde GuiResearchBrowser.drawLine de BETA26: tramos horizontales/verticales, esquinas pequeñas y grandes del atlas y flechas con REVERSE. No usa curvas Bézier inventadas. La referencia visual de esas conexiones es la escena de auromancia en el episodio de artificio, aproximadamente 09:51, ya documentada en fix58.


## Golemancia — fotogramas inspeccionados tras fix63

Video 78pTIeE5pQw, duración 46:25, Minecraft 1.10.2 (beta anterior a BETA26). Se inspeccionaron solo tres fotogramas pausados, no el episodio completo:

- 09:17: interfaz del constructor, panel de piedra con selección de piezas/rasgos, bordes metálicos dorados y tooltip Fighter. La lista de objetos a la derecha corresponde a un visor de recetas externo y no debe copiarse como parte de Thaumcraft.
- 23:12: pantalla de configuración de sello con lacre rojo, pestañas/iconos laterales y secciones Required/Forbidden; tooltip Smart. No se deduce una IA funcionando a partir de esta pantalla.
- 37:08: otra pantalla de sello, lacre rojo con filtro de objetos y control Blacklist. Hay inventario debajo y un visor externo a la derecha. Aunque se buscó una escena en mundo, este fotograma muestra otra interfaz; no se revisó aquí una animación de gólem.

Contraste funcional/artístico de BETA26: GuiGolemBuilder usa gui_golembuilder.png y TileGolemBuilder/ContainerGolemBuilder; SealBaseGUI y SealBaseContainer organizan las pantallas de sellos, y RenderThaumcraftGolem organiza el renderer. Esas clases se conservan únicamente en la referencia comunitaria, no se consideran portadas por aparecer en el inventario.

Estado del port al revisar: el constructor y los sellos no tienen sus menús, IA ni tareas implementados. Los recursos y registros conservados mantienen estado parcial/pendiente. La exposición de rasgos y los filtros de sello requerirán sincronización validada por el servidor antes de añadir la pantalla original.


## Revisión de betas 20–24 — fotogramas inspeccionados tras fix64

Video BHbDnBbCx08, duración 25:12, titulado Thaumcraft 6.1 Beta 20–24 para Minecraft 1.12.2. Es más próximo a la referencia funcional que los tutoriales iniciales de 1.10.2, pero no equivale automáticamente a BETA26.

- 05:02: vista cercana de una pared de piedra, vegetación y una luz. No permite identificar una mecánica nueva ni comprobar su implementación.
- 12:36: conjunto de dispositivos con estructura dorada, piezas moradas y conexiones oscuras sobre suelo de piedra. El fotograma no muestra un identificador inequívoco; se conserva la descripción visual sin asignar nombre ni función confirmados.
- 20:10: inventario creativo vanilla con el personaje equipado y varios objetos. No se considera prueba de que todas las propiedades del equipo estén implementadas, ni se copia su menú como interfaz propia de TC6.

Solo se inspeccionaron estos tres fotogramas pausados. La narración completa y las animaciones no se han revisado. El catálogo de la playlist también se actualizó para que infusión y golemancia no siguieran figurando como episodios sin fotogramas revisados.


## Beta 25 — fotogramas inspeccionados tras fix68

Video CfBYyTmMmuY, título Thaumcraft 6.1 Tutorial Completo Beta 25, Minecraft 1.12.2, duración 15:53. Se inspeccionaron tres fotogramas pausados, no el video completo ni las secuencias de animación. Audio silenciado; los subtítulos visibles son contexto parcial, no una transcripción revisada.

- 03:10: habitación de piedra con suelo de madera, cofres y sello circular rojo colocado en pared. El nombre visible del objeto sostenido es Control Seal: Guard. SealGuard de BETA26 identifica el icono items/seals/seal_guard y la clave thaumcraft:guard. La presencia visual no verifica tareas de defensa ni IA; los sellos continúan pendientes en el port.
- 07:56: escena exterior oscura y lluviosa con un carro o recipiente claro, dispositivos y un haz verde. No aparece identificador inequívoco del conjunto en el fotograma; no se atribuye el haz a un sistema concreto ni se certifica transporte sobre raíles.
- 12:42: habitación de piedra y madera; recipiente gris abierto con emblema frontal y otro rosado al lado. Se sostiene Glass bottle; la pared contiene objetos en marcos. No se deduce de esta imagen estática una receta, interacción de botella o purificación terminada.

Contraste del crisol con el código BETA26: TileCrucibleRenderer.renderFluid usa water_still y calcula recolor a partir de aspects.visSize()/500; si hay aspectos, transforma a 0.5+recolor/2 y limita a 1. Los multiplicadores RGB son 1-recolor/3, 1-recolor y 1-recolor/2. En el port actual, los cuatro modelos crucible_water usan tintindex 0 y ThaumcraftClient registra BlockTintSources.water(), dependiente del bioma. No incorpora aún el tinte dinámico por concentración ni la sincronización visual de esa concentración. Esta diferencia se registra como pendiente; no se afirma que haya sido corregida en fix68.

Los tutoriales iniciales de 1.10.2 y este episodio beta 25 no sustituyen la referencia funcional BETA26. Los elementos externos y las funciones no identificadas permanecen separados de la auditoría de Thaumcraft.

Seguimiento fix69: la discrepancia de tinte registrada tras fix68 se corrigió usando los multiplicadores de TileCrucibleRenderer y actualizaciones del contenido al cliente. Paleta y datos de actualización se verifican; la escena completa en mundo y la transparencia exacta siguen pendientes. No se añaden fotogramas nuevos a esta revisión.
