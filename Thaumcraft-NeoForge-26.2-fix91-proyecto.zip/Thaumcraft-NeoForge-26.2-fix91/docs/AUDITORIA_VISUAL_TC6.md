# Auditoría visual TC6 — fix81

Comparación de todos los recursos PNG/JPG/OBJ/MTL/OGG/JSON disponibles de la referencia con el port. No es una certificación de fidelidad en juego.

## Inventario de recursos

- modificado: 398
- reubicado idéntico: 524
- idéntico: 500

Colores de aspectos coincidentes: 37/37.

## Sistemas artísticos revisados

| Sistema | Estado real |
|---|---|
| Libro | Textura original abierta; tipografía original recuperada para el pedido1:1; mapa con posiciones, marcos e iconos originales y lectura en doble página con proporciones originales; selector con marcos e iconos originales, sujeto a los desbloqueos del jugador. Conexiones y flechas con los segmentos curvos del atlas original; enlaces secundarios sin flecha y tonos originales incorporados; párrafos y saltos de página originales conservados; ilustraciones IMG y ornamentos LINE/DIV originales incorporados; primeras páginas de fabricación normal, arcana y alquimia en crisol con recursos del datapack y atlas original incorporadas; demás recetas ilustradas y animaciones pendientes. |
| Mesa arcana | Atlas original y disposición original de ranuras y seis cristales. |
| Horno alquímico | Atlas e indicadores originales de llama, progreso y reserva; cantidades en tooltips. |
| Investigación | Madera y papel originales; tres cartas verticales con iconos de categoría, inspiración y detalles al pasar el cursor. Diseño compacto adaptado; animación original pendiente. |
| Crisol | Geometría y cuatro niveles de agua conservados; espuma original incorporada. Agua con multiplicadores RGB originales según concentración, sin tinte de bioma; contenido y cruces del umbral de ebullición sincronizados al cliente y actualización del modelo. Paleta y datos verificados; vista integrada en mundo pendiente. |
| Manipulador | Metal original adaptado; editor de grafo original pendiente. |
| Objetos sostenidos | Guanteletes con atlas corregido; comprobación del horno existente. Transformaciones de todos los objetos pendientes de revisión en mundo. |
| Bloques | Recursos/modelos existentes conservados; igualdad de archivo no acredita renderer especial, animación ni estado en mundo. |
| Entidades | Solo Alumentum tiene renderer de entidad registrado en el cliente actual; criaturas, gólems y demás renderers originales pendientes. |
| Efectos | Fuego del primer foco con diez fotogramas originales, gravedad, duración y frenado de TC6; transparencia adaptada al renderizador moderno. Espuma del crisol con fotogramas 64–66 y tono original, activa solo con agua hirviendo. Destellos centrales del manipulador con fotogramas 448–456, activos durante fabricación. Burbujas por aspecto con fotogramas originales, colores y vida incorporados; codec, proveedor y geometría verificados. Rebose morado por los cuatro bordes con umbral original y fotogramas 73, 66 y 65 incorporado. Vista integrada, rayos, aura, demás partículas y shaders originales pendientes. |
| Armaduras | Gafas con capa original de equipo; resto y vista sobre jugador pendientes. |
| Aspectos | Comparación de iconos y colores incluida en JSON; no equivale a validar HUD/revelación. |
| Sonido | Inventario binario comparado; activación y ambientes originales pendientes. |

## Recursos ausentes


## Trazabilidad

Detalle por archivo y clases visuales originales en `AUDITORIA_VISUAL_TC6.json`. Se respetan los recursos originales; la fuente Alegreya es una adaptación aprobada en esta conversación.
