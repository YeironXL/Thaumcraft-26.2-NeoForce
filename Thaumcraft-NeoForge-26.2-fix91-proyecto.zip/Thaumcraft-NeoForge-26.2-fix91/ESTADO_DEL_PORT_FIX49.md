# Thaumcraft NeoForge 26.2 — fix49

Primera revisión visual con recursos originales de TC6: pergamino y libro abierto del Thaumonomicon, botones originales, marco de madera/tinta, ranuras de inventario originales e iconos de aspectos en la mesa arcana. Aplicado al libro, mesa arcana, horno alquímico, mesa de investigación y manipulador de focos.

Se reparan las referencias del guantelete básico/avanzado y modelos con foco: sus texturas originales se incluyen en el atlas de objetos moderno. Se completan las referencias de partículas de esos modelos y del lanzador de garfio. No se cambia su geometría.

Incluye la carta Trastear de fix48, documentada por separado. La prueba visual sin mundo vincula ahora el componente del pistón utilizado por su tooltip.

Límites: el libro mantiene su navegación actual por lista; no implementa todavía el árbol original de investigación. Esta entrega no certifica fidelidad de todos los bloques, entidades, animaciones ni interfaces aún sin portar. El recorrido de supervivencia sigue pendiente de prueba manual conectada.

Validación: cliente nativo con seis capturas revisadas; sin advertencias de texturas/referencias ausentes en modelos. Las diez pruebas requeridas del servidor pasan. La comprobación visual no abre un mundo ni sustituye la prueba manual de objetos sostenidos.
