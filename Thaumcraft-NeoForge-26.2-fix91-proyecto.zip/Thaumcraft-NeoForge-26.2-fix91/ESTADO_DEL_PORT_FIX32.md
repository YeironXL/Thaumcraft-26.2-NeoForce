# Thaumcraft NeoForge 26.2 — fix32

Interfaz funcional de los tres hornos alquímicos.

- Clic normal abre el inventario del horno, con material, combustible e inventario del jugador.
- La interfaz muestra destilación, tiempo de combustión, esencia almacenada (hasta 256) y rendimiento base de la variante: 80 %, 90 % o 95 %. Los valores proceden del servidor.
- Diseño adaptado con barras legibles y textos en español/inglés, coherente con la mesa arcana del port.
- Mayús/clic mueve objetos entre el inventario y el horno. Los combustibles tienen prioridad en su ranura; materiales con aspectos conocidos van a la entrada.
- Las ranuras rechazan objetos inválidos, incluidos intercambios con la barra rápida. Un inventario lleno no provoca pérdidas.
- El menú conserva acceso por proximidad y deja de ser válido al retirar el horno. Cerrar la interfaz conserva el inventario del bloque.
- Agacharse mantiene la interacción manual anterior: introducir/retirar material por arriba y combustible por los lados. Las reglas de automatización de fix31 se mantienen.
- Se guarda también la duración inicial del combustible para conservar su barra al cargar el mundo. Los guardados anteriores siguen siendo compatibles.
- Seis pruebas de servidor superadas: incluye tres variantes del menú, movimiento rápido, objetos inválidos, intercambio de barra rápida, inventario lleno y persistencia.
- Prueba de cliente con pantalla del horno en español y captura del menú, además de las comprobaciones anteriores de recursos/modelos e interfaces.
- Compilación de producción y regresiones de migración.

Los hornos siguen marcados como parciales: faltan accesorios, recetas de mejoras y aspectos derivados de todos los objetos. Esta entrega completa su interfaz dentro del alcance actual de la destilación.
