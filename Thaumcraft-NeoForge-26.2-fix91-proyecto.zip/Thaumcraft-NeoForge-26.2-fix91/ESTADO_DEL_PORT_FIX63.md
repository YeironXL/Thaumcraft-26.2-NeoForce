# Estado del port — fix63

La lectura del Thaumonomicon dibuja las ilustraciones IMG conservadas, con el recorte y la escala de los descriptores originales. Usa la normalización UV de 256 de GuiResearchPage, aunque el PNG tenga otra resolución. Migra las rutas textures/items y textures/blocks a las rutas actuales.

Texto e ilustraciones comparten la altura de la página: una imagen que no cabe pasa a la siguiente página; si supera el espacio total se reduce proporcionalmente. Se conserva la paginación explícita y la fuente serif aprobada. LINE y DIV recuperan los dos ornamentos del atlas original del libro.

Los descriptores inválidos, coordenadas fuera del atlas o escalas no finitas se omiten. Una textura ausente no se dibuja, sin mostrar el descriptor interno como prosa. Las recetas ilustradas y su interacción todavía están pendientes; no son lo mismo que las ilustraciones del texto.

La verificación revisa dimensiones de un recorte original, paginación, rechazo de NaN y una captura de THEORYRESEARCH en su segunda etapa usando una instantánea ficticia. No cambia investigación, costes ni reglas del servidor.

Validación: compilación de producción y migración aprobadas; cliente nativo verifica recorte, dimensiones, paginación y rechazo de escala NaN. Captura de THEORYRESEARCH inspeccionada: ilustración original de las cartas en la página derecha, con texto debajo sin solapamiento. Las diez pruebas requeridas del servidor pasaron en un universo nuevo.
