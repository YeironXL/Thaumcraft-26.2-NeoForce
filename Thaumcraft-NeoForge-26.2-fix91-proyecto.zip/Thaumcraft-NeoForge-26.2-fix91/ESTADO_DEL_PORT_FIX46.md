# Thaumcraft NeoForge 26.2 — fix46

Aspectos originales de palancas/pistones y comprobación de acceso a artificio con el jugador del recorrido.


## Fix46: fuentes de Machina y entrada continua a artificio

Palanca y pistón se añaden al mapa de aspectos derivados (17 entradas): adición original Machina5 a palanca y Machina10/Motus10 a pistón. La base de receta mantiene la fórmula75% y redondeo TC6; palanca queda Terra3/Machina5 (el Herba del palo se redondea a cero); pistón Herba6/Terra15/Perditio3/Metallum11/Potentia7 más las adiciones. No se añaden todavía todas las máquinas/recetas.

Para etiquetas modernas, el adaptador prefiere un ingrediente con aspectos explícitos o tablas de las seis maderas históricas; si no lo encuentra conserva el primer candidato. Es una adaptación de compatibilidad: TC6 empleaba el primer candidato histórico, mientras las etiquetas actuales incluyen materiales nuevos no cubiertos. No evalúa exhaustivamente todos los candidatos ni certifica aspectos de contenido moderno.

El mismo jugador del recorrido inicia UNLOCKARTIFICE tras metalurgia2, comprueba bloqueo sin descubrimiento Machine, ensambla una palanca por receta cargada, invoca ScanProgression con sus aspectos reales y completa el capítulo pagando16 observaciones Artifice. No concede manualmente ese capítulo. Sigue pendiente raycast/conexión real/obtención natural de todos los recursos. Diez pruebas requeridas pasan (`artifice-entry-server.log`). Los intentos previos ajustaron el esperado de Herba del palo conforme al redondeo original; no alteraron la fórmula para hacer pasar la prueba.
