# Thaumcraft NeoForge 26.2 — fix48

Carta Trastear: requisito de objeto conservado, puntuación original por aspectos, persistencia y traducciones.


## Fix48: carta Trastear de artificio

Se añade CardTinker con sus18 opciones originales de objeto, una inspiración, requisito de posesión que no consume el objeto y recompensa Artificio desde2×entero(sqrt(sumaAspectos)) hasta ese valor+10. La opción se guarda y transmite; la puntuación se vuelve a calcular en activación como el original. Aparece en el mazo normal tras UNLOCKARTIFICE completado. No añade todavía ayudas de yunque/mesa encantamiento ni las otras cartas de artificio. El cálculo depende de la cobertura parcial de aspectos del port: opciones aún sin aspectos reciben rango0–10 según la regla de entrada desconocida; eso no certifica todas sus puntuaciones originales.

Se mantiene compatibilidad de cartas guardadas: kind acepta0..15 y second0..17; las cartas anteriores conservan datos/efectos. En menú se transmite el índice de objeto en los datos reservados para el requisito. Tooltip y nombre localizados en español/inglés. Diez pruebas pasan (`tinker-full-server.log`): requisito sin cobro al faltar, objeto conservado, coste1, score14..24 para pistón en50 semillas, persistencia, activación única y puerta de categoría en200 semillas. Las15 cartas anteriores y los recorridos pasan.
