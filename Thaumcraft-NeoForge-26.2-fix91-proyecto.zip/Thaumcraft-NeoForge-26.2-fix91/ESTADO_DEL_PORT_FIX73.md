# Estado del port — fix73

Primeras páginas ilustradas de fabricación arcana en el Thaumonomicon. Botón Recetas dentro de una investigación accesible con una receta arcana de cuadrícula disponible en su etapa actual. Muestra ingredientes, resultado, seis tipos de cristal cuando corresponda y coste vis; navegación entre recetas y regreso al libro. Fuente serif aprobada conservada.

processResources copia las recetas del datapack a recursos del cliente: la página utiliza exactamente el JSON enviado en la compilación, sin catálogo duplicado mantenido manualmente. Resolución por identificador exacto; no convierte automáticamente los aliases del original. Referencias ausentes, recetas ilustrativas, grupos y tipos todavía no compatibles no producen páginas ficticias.

Atlas gui_researchbook_overlay.png original: cuadrícula UV112,15 y marco de resultado UV20,3, escala2, disposición de ingredientes/resultados/cristales/coste según GuiResearchPage.drawArcaneCraftingPage. Contenedor y controles adaptados a la pantalla actual. Solo ingredientes simples de las recetas migradas actuales; rotación de ingredientes, grupos, addenda desbloqueadas, fabricación normal, crisol, infusión y planos pendientes.

Compilación de producción y diez pruebas requeridas del servidor aprobadas. Prueba de cliente verifica etapa actual, omisión de referencias ausentes, costes del taumómetro de20 vis/seis cristales y regreso/reapertura del libro. Cliente final aprobado y captura inspeccionada tras ajustar la altura al tamaño de interfaz de427x240; título, coste y controles visibles. No certifica igualdad de todo el libro, servidor remoto con datapack modificado ni paridad funcional. La página es de consulta, no fabrica ni altera investigación.
