# Thaumcraft NeoForge 26.2 — fix24

Port en desarrollo de Thaumcraft 6.1.BETA26. Todavía no reproduce todo el contenido ni todo el comportamiento del mod original.

Esta revisión añade la mesa arcana, recetas, variantes de cristales, aura persistente, crisol y el inicio de la alquimia. Conserva las correcciones de investigación, creativo y modelos de las revisiones anteriores.

Requisitos: Minecraft 26.2, NeoForge 26.2.0.88 y Java 25. El wrapper de Gradle está incluido.

```bat
gradlew.bat build
gradlew.bat runClient
```

Para jugar, instalar el JAR generado en `build/libs` en la carpeta `mods`. `-PverifyUi` inicia un cliente de pruebas que captura pantallas y se cierra; no se usa para jugar.

Consultar `ESTADO_DEL_PORT_FIX24.md` para cambios, validación y límites. `docs/PLAN_DE_PORT_TC6.md` y `docs/AUDITORIA_TC6.json` inventarían la referencia original y el trabajo restante.

Los scripts `tools/port_*.py` ya se ejecutaron: los recursos generados están incluidos. Para regenerarlos a partir de la referencia se necesita el checkout comunitario como `../reference-tc6`. El proyecto se compila sin ese checkout.

Referencia histórica: [publicación de Azanor](https://www.curseforge.com/minecraft/mc-mods/thaumcraft/files/2629023). Referencia de código: [reconstrucción comunitaria](https://github.com/TheDarkTower314/Thaumcraft-6-Source-Code), commit `954022bb777b7546281fb36df8522f0ba6b43f81`. No es una publicación oficial del código de Azanor. Los recursos originales conservan sus derechos.
