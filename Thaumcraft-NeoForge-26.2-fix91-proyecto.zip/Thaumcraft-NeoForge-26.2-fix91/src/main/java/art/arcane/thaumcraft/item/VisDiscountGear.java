package art.arcane.thaumcraft.item;
public interface VisDiscountGear {int visDiscountPercent();}
