package art.arcane.thaumcraft.worldgen;

import art.arcane.thaumcraft.ModBlocks;
import art.arcane.thaumcraft.block.CrystalClusterBlock;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Primal crystals on cave stone; uses native world generation, never retroactively edits explored chunks. */
public final class VisCrystalFeature extends Feature<NoneFeatureConfiguration> {
    public VisCrystalFeature() { super(NoneFeatureConfiguration.CODEC); }
    @Override public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        var level = context.level(); var random = context.random(); var origin = context.origin();
        Block[] crystals = {ModBlocks.CRYSTAL_AER.get(),ModBlocks.CRYSTAL_TERRA.get(),ModBlocks.CRYSTAL_IGNIS.get(),
                ModBlocks.CRYSTAL_AQUA.get(),ModBlocks.CRYSTAL_ORDO.get(),ModBlocks.CRYSTAL_PERDITIO.get()};
        var block = crystals[random.nextInt(crystals.length)];
        for (int offset = 0; offset < 32; offset++) {
            var pos = origin.below(offset);
            if (pos.getY() <= level.getMinY()) break;
            if (!level.isEmptyBlock(pos)) continue;
            var faces = Direction.values();
            int first = random.nextInt(faces.length);
            for (int face=0;face<faces.length;face++) {
                var state = block.defaultBlockState().setValue(CrystalClusterBlock.FACING, faces[(first+face)%faces.length])
                        .setValue(CrystalClusterBlock.SIZE,random.nextInt(4));
                if (state.canSurvive(level,pos)) { level.setBlock(pos,state,2); return true; }
            }
        }
        return false;
    }
}
