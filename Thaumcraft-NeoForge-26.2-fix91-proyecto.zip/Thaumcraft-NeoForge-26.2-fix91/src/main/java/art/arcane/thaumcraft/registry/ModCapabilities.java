package art.arcane.thaumcraft.registry;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.transfer.item.VanillaContainerWrapper;

public final class ModCapabilities {
    public static void register(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.Item.BLOCK, ModBlockEntities.HUNGRY_CHEST.get(),
                (chest, side) -> VanillaContainerWrapper.of(chest));
        event.registerBlockEntity(Capabilities.Item.BLOCK, ModBlockEntities.ESSENTIA_SMELTER.get(),
                (smelter, side) -> side==null?VanillaContainerWrapper.of(smelter):new net.neoforged.neoforge.transfer.item.WorldlyContainerWrapper(smelter,side));
    }
    private ModCapabilities() {}
}
