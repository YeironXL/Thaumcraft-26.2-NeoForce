package art.arcane.thaumcraft;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.network.chat.Component;

@Mod(Thaumcraft.MOD_ID)
public final class Thaumcraft {
    public static final String MOD_ID = "thaumcraft";

    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("thaumcraft", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.thaumcraft"))
            .icon(() -> ModItems.AMBER.get().getDefaultInstance())
            .displayItems((params, output) -> CreativeInventory.populate(output)).build());

    public Thaumcraft(IEventBus bus) {
        art.arcane.thaumcraft.registry.ModComponents.register(bus);
        art.arcane.thaumcraft.registry.ModRecipes.register(bus);
        art.arcane.thaumcraft.registry.ModMenus.register(bus);
        art.arcane.thaumcraft.registry.ModWorldgen.register(bus);
        art.arcane.thaumcraft.registry.ModSounds.register(bus);
        art.arcane.thaumcraft.registry.ModEntities.register(bus);
        art.arcane.thaumcraft.registry.ModParticles.register(bus);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(art.arcane.thaumcraft.aura.NativeAura::tick);
        art.arcane.thaumcraft.progression.ProgressionEvents.register();
        art.arcane.thaumcraft.scan.DerivedAspectEvents.register();
        art.arcane.thaumcraft.registry.ModAttachments.register(bus);
        bus.addListener(art.arcane.thaumcraft.network.ResearchNetworking::register);
        bus.addListener(art.arcane.thaumcraft.registry.ModCapabilities::register);
        ModBlocks.register(bus);
        ModItems.register(bus);
        art.arcane.thaumcraft.registry.ModBlockEntities.register(bus);
        TABS.register(bus);
    }
}
