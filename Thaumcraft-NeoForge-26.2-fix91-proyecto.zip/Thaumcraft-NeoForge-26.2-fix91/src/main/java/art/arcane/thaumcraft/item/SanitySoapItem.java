package art.arcane.thaumcraft.item;

import art.arcane.thaumcraft.ModBlocks;
import art.arcane.thaumcraft.progression.PlayerProgressManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.level.Level;

/** Legacy-shaped sanity soap use: clears temporary warp and may reduce normal warp. */
public final class SanitySoapItem extends Item {
    private static final int USE_DURATION_TICKS = 200;

    public SanitySoapItem(Item.Properties properties) {
        super(properties.stacksTo(16));
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return USE_DURATION_TICKS;
    }

    @Override
    public ItemUseAnimation getUseAnimation(ItemStack stack) {
        return ItemUseAnimation.BLOCK;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResult.CONSUME;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity livingEntity) {
        if (!(livingEntity instanceof ServerPlayer player)) {
            return stack;
        }

        float chance = 0.33F;
        if (level.getBlockState(player.blockPosition()).is(ModBlocks.PURIFYING_FLUID.get())) {
            chance += 0.25F;
        }

        PlayerProgressManager.addWarp(player, PlayerProgressManager.WarpType.TEMPORARY,
                -PlayerProgressManager.getWarp(player, PlayerProgressManager.WarpType.TEMPORARY));
        int normal = PlayerProgressManager.getWarp(player, PlayerProgressManager.WarpType.NORMAL);
        if (normal > 0 && level.getRandom().nextFloat() < chance) {
            PlayerProgressManager.addWarp(player, PlayerProgressManager.WarpType.NORMAL, -1);
        }

        level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_SPLASH, SoundSource.PLAYERS, 0.35F, 1.0F);
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return stack;
    }
}
