package art.arcane.thaumcraft.scan;
import java.util.*;
import art.arcane.thaumcraft.network.AspectSnapshotPayload;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;
public final class DerivedAspectEvents{
    public static Map<String,Map<String,Integer>> rebuild(net.minecraft.server.MinecraftServer server){
        var graph=NativeRecipeAspectGraph.build(server.getRecipeManager());var targets=new ArrayList<>(List.of("minecraft:book","minecraft:glass_bottle","minecraft:bucket","minecraft:bowl","minecraft:chest","minecraft:furnace","minecraft:lever","minecraft:piston","minecraft:arrow","minecraft:paper","minecraft:crafting_table","minecraft:bookshelf","minecraft:torch","minecraft:stick","minecraft:iron_nugget","minecraft:gold_nugget","thaumcraft:arcane_workbench"));
        for(String wood:List.of("oak","spruce","birch","jungle","acacia","dark_oak"))targets.add("minecraft:"+wood+"_planks");
        var values=new LinkedHashMap<String,Map<String,Integer>>();for(var target:targets){var tags=graph.get(target);if(!tags.isEmpty())values.put(target,tags);}ScanRegistry.installDerived(values);return values;
    }
    public static void register(){
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.OnDatapackSyncEvent event)->{var payload=AspectSnapshotPayload.of(rebuild(event.getPlayerList().getServer()));if(event.getPlayer()!=null)PacketDistributor.sendToPlayer(event.getPlayer(),payload);else for(var player:event.getPlayerList().getPlayers())PacketDistributor.sendToPlayer(player,payload);});
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.server.ServerStoppedEvent event)->ScanRegistry.clearDerived());
    }
    private DerivedAspectEvents(){}
}

