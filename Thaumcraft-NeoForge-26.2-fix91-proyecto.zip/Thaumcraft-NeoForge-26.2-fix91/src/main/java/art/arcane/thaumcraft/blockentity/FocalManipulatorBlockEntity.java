package art.arcane.thaumcraft.blockentity;

import art.arcane.thaumcraft.ModItems;
import art.arcane.thaumcraft.focus.*;
import art.arcane.thaumcraft.registry.ModBlockEntities;
import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.*;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.*;

public final class FocalManipulatorBlockEntity extends RandomizableContainerBlockEntity {
    private NonNullList<ItemStack> items = NonNullList.withSize(1, ItemStack.EMPTY);
    private FocusCraftingJob job;
    private int elapsed;
    public FocalManipulatorBlockEntity(BlockPos pos, BlockState state) { super(ModBlockEntities.FOCAL_MANIPULATOR.get(), pos, state); }
    @Override public int getContainerSize() { return 1; }
    @Override protected NonNullList<ItemStack> getItems() { return items; }
    @Override protected void setItems(NonNullList<ItemStack> value) { items = value; }
    @Override protected Component getDefaultName() { return Component.translatable("block.thaumcraft.wand_workbench"); }
    @Override protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
        return new art.arcane.thaumcraft.menu.FocalManipulatorMenu(id,inventory,this,new net.minecraft.world.inventory.ContainerData(){
            private final int[] parameters={0,1,0};
            public int get(int index){if(index<3)return job!=null&&index>0?(index==1?job.focus().power():job.focus().duration()):parameters[index];return switch(index){case 3->job==null?0:job.remainingVis();case 4->job==null?0:job.focus().craftingVis();default->working()?1:0;};}
            public void set(int index,int value){if(index<3)parameters[index]=value;}public int getCount(){return 6;}
        });
    }
    public FocusCraftingJob job() { return job; }
    public boolean working() { return job != null; }
    @Override public boolean canPlaceItem(int slot, ItemStack stack) { return slot == 0 && !working() && stack.is(ModItems.FOCUS_1.get()) && stack.getCount() == 1; }
    @Override public void setItem(int slot, ItemStack stack) { if (!working() && slot == 0 && (stack.isEmpty() || canPlaceItem(slot, stack))) super.setItem(slot, stack); }
    @Override public ItemStack removeItem(int slot, int amount) { return working() ? ItemStack.EMPTY : super.removeItem(slot, amount); }
    @Override public ItemStack removeItemNoUpdate(int slot) { return working() ? ItemStack.EMPTY : super.removeItemNoUpdate(slot); }
    @Override public void clearContent() { if (!working()) super.clearContent(); }
    public boolean start(ServerPlayer player, TouchFireFocus configuration) {
        if (working() || level == null || player.level() != level || !stillValid(player)) return false;
        var started = FocusCraftingJob.start(player, getItem(0), configuration);
        if (started.isEmpty()) return false;
        job = started.get(); elapsed = 0; setChanged(); return true;
    }
    public static void tick(Level level, BlockPos pos, BlockState state, FocalManipulatorBlockEntity table) {
        if (!(level instanceof ServerLevel server) || table.job == null) return;
        if (!table.getItem(0).is(ModItems.FOCUS_1.get()) || table.getItem(0).getCount() != 1) {
            table.job = null; table.elapsed = 0; table.setChanged(); return;
        }
        if(server.getGameTime()%5==0){
            var visualRandom=java.util.concurrent.ThreadLocalRandom.current();
            server.sendParticles(art.arcane.thaumcraft.registry.ModParticles.FOCAL_CRAFT.get(),
                pos.getX()+0.5+(visualRandom.nextFloat()-visualRandom.nextFloat())*0.3,
                pos.getY()+1.4+(visualRandom.nextFloat()-visualRandom.nextFloat())*0.3,
                pos.getZ()+0.5+(visualRandom.nextFloat()-visualRandom.nextFloat())*0.3,1,0,0,0,0);
        }
        table.elapsed++;
        if (table.elapsed < 20) { table.setChanged(); return; }
        table.elapsed = 0; table.job = table.job.drain(server, pos);
        if (table.job.complete() && table.job.apply(table.getItem(0))) table.job = null;
        table.setChanged();
    }
    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output); ContainerHelper.saveAllItems(output, items);
        output.putInt("elapsed", elapsed); if (job != null) output.store("focus_job", FocusCraftingJob.CODEC, job);
    }
    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input); items = NonNullList.withSize(1, ItemStack.EMPTY); ContainerHelper.loadAllItems(input, items);
        elapsed = Math.clamp(input.getIntOr("elapsed", 0), 0, 19);
        job = input.read("focus_job", FocusCraftingJob.CODEC).orElse(null);
        if (!getItem(0).is(ModItems.FOCUS_1.get()) || getItem(0).getCount() != 1) job = null;
    }
}
