package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.research.ResearchCatalog;
import art.arcane.thaumcraft.research.LegacyItemReferences;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.HashMap;
import java.util.Map;

/** Authored node shapes and cycling icons from TC6's research browser atlas. */
final class ResearchNodeButton extends Button {
    private static final Identifier ATLAS=Identifier.parse("thaumcraft:textures/gui/gui_research_browser.png");
    private static final Identifier UNKNOWN=Identifier.parse("thaumcraft:textures/aspects/_unknown.png");
    private static final Map<Identifier,int[]> SIZES=new HashMap<>();
    final ResearchCatalog.Entry entry;
    private final boolean unlocked,complete;
    ResearchNodeButton(ResearchCatalog.Entry entry,boolean unlocked,boolean complete,OnPress action){
        super(Button.builder(ThaumcraftTheme.ink(Component.translatable(entry.name())),action).bounds(0,0,32,32));
        this.entry=entry;this.unlocked=unlocked;this.complete=complete;
        setTooltip(Tooltip.create(ThaumcraftTheme.ink(Component.translatable(entry.name()).append("\n").append(Component.translatable(complete?"screen.thaumcraft.completed":unlocked?"screen.thaumcraft.incomplete":"screen.thaumcraft.locked")))));
    }
    @Override protected void extractContents(GuiGraphicsExtractor g,int mouseX,int mouseY,float tick){
        int u=entry.meta().contains("ROUND")?144:entry.meta().contains("HEX")?112:80;
        int v=entry.meta().contains("HIDDEN")?80:48;
        int shade=complete?255:unlocked?(int)(255*(Math.sin(net.minecraft.util.Util.getMillis()%600/600.0*Math.PI*2)*0.25+0.75)):77;
        int tint=0xFF000000|(shade<<16)|(shade<<8)|shade;
        g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,getX(),getY(),u,v,32,32,256,256,tint);
        if(entry.meta().contains("SPIKY"))g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,getX(),getY(),176,v,32,32,256,256,tint);
        drawIcon(g,tint);
    }
    private void drawIcon(GuiGraphicsExtractor g,int tint){
        var node=ResearchMapData.node(entry.key());
        if(node==null||node.icons().isEmpty()){texture(g,UNKNOWN,tint);return;}
        String raw=node.icons().get((int)((net.minecraft.util.Util.getMillis()/1000)%node.icons().size()));
        Identifier texture=null;
        if(raw.contains("textures/")&&raw.endsWith(".png"))texture=Identifier.tryParse(raw.replace("textures/items/","textures/item/").replace("textures/blocks/","textures/block/"));
        else if(raw.startsWith("focus:"))texture=Identifier.parse("thaumcraft:textures/foci/"+raw.substring(raw.lastIndexOf('.')+1).toLowerCase(java.util.Locale.ROOT)+".png");
        else{
            String resolved=LegacyItemReferences.item(raw);
            Identifier id=Identifier.tryParse(resolved);
            if(id!=null){
                var item=BuiltInRegistries.ITEM.getValue(id);
                // Native GUI item extraction accepts a null level, including title-screen previews.
                if(item!=null&&item!=Items.AIR){g.item(new ItemStack(item),getX()+8,getY()+8);return;}
                texture=Identifier.fromNamespaceAndPath(id.getNamespace(),"textures/item/"+id.getPath()+".png");
            }
        }
        if(texture==null||Minecraft.getInstance().getResourceManager().getResource(texture).isEmpty())texture=UNKNOWN;
        texture(g,texture,tint);
    }
    private void texture(GuiGraphicsExtractor g,Identifier texture,int tint){
        int[] size=SIZES.computeIfAbsent(texture,id->{
            try(var stream=Minecraft.getInstance().getResourceManager().open(id);var input=new java.io.DataInputStream(stream)){
                input.skipNBytes(16);return new int[]{input.readInt(),input.readInt()};
            }catch(java.io.IOException exception){return new int[]{32,32};}
        });
        // Research image strips use square animation frames in the original.
        int square=Math.min(size[0],size[1]);
        int frames=Math.max(size[0],size[1])/Math.max(1,square);
        int frame=(int)((net.minecraft.util.Util.getMillis()/150)%Math.max(1,frames));
        g.blit(RenderPipelines.GUI_TEXTURED,texture,getX()+8,getY()+8,size[0]>size[1]?frame*square:0,size[1]>size[0]?frame*square:0,16,16,square,square,size[0],size[1],tint);
    }
}
