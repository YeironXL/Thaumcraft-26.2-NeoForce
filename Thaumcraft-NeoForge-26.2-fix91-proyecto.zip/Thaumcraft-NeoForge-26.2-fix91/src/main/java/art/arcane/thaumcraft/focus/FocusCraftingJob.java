package art.arcane.thaumcraft.focus;

import art.arcane.thaumcraft.ModItems;
import art.arcane.thaumcraft.aura.NativeAura;
import art.arcane.thaumcraft.progression.PlayerProgressManager;
import art.arcane.thaumcraft.registry.ModComponents;
import art.arcane.thaumcraft.research.ResearchItemCosts;
import art.arcane.thaumcraft.research.ResearchRules;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import java.util.Map;
import java.util.Optional;

/** Paid, resumable lesser-focus work. The manipulator must keep its input locked until completion. */
public record FocusCraftingJob(TouchFireFocus focus, int remainingVis) {
    private record Saved(TouchFireFocus focus, int remaining) {}
    private static final Codec<Saved> SAVED = RecordCodecBuilder.create(instance -> instance.group(
            TouchFireFocus.CODEC.fieldOf("focus").forGetter(Saved::focus),
            Codec.intRange(0, 153).fieldOf("remaining_vis").forGetter(Saved::remaining)
    ).apply(instance, Saved::new));
    public static final Codec<FocusCraftingJob> CODEC = SAVED.comapFlatMap(saved ->
            saved.remaining() > saved.focus().craftingVis()
                    ? DataResult.error(() -> "Remaining vis exceeds focus crafting cost")
                    : DataResult.success(new FocusCraftingJob(saved.focus(), saved.remaining())),
            job -> new Saved(job.focus(), job.remainingVis()));

    public FocusCraftingJob {
        if (focus == null || remainingVis < 0 || remainingVis > focus.craftingVis())
            throw new IllegalArgumentException("Invalid focus crafting progress");
    }

    public static Optional<FocusCraftingJob> start(ServerPlayer player, ItemStack input, TouchFireFocus focus) {
        if (!input.is(ModItems.FOCUS_1.get()) || input.getCount() != 1
                || !ResearchRules.complete(PlayerProgressManager.get(player), "BASEAUROMANCY"))
            return Optional.empty();
        Map<String, Integer> crystals = Map.of("thaumcraft:crystal_essence@aversio", 1,
                "thaumcraft:crystal_essence@ignis", 1);
        boolean creative = player.isCreative();
        if ((!creative && player.experienceLevel < focus.craftingLevels())
                || !ResearchItemCosts.has(player.getInventory(), crystals)) return Optional.empty();
        // Verify all costs before modifying either resource; TC6 also consumes crystals in creative.
        if (!ResearchItemCosts.consume(player.getInventory(), crystals)) return Optional.empty();
        if (!creative) player.giveExperienceLevels(-focus.craftingLevels());
        return Optional.of(new FocusCraftingJob(focus, focus.craftingVis()));
    }

    /** Call once every 20 server ticks, matching the original manipulator's drain rate. */
    public FocusCraftingJob drain(ServerLevel level, BlockPos position) {
        int amount = Math.min(20, Math.min(remainingVis, NativeAura.available(level, position)));
        return amount > 0 && NativeAura.spend(level, position, amount)
                ? new FocusCraftingJob(focus, remainingVis - amount) : this;
    }

    public boolean complete() { return remainingVis == 0; }
    public boolean apply(ItemStack lockedInput) {
        if (!complete() || !lockedInput.is(ModItems.FOCUS_1.get()) || lockedInput.getCount() != 1) return false;
        lockedInput.set(ModComponents.TOUCH_FIRE_FOCUS.get(), focus);
        return true;
    }
}
