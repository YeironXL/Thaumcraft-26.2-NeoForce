package art.arcane.thaumcraft.focus;
import art.arcane.thaumcraft.aura.NativeAura;
import art.arcane.thaumcraft.item.CasterGauntletItem;
import art.arcane.thaumcraft.registry.ModComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import java.util.Map;
import java.util.WeakHashMap;
public final class TouchFireCasting {
    private static final Map<ServerPlayer,Long> COOLDOWN=new WeakHashMap<>();
    public static InteractionResult cast(ServerPlayer player,InteractionHand hand){
        var stack=CasterGauntletItem.equipped(player.getItemInHand(hand));var focus=stack.get(ModComponents.TOUCH_FIRE_FOCUS.get());
        if(focus==null)return InteractionResult.PASS;
        var world=player.level();long now=world.getGameTime();
        if(COOLDOWN.getOrDefault(player,Long.MIN_VALUE)>now)return InteractionResult.FAIL;
        // TC6 applies cooldown even when the aura payment subsequently fails.
        COOLDOWN.put(player,now+focus.cooldownTicks());
        if(!NativeAura.spendLocal(world,player.blockPosition(),focus.castingVis()*VisDiscounts.multiplier(player)))return InteractionResult.FAIL;
        var from=player.getEyePosition();var to=from.add(player.getLookAngle().scale(player.blockInteractionRange()));
        var block=world.clip(new ClipContext(from,to,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player));
        if(block.getType()!=HitResult.Type.MISS)to=block.getLocation();
        var entity=ProjectileUtil.getEntityHitResult(world,player,from,to,player.getBoundingBox().expandTowards(to.subtract(from)).inflate(1),e->e.isPickable()&&!e.isSpectator(),0.25f);
        var impact=entity==null?block.getLocation():entity.getLocation();
        if(entity!=null&&!entity.getEntity().fireImmune()){
            var source=new DamageSource(world.registryAccess().lookupOrThrow(Registries.DAMAGE_TYPE).getOrThrow(DamageTypes.FIREBALL),player,player);
            entity.getEntity().hurtServer(world,source,focus.damage());entity.getEntity().igniteForSeconds(focus.fireSeconds());
        }else if(entity==null&&block.getType()==HitResult.Type.BLOCK&&focus.duration()>0){
            var position=block.getBlockPos().relative(block.getDirection());
            if(world.isEmptyBlock(position)&&player.mayUseItemAt(position,block.getDirection(),player.getItemInHand(hand)))world.setBlockAndUpdate(position,Blocks.FIRE.defaultBlockState());
        }
        world.sendParticles(art.arcane.thaumcraft.registry.ModParticles.FOCUS_FIRE.get(),impact.x,impact.y,impact.z,8,0.12,0.12,0.12,0.025);
        world.playSound(null,player.blockPosition(),net.minecraft.sounds.SoundEvents.FIRECHARGE_USE,net.minecraft.sounds.SoundSource.PLAYERS,1,1);
        return InteractionResult.SUCCESS;
    }
    private TouchFireCasting(){}
}
