package art.arcane.thaumcraft.focus;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Map;

/** First supported TC6 graph: root -> touch -> fire. Other graphs remain unported. */
public record TouchFireFocus(int power, int duration) {
    public static final int MAX_COMPLEXITY = 15;
    public TouchFireFocus {
        if (power < 1 || power > 5 || duration < 0 || duration > 5
                || 2 + power * 2 + duration > MAX_COMPLEXITY) {
            throw new IllegalArgumentException("Invalid lesser touch/fire focus settings");
        }
    }

    // Validate before invoking the constructor, so malformed saved/network data yields a codec error.
    public static final Codec<TouchFireFocus> CODEC = Codec.INT.listOf().comapFlatMap(values -> {
        if (values.size() != 2) return DataResult.error(() -> "Expected power and duration");
        int power = values.get(0), duration = values.get(1);
        if (power < 1 || power > 5 || duration < 0 || duration > 5
                || 2 + power * 2 + duration > MAX_COMPLEXITY)
            return DataResult.error(() -> "Invalid lesser touch/fire focus settings");
        return DataResult.success(new TouchFireFocus(power, duration));
    }, focus -> java.util.List.of(focus.power(), focus.duration()));

    public int complexity() { return 2 + power * 2 + duration; }
    public float castingVis() { return complexity() / 5.0f; }
    public int cooldownTicks() { return Math.max(5, complexity() / 5 * (complexity() / 4)); }
    public int craftingVis() { return complexity() * 10 + MAX_COMPLEXITY / 5; }
    public int craftingLevels() { return Math.max(1, (int) Math.round(Math.sqrt(complexity()))); }
    public float damage() { return 3 + power; }
    public int fireSeconds() { return 1 + duration * duration; }
    public Map<String, Integer> crystals() { return Map.of("aversio", 1, "ignis", 1); }
}
