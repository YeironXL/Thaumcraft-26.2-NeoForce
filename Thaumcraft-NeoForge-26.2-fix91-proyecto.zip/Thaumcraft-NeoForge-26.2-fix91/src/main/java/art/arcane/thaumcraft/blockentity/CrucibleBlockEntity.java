package art.arcane.thaumcraft.blockentity;

import art.arcane.thaumcraft.aura.NativeAura;
import art.arcane.thaumcraft.block.CrucibleBlock;
import art.arcane.thaumcraft.crafting.AlchemyMixture;
import art.arcane.thaumcraft.item.CrystalEssenceItem;
import art.arcane.thaumcraft.progression.PlayerProgressManager;
import art.arcane.thaumcraft.registry.ModBlockEntities;
import art.arcane.thaumcraft.registry.ModRecipes;
import art.arcane.thaumcraft.research.ResearchRules;
import art.arcane.thaumcraft.scan.ScanRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import java.util.LinkedHashMap;
import java.util.Map;

public final class CrucibleBlockEntity extends BlockEntity {
    private AlchemyMixture mixture=new AlchemyMixture();
    private long lastSound=Long.MIN_VALUE;
    public CrucibleBlockEntity(BlockPos pos,BlockState state) { super(ModBlockEntities.CRUCIBLE.get(),pos,state); }
    public AlchemyMixture mixture() { return mixture; }
    @Override protected void saveAdditional(ValueOutput output) { super.saveAdditional(output); output.store("mixture",AlchemyMixture.CODEC.codec(),mixture); }
    @Override protected void loadAdditional(ValueInput input) { super.loadAdditional(input); mixture=input.read("mixture",AlchemyMixture.CODEC.codec()).orElseGet(AlchemyMixture::new);
        if(level!=null&&level.isClientSide())level.sendBlockUpdated(worldPosition,getBlockState(),getBlockState(),3);
    }
    @Override public net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket getUpdatePacket(){return net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket.create(this);}
    @Override public net.minecraft.nbt.CompoundTag getUpdateTag(net.minecraft.core.HolderLookup.Provider registries){return saveWithoutMetadata(registries);}
    public void changed() {
        setChanged();
        if (level instanceof ServerLevel world) {
            int water=(int)Math.ceil(mixture.water()/250D);
            if (getBlockState().getValue(CrucibleBlock.WATER) != water) world.setBlock(worldPosition,getBlockState().setValue(CrucibleBlock.WATER,water),3);
            else world.sendBlockUpdated(worldPosition,getBlockState(),getBlockState(),3);
        }
    }
    public void empty() { pollute(mixture.empty()); changed(); sound("spill"); }
    private void sound(String id) {
        if (level instanceof ServerLevel world && lastSound != world.getGameTime()) {
            lastSound=world.getGameTime();
            world.playSound(null,worldPosition,art.arcane.thaumcraft.registry.ModSounds.get(id),net.minecraft.sounds.SoundSource.BLOCKS,0.2F,1F);
        }
    }
    private void pollute(float amount) {
        if (amount > 0 && level instanceof ServerLevel world) {
            var chunk=world.getChunkAt(worldPosition); NativeAura.get(world,chunk).addFlux(amount); chunk.markUnsaved();
        }
    }
    @Override public void preRemoveSideEffects(BlockPos pos,BlockState state) { pollute(mixture.empty()); super.preRemoveSideEffects(pos,state); }
    public static void tick(net.minecraft.world.level.Level level,BlockPos pos,BlockState state,CrucibleBlockEntity crucible) {
        if(level.isClientSide()){
            if(crucible.mixture.water()<=0||crucible.mixture.total()<=0)return;
            var visual=java.util.concurrent.ThreadLocalRandom.current();
            if(crucible.mixture.overflowing())for(int n=0;n<2;n++){
                var overflow=art.arcane.thaumcraft.registry.ModParticles.CRUCIBLE_OVERFLOW.get();
                level.addParticle(overflow,pos.getX(),pos.getY()+1,pos.getZ()+visual.nextDouble(),0,0,0);
                level.addParticle(overflow,pos.getX()+1,pos.getY()+1,pos.getZ()+visual.nextDouble(),0,0,0);
                level.addParticle(overflow,pos.getX()+visual.nextDouble(),pos.getY()+1,pos.getZ(),0,0,0);
                level.addParticle(overflow,pos.getX()+visual.nextDouble(),pos.getY()+1,pos.getZ()+1,0,0,0);
            }
            if(visual.nextInt(6)!=0)return;
            var tags=java.util.List.copyOf(crucible.mixture.aspects().keySet());if(tags.isEmpty())return;
            int color=0xFF000000|art.arcane.thaumcraft.aspect.AspectRegistry.color(tags.get(visual.nextInt(tags.size())));
            double surface=.3+Math.ceil(crucible.mixture.water()/250D)*.125;
            level.addParticle(net.minecraft.core.particles.ColorParticleOption.create(art.arcane.thaumcraft.registry.ModParticles.CRUCIBLE_ASPECT_BUBBLE.get(),color),
                pos.getX()+(5+visual.nextInt(22))/32D+.015625,pos.getY()+surface+.05,pos.getZ()+(5+visual.nextInt(22))/32D+.015625,0,0,0);
            return;
        }
        if (!(level instanceof ServerLevel world)) return;
        var below=world.getBlockState(pos.below());
        var id=BuiltInRegistries.BLOCK.getKey(below.getBlock());
        boolean heated=below.is(Blocks.LAVA)||below.is(Blocks.FIRE)||below.is(Blocks.SOUL_FIRE)||below.is(Blocks.MAGMA_BLOCK)
                ||id.getNamespace().equals("thaumcraft")&&id.getPath().startsWith("nitor_")
                ||below.getBlock() instanceof CampfireBlock&&below.getValue(CampfireBlock.LIT);
        int before=crucible.mixture.heat(); boolean wasBoiling=crucible.mixture.boiling(); crucible.mixture.heatTick(heated);
        long tags=crucible.mixture.total(); crucible.pollute(crucible.mixture.tickSpill(world.getRandom().nextInt()));
        if(tags != crucible.mixture.total()||wasBoiling!=crucible.mixture.boiling())crucible.changed();
        else if(before != crucible.mixture.heat())crucible.setChanged();
        if (world.getGameTime()%5 != 0 || !crucible.mixture.boiling()) return;
        // Use the visible water model's surface; empty/cold cauldrons never emit froth.
        double surface=0.3+Math.ceil(crucible.mixture.water()/250D)*0.125;
        var visualRandom=java.util.concurrent.ThreadLocalRandom.current();
        world.sendParticles(art.arcane.thaumcraft.registry.ModParticles.CRUCIBLE_FROTH.get(),
                pos.getX()+0.2+visualRandom.nextDouble()*0.6,pos.getY()+surface,
                pos.getZ()+0.2+visualRandom.nextDouble()*0.6,1,0,0,0,0);
        for (var entity : world.getEntitiesOfClass(ItemEntity.class,new AABB(pos).deflate(0.12).move(0,0.15,0),
                item -> !item.getPersistentData().getBoolean("thaumcraft:crucible_output").orElse(false))) {
            var stack=entity.getItem();
            var actor=entity.getOwner() instanceof ServerPlayer player ? player : null;
            while (!stack.isEmpty() && crucible.processOne(stack,actor)) stack.shrink(1);
            if (stack.isEmpty()) entity.discard(); else entity.setItem(stack);
        }
    }
    /** Returns true only after one catalyst or one dissolvable input has been committed. */
    public boolean processOne(ItemStack stack,ServerPlayer player) {
        if (!(level instanceof ServerLevel world) || stack.isEmpty() || !mixture.boiling()) return false;
        var input=new SingleRecipeInput(stack);
        var recipe=player==null?null:art.arcane.thaumcraft.crafting.CrucibleRecipe.select(
                world.getServer().getRecipeManager().recipeMap().byType(ModRecipes.CRUCIBLE_TYPE.get()).stream().map(holder->holder.value()).toList(),
                candidate->candidate.matches(input,world)&&ResearchRules.knows(PlayerProgressManager.get(player),candidate.research())&&mixture.canPay(candidate.aspects()));
        if(recipe!=null){
            var result=recipe.assemble(input);
            if (result.isEmpty() || !mixture.pay(recipe.aspects())) return false;
            changed();
            var output=new ItemEntity(world,worldPosition.getX()+0.5,worldPosition.getY()+1.2,worldPosition.getZ()+0.5,result);
            output.setDeltaMovement(0,0.15,0); output.setDefaultPickUpDelay();
            output.getPersistentData().putBoolean("thaumcraft:crucible_output",true);
            world.addFreshEntity(output);
            sound("spill");
            PlayerProgressManager.get(player).recordCraft(BuiltInRegistries.ITEM.getKey(result.getItem()).toString());
            return true;
        }
        Map<String,Integer> tags=new LinkedHashMap<>();
        String aspect=CrystalEssenceItem.aspect(stack);
        if (!aspect.isEmpty()) tags.put(aspect,1);
        else ScanRegistry.get(BuiltInRegistries.ITEM.getKey(stack.getItem()).toString()).forEach((tag,count) -> tags.put(tag.id(),count));
        if (!mixture.dissolve(tags)) return false;
        changed(); sound("bubble"); return true;
    }
}
