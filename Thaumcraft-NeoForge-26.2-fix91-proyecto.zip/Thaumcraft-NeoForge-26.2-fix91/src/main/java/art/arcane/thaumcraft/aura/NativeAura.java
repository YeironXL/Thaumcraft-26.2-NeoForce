package art.arcane.thaumcraft.aura;

import art.arcane.thaumcraft.ModBlocks;
import art.arcane.thaumcraft.registry.ModAttachments;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/** Main-thread, dimension-isolated chunk attachments; never creates chunks to drain aura. */
public final class NativeAura {
    private static final Map<ServerLevel, Set<net.minecraft.world.level.ChunkPos>> ACTIVE = new WeakHashMap<>();
    public static ChunkAura get(ServerLevel level, LevelChunk chunk) {
        var aura = chunk.getData(ModAttachments.AURA.get());
        ACTIVE.computeIfAbsent(level, ignored -> new java.util.HashSet<>()).add(chunk.getPos());
        if (aura.base() < 0) {
            var pos = new BlockPos(chunk.getPos().x() * 16 + 8, 50, chunk.getPos().z() * 16 + 8);
            double life = modifier(level.getBiome(pos));
            for (var direction : net.minecraft.core.Direction.Plane.HORIZONTAL) life += modifier(level.getBiome(pos.relative(direction,16)));
            var random = new java.util.Random(level.getSeed() ^ net.minecraft.world.level.ChunkPos.pack(chunk.getPos().x(), chunk.getPos().z()));
            aura.initialize((int)(life / 5 * 500 * (1 + random.nextGaussian() * 0.1)));
            chunk.markUnsaved();
        }
        return aura;
    }
    private static double modifier(Holder<Biome> biome) {
        double total = 0; int count = 0;
        if (biome.is(BiomeTags.IS_OCEAN)) { total += 0.33; count++; }
        if (biome.is(BiomeTags.IS_RIVER)) { total += 0.4; count++; }
        if (biome.is(BiomeTags.IS_FOREST)) { total += 0.5; count++; }
        if (biome.is(BiomeTags.IS_TAIGA)) { total += 0.33; count++; }
        if (biome.is(BiomeTags.IS_JUNGLE)) { total += 0.6; count++; }
        if (biome.is(BiomeTags.IS_BEACH)) { total += 0.3; count++; }
        if (biome.is(BiomeTags.IS_SAVANNA)) { total += 0.25; count++; }
        if (biome.is(BiomeTags.IS_BADLANDS)) { total += 0.33; count++; }
        if (biome.is(BiomeTags.IS_NETHER)) { total += 0.125; count++; }
        if (biome.value().getBaseTemperature() < 0.2) { total += 0.25; count++; }
        return count == 0 ? 0.5 : total / count;
    }
    private static List<LevelChunk> sources(ServerLevel level, BlockPos pos) {
        var result = new ArrayList<LevelChunk>();
        int radius = level.getBlockState(pos.above()).is(ModBlocks.ARCANE_WORKBENCH_CHARGER.get()) ? 1 : 0;
        for (int x = -radius; x <= radius; x++) for (int z = -radius; z <= radius; z++) {
            var chunk = level.getChunkSource().getChunkNow((pos.getX() >> 4) + x, (pos.getZ() >> 4) + z);
            if (chunk != null) result.add(chunk);
        }
        return result;
    }
    /** Basic gauntlets draw fractional vis from only the caster's already loaded chunk. */
    public static boolean spendLocal(ServerLevel level, BlockPos pos, float amount) {
        if (!Float.isFinite(amount) || amount < 0) return false;
        var chunk=level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4);
        if(chunk==null || !get(level,chunk).spend(amount))return false;
        if(amount>0)chunk.markUnsaved();return true;
    }
    public static int available(ServerLevel level, BlockPos pos) {
        return sources(level,pos).stream().mapToInt(chunk -> (int)get(level,chunk).vis()).sum();
    }
    public static boolean spend(ServerLevel level, BlockPos pos, int amount) {
        if (amount < 0) return false;
        var chunks = sources(level,pos);
        if (chunks.stream().mapToInt(chunk -> (int)get(level,chunk).vis()).sum() < amount) return false;
        int remaining = amount;
        for (var chunk : chunks) {
            var aura = get(level,chunk);
            int moved = Math.min(remaining,(int)aura.vis());
            if (moved > 0) { aura.spend(moved); chunk.markUnsaved(); remaining -= moved; }
        }
        return remaining == 0;
    }
    public static void tick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level) || level.getGameTime() % 20 != 0) return;
        var positions = ACTIVE.get(level);
        if (positions == null) return;
        for (var pos : positions) {
            var chunk = level.getChunkSource().getChunkNow(pos.x(),pos.z());
            if (chunk == null) continue;
            var aura = chunk.getData(ModAttachments.AURA.get());
            float before = aura.vis();
            int phase = level.environmentAttributes().getValue(net.minecraft.world.attribute.EnvironmentAttributes.MOON_PHASE,
                    new BlockPos(pos.x() * 16 + 8,50,pos.z() * 16 + 8)).ordinal();
            aura.regenerate(phase);
            if (aura.vis() != before) chunk.markUnsaved();
        }
    }
    private NativeAura() {}
}
