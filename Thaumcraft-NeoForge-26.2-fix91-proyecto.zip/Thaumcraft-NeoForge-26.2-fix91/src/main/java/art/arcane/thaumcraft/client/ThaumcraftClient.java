package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.Thaumcraft;
import art.arcane.thaumcraft.network.ResearchSnapshotPayload;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.network.event.RegisterClientPayloadHandlersEvent;

@Mod(value = Thaumcraft.MOD_ID, dist = Dist.CLIENT)
public final class ThaumcraftClient {
    public ThaumcraftClient(IEventBus bus) {
        bus.addListener(ThaumcraftClient::registerPayloads);
        bus.addListener((net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent event)->event.registerItem(new ThaumometerChannelPose(),art.arcane.thaumcraft.ModItems.THAUMOMETER.get()));
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut event)->art.arcane.thaumcraft.scan.ScanRegistry.clearDerived());
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(ThaumometerHud::render);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut event)->ThaumometerHud.clear());
        bus.addListener(ThaumcraftClient::registerMenus);
        bus.addListener(ThaumcraftClient::registerEntities);
        bus.addListener(ThaumcraftClient::registerParticles);
        bus.addListener(ThaumcraftClient::registerBlockColors);
    }
    private static void registerEntities(net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(art.arcane.thaumcraft.registry.ModEntities.ALUMENTUM.get(),net.minecraft.client.renderer.entity.ThrownItemRenderer::new);
    }
    private static void registerParticles(net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent event){
        event.registerSpriteSet(art.arcane.thaumcraft.registry.ModParticles.SCAN_RUNE.get(),ScanRuneParticle.Provider::new);
        event.registerSpriteSet(art.arcane.thaumcraft.registry.ModParticles.FOCUS_FIRE.get(),FocusFireParticle.Provider::new);
        event.registerSpriteSet(art.arcane.thaumcraft.registry.ModParticles.CRUCIBLE_ASPECT_BUBBLE.get(),CrucibleAspectBubbleParticle.Provider::new);
        event.registerSpriteSet(art.arcane.thaumcraft.registry.ModParticles.CRUCIBLE_OVERFLOW.get(),CrucibleOverflowParticle.Provider::new);
        event.registerSpriteSet(art.arcane.thaumcraft.registry.ModParticles.CRUCIBLE_FROTH.get(),CrucibleFrothParticle.Provider::new);
        event.registerSpriteSet(art.arcane.thaumcraft.registry.ModParticles.FOCAL_CRAFT.get(),FocalCraftParticle.Provider::new);
    }
    private static void registerBlockColors(net.neoforged.neoforge.client.event.RegisterColorHandlersEvent.BlockTintSources event) {
        net.minecraft.client.color.block.BlockTintSource filterTint=new net.minecraft.client.color.block.BlockTintSource(){
            public int color(net.minecraft.world.level.block.state.BlockState state){return -1;}
            public int colorInWorld(net.minecraft.world.level.block.state.BlockState state,net.minecraft.client.renderer.block.BlockAndTintGetter world,net.minecraft.core.BlockPos pos){
                if(world.getBlockEntity(pos) instanceof art.arcane.thaumcraft.blockentity.EssentiaTubeBlockEntity tube)return 0xFF000000 | art.arcane.thaumcraft.aspect.AspectRegistry.color(tube.filter());
                return -1;
            }
        };
        event.register(java.util.List.of(filterTint,filterTint),art.arcane.thaumcraft.ModBlocks.TUBE_FILTER.get());
        event.register(art.arcane.thaumcraft.aspect.AspectRegistry.all().keySet().stream().map(tag -> net.minecraft.client.color.block.BlockTintSources.constant(0xFF000000 | art.arcane.thaumcraft.aspect.AspectRegistry.color(tag))).toList(),art.arcane.thaumcraft.ModBlocks.JAR_NORMAL.get(),art.arcane.thaumcraft.ModBlocks.JAR_VOID.get());
        event.register(java.util.List.of(new CrucibleWaterTint()),art.arcane.thaumcraft.ModBlocks.CRUCIBLE.get());
    }
    private static void registerMenus(net.neoforged.neoforge.client.event.RegisterMenuScreensEvent event) {
        event.register(art.arcane.thaumcraft.registry.ModMenus.ARCANE_WORKBENCH.get(),ArcaneWorkbenchScreen::new);
        event.register(art.arcane.thaumcraft.registry.ModMenus.ESSENTIA_SMELTER.get(),EssentiaSmelterScreen::new);
        event.register(art.arcane.thaumcraft.registry.ModMenus.RESEARCH_TABLE.get(),ResearchTableScreen::new);
        event.register(art.arcane.thaumcraft.registry.ModMenus.FOCAL_MANIPULATOR.get(),FocalManipulatorScreen::new);
    }
    private static void registerPayloads(RegisterClientPayloadHandlersEvent event) {
        event.register(art.arcane.thaumcraft.network.ThaumometerAuraPayload.TYPE,(payload,context)->context.enqueueWork(()->ThaumometerHud.receive(payload)));
        event.register(art.arcane.thaumcraft.network.AspectSnapshotPayload.TYPE,(payload,context)->context.enqueueWork(()->art.arcane.thaumcraft.scan.ScanRegistry.installDerived(payload.values())));
        event.register(ResearchSnapshotPayload.TYPE, (payload, context) ->
                context.enqueueWork(() -> {
                    var minecraft = Minecraft.getInstance();
                    if (minecraft.gui.screen() instanceof ThaumonomiconScreen screen) screen.receiveSnapshot(payload.data());
                    else if (com.google.gson.JsonParser.parseString(payload.data()).getAsJsonObject().get("open").getAsBoolean())
                        minecraft.gui.setScreen(new ThaumonomiconScreen(payload.data()));
                }));
    }
}
