package art.arcane.thaumcraft.block;

import art.arcane.thaumcraft.aura.NativeAura;
import art.arcane.thaumcraft.item.CrystalEssenceItem;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.AmethystClusterBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import java.util.List;

/** Native six-direction attachment, with TC6 aspect drops and aura-driven growth. */
public final class CrystalClusterBlock extends AmethystClusterBlock {
    public static final IntegerProperty SIZE = IntegerProperty.create("size", 0, 3);
    public static final IntegerProperty GENERATION = IntegerProperty.create("generation", 1, 4);
    public static final MapCodec<CrystalClusterBlock> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            Codec.STRING.fieldOf("aspect").forGetter(b -> b.aspect), propertiesCodec()).apply(i, CrystalClusterBlock::new));
    private final String aspect;
    public CrystalClusterBlock(String aspect, BlockBehaviour.Properties properties) {
        super(12, 1, properties.strength(0.25F).sound(SoundType.GLASS).noOcclusion().randomTicks());
        this.aspect = aspect;
        registerDefaultState(defaultBlockState().setValue(SIZE, 0).setValue(GENERATION, 1));
    }
    @Override public MapCodec<AmethystClusterBlock> codec() { return CODEC.xmap(b -> b, b -> (CrystalClusterBlock)b); }
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder); builder.add(SIZE, GENERATION);
    }
    @Override protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        var support = level.getBlockState(pos.relative(state.getValue(FACING).getOpposite()));
        return support.is(BlockTags.MINEABLE_WITH_PICKAXE) && super.canSurvive(state, level, pos);
    }
    @Override protected List<ItemStack> getDrops(BlockState state, LootParams.Builder params) {
        return List.of(CrystalEssenceItem.of(aspect, state.getValue(SIZE) + 1));
    }
    @Override protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int size = state.getValue(SIZE), generation = state.getValue(GENERATION);
        if (random.nextInt(3 + generation) != 0) return;
        var chunk = level.getChunkAt(pos);
        var aura = NativeAura.get(level, chunk);
        boolean flux = aspect.equals("vitium");
        float pool = flux ? aura.flux() : aura.vis();
        if (pool <= 10 && size > 0) {
            level.setBlock(pos, state.setValue(SIZE, size - 1), 3);
            if (flux) aura.addFlux(10); else aura.addVis(10);
            chunk.markUnsaved();
        } else if (pool > aura.base() + 10) {
            if (size < 3 && size < 5 - generation + Math.floorMod(pos.asLong(), 3)) {
                boolean paid = flux ? aura.spendFlux(10) : aura.spend(10);
                if (paid) { level.setBlock(pos, state.setValue(SIZE, size + 1), 3); chunk.markUnsaved(); }
            } else if (generation < 4 && random.nextInt(16) == 0) {
                var target = pos.offset(random.nextInt(3)-1,random.nextInt(3)-1,random.nextInt(3)-1);
                if (!level.isEmptyBlock(target)) return;
                for (var facing : Direction.values()) {
                    var candidate = defaultBlockState().setValue(FACING, facing).setValue(GENERATION, generation + 1);
                    if (candidate.canSurvive(level,target)) { level.setBlock(target,candidate,3); break; }
                }
            }
        }
    }
}
