package art.arcane.thaumcraft.focus;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import art.arcane.thaumcraft.item.VisDiscountGear;
public final class VisDiscounts {
    public static float multiplier(Player player){int percent=0;for(var slot:new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET}){var item=player.getItemBySlot(slot).getItem();if(item instanceof VisDiscountGear gear)percent+=gear.visDiscountPercent();}return Math.max(0.1F,1F-percent/100F);}
    private VisDiscounts(){}
}
