package art.arcane.thaumcraft.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.List;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Read-only shaped crafting diagrams from the exact recipe resources shipped by this build. */
public final class ResearchRecipeScreen extends Screen {
    private static final Identifier OVERLAY=Identifier.parse("thaumcraft:textures/gui/gui_researchbook_overlay.png");
    public record Diagram(String id,JsonObject recipe) {}
    private final Screen parent;
    private final List<Diagram> diagrams;
    private int index,left,top,screenMouseX,screenMouseY;
    private float layoutScale=1;
    private Button previous,next;
    public ResearchRecipeScreen(Screen parent,List<Diagram> diagrams){super(Component.translatable("screen.thaumcraft.recipes"));this.parent=parent;this.diagrams=List.copyOf(diagrams);if(diagrams.isEmpty())throw new IllegalArgumentException("Empty recipe book");}
    public static List<Diagram> resolve(List<String> ids){
        var result=new ArrayList<Diagram>();
        for(String raw:ids){
            String canonical=raw.equals("thaumcraft:BrickArcane")?"thaumcraft:brickarcane":raw;
            var id=Identifier.tryParse(canonical);if(id==null||!id.getNamespace().equals("thaumcraft"))continue;
            var resource=Minecraft.getInstance().getResourceManager().getResource(Identifier.fromNamespaceAndPath(id.getNamespace(),"book_recipes/"+id.getPath()+".json"));
            if(resource.isEmpty())continue;
            try(var reader=resource.get().openAsReader()){
                var json=JsonParser.parseReader(reader).getAsJsonObject();
                if(json.has("type")&&json.get("type").getAsString().equals("thaumcraft:crucible")&&simpleCrucible(json))result.add(new Diagram(raw,json));
                if(json.has("type")&&java.util.Set.of("thaumcraft:arcane","minecraft:crafting_shaped").contains(json.get("type").getAsString())&&json.has("pattern")&&json.has("key")&&json.has("result")&&simpleIngredients(json))result.add(new Diagram(raw,json));
            }catch(java.io.IOException|RuntimeException error){com.mojang.logging.LogUtils.getLogger().warn("Cannot read book recipe {}",raw,error);}
        }
        return List.copyOf(result);
    }
    private static boolean simpleCrucible(JsonObject json){
        if(!json.has("catalyst")||!json.get("catalyst").isJsonPrimitive()||stack(json.get("catalyst").getAsString(),1).isEmpty()||!json.has("result")||!json.has("aspects"))return false;
        var output=json.getAsJsonObject("result");if(!output.has("id")||stack(output.get("id").getAsString(),1).isEmpty())return false;
        var aspects=json.getAsJsonObject("aspects");if(aspects.size()==0||aspects.size()>9)return false;
        return aspects.entrySet().stream().allMatch(entry->art.arcane.thaumcraft.aspect.AspectRegistry.get(entry.getKey())!=null&&entry.getValue().getAsInt()>0);
    }
    private static boolean simpleIngredients(JsonObject json){
        var output=json.getAsJsonObject("result");if(!output.has("id")||stack(output.get("id").getAsString(),1).isEmpty())return false;
        var keys=json.getAsJsonObject("key");
        for(var row:json.getAsJsonArray("pattern")){
            String line=row.getAsString();if(line.length()>3)return false;
            for(char symbol:line.toCharArray())if(symbol!=' '){
                var ingredient=keys.get(String.valueOf(symbol));
                if(ingredient==null||!ingredient.isJsonPrimitive()||ingredientOptions(ingredient.getAsString()).isEmpty())return false;
            }
        }
        return json.getAsJsonArray("pattern").size()>0&&json.getAsJsonArray("pattern").size()<=3;
    }
    @Override protected void init(){
        layoutScale=Math.min(1f,Math.min((width-16)/256f,(height-16)/256f));
        left=Math.round((width-256*layoutScale)/2);top=Math.round((height-256*layoutScale)/2);
        previous=addRenderableWidget(Button.builder(Component.translatable("screen.thaumcraft.previous_page"),b->index=Math.max(0,index-1)).bounds(left+Math.round(40*layoutScale),top+Math.round(232*layoutScale),Math.max(1,Math.round(12*layoutScale)),Math.max(1,Math.round(8*layoutScale))).build(builder->new RecipeArrow(builder,false)));
        next=addRenderableWidget(Button.builder(Component.translatable("screen.thaumcraft.next_page"),b->index=Math.min(diagrams.size()-1,index+1)).bounds(left+Math.round(204*layoutScale),top+Math.round(232*layoutScale),Math.max(1,Math.round(12*layoutScale)),Math.max(1,Math.round(8*layoutScale))).build(builder->new RecipeArrow(builder,true)));
    }
    private static final class RecipeArrow extends Button{
        private final boolean forward;
        RecipeArrow(Builder builder,boolean forward){super(builder);this.forward=forward;setTooltip(net.minecraft.client.gui.components.Tooltip.create(getMessage()));}
        @Override protected void extractContents(GuiGraphicsExtractor g,int mx,int my,float tick){
            g.blit(RenderPipelines.GUI_TEXTURED,Identifier.parse("thaumcraft:textures/gui/gui_researchbook.png"),getX(),getY(),forward?24:0,368,getWidth(),getHeight(),24,16,512,512);
        }
    }
    private static ItemStack stack(String raw,int count){var id=Identifier.tryParse(raw);if(id==null)return ItemStack.EMPTY;var item=BuiltInRegistries.ITEM.getValue(id);return item==null||item==Items.AIR?ItemStack.EMPTY:new ItemStack(item,count);}
    public static List<ItemStack> ingredientOptions(String raw){
        if(!raw.startsWith("#")){var value=stack(raw,1);return value.isEmpty()?List.of():List.of(value);}
        var id=Identifier.tryParse(raw.substring(1));if(id==null)return List.of();var result=new ArrayList<ItemStack>();
        for(var holder:BuiltInRegistries.ITEM.getTagOrEmpty(net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.ITEM,id))){
            if(holder.value()!=Items.AIR)result.add(new ItemStack(holder.value()));
        }
        return List.copyOf(result);
    }
    public static ItemStack ingredientAt(String raw,int slot,long millis){
        var options=ingredientOptions(raw);return options.isEmpty()?ItemStack.EMPTY:options.get((int)Math.floorMod(millis/1000+slot,options.size()));
    }
    private void item(GuiGraphicsExtractor g,ItemStack stack,int x,int y,int mx,int my){
        if(stack.isEmpty())return;g.item(stack,x,y);g.itemDecorations(font,stack,x,y);
        if(mx>=x&&mx<x+16&&my>=y&&my<y+16)g.setTooltipForNextFrame(ThaumcraftTheme.ink(stack.getHoverName().copy().append(stack.getCount()>1?" ×"+stack.getCount():"")),screenMouseX,screenMouseY);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float tick){
        screenMouseX=mx;screenMouseY=my;
        g.fillGradient(0,0,width,height,0xEC0D0C16,0xEC241C2D);
        int actualLeft=left,actualTop=top;
        int localX=(int)((mx-left)/layoutScale),localY=(int)((my-top)/layoutScale);
        g.pose().pushMatrix();g.pose().translate(left,top);g.pose().scale(layoutScale,layoutScale);left=0;top=0;
        g.blit(RenderPipelines.GUI_TEXTURED,Identifier.parse("thaumcraft:textures/gui/paper.png"),0,0,0,0,255,255,256,256);g.nextStratum();
        mx=localX;my=localY;
        var diagram=diagrams.get(index);var json=diagram.recipe();int cx=128,cy=128;
        if(json.get("type").getAsString().equals("thaumcraft:crucible")){renderCrucible(g,json,cx,128,mx,my);finish(g,actualLeft,actualTop,tick);return;}
        boolean arcane=json.get("type").getAsString().equals("thaumcraft:arcane");
        ThaumcraftTheme.text(g,font,Component.translatable(arcane?"screen.thaumcraft.arcane_recipe":"screen.thaumcraft.crafting_recipe"),128-font.width(ThaumcraftTheme.ink(Component.translatable(arcane?"screen.thaumcraft.arcane_recipe":"screen.thaumcraft.crafting_recipe")))/2,24,0xFF505050,false);
        g.blit(RenderPipelines.GUI_TEXTURED,OVERLAY,cx-52,cy-52,arcane?112:60,15,arcane?104:102,104,arcane?52:51,52,256,256);
        g.blit(RenderPipelines.GUI_TEXTURED,OVERLAY,cx-16,cy-92,20,3,32,32,16,16,256,256);g.nextStratum();
        var output=json.getAsJsonObject("result");item(g,stack(output.get("id").getAsString(),output.has("count")?output.get("count").getAsInt():1),cx-8,cy-84,mx,my);
        var pattern=json.getAsJsonArray("pattern");var key=json.getAsJsonObject("key");
        for(int row=0;row<Math.min(3,pattern.size());row++){
            String line=pattern.get(row).getAsString();for(int col=0;col<Math.min(3,line.length());col++){
                var ingredient=key.get(String.valueOf(line.charAt(col)));if(ingredient==null)continue;
                if(ingredient.isJsonPrimitive())item(g,ingredientAt(ingredient.getAsString(),col+row*3,net.minecraft.util.Util.getMillis()),cx-40+col*32,cy-40+row*32,mx,my);
            }
        }
        if(arcane&&json.has("crystals")){
            var crystals=json.getAsJsonObject("crystals");int n=0;
            for(var entry:crystals.entrySet())item(g,stack("thaumcraft:crystal_"+entry.getKey(),entry.getValue().getAsInt()),cx+4-crystals.size()*10+n++*20,cy+59,mx,my);
        }
        if(arcane&&json.has("vis"))ThaumcraftTheme.text(g,font,json.get("vis").getAsInt()+" vis",cx-20,cy+90,0xFF505050,false);
        finish(g,actualLeft,actualTop,tick);
    }
    private void finish(GuiGraphicsExtractor g,int actualLeft,int actualTop,float tick){
        left=actualLeft;top=actualTop;g.pose().popMatrix();
        previous.visible=index>0;next.visible=index+1<diagrams.size();
        super.extractRenderState(g,screenMouseX,screenMouseY,tick);
    }
    private void renderCrucible(GuiGraphicsExtractor g,JsonObject json,int cx,int cy,int mx,int my){
        ThaumcraftTheme.text(g,font,Component.translatable("screen.thaumcraft.crucible_recipe"),128-font.width(ThaumcraftTheme.ink(Component.translatable("screen.thaumcraft.crucible_recipe")))/2,24,0xFF505050,false);
        g.blit(RenderPipelines.GUI_TEXTURED,OVERLAY,cx-56,cy-58,0,3,112,34,56,17,256,256);
        g.blit(RenderPipelines.GUI_TEXTURED,OVERLAY,cx-56,cy-24,0,20,112,96,56,48,256,256);
        g.blit(RenderPipelines.GUI_TEXTURED,OVERLAY,cx-50,cy-52,100,84,22,26,11,13,256,256);g.nextStratum();
        var output=json.getAsJsonObject("result");item(g,stack(output.get("id").getAsString(),output.has("count")?output.get("count").getAsInt():1),cx-8,cy-50,mx,my);
        item(g,stack(json.get("catalyst").getAsString(),1),cx-64,cy-56,mx,my);
        var aspects=json.getAsJsonObject("aspects");var keys=aspects.keySet().stream().sorted().toList();int rows=(keys.size()-1)/3,shift=(3-keys.size()%3)*10;
        for(int n=0;n<keys.size();n++){
            String aspect=keys.get(n);int m=n/3>=rows&&(rows>1||keys.size()<3)?1:0;
            int x=cx-28+n%3*20+shift*m,y=cy+8-10*rows+n/3*20;
            g.blit(RenderPipelines.GUI_TEXTURED,Identifier.parse("thaumcraft:textures/aspects/"+aspect+".png"),x,y,0,0,16,16,32,32,32,32,0xFF000000|art.arcane.thaumcraft.aspect.AspectRegistry.color(aspect));
            g.nextStratum();g.text(font,Component.literal(aspects.get(aspect).getAsString()),x+10,y+9,0xFFFFFFFF,true);
            if(mx>=x&&mx<x+16&&my>=y&&my<y+16)g.setTooltipForNextFrame(ThaumcraftTheme.ink(Component.translatable(aspect).append(" ×"+aspects.get(aspect).getAsInt())),screenMouseX,screenMouseY);
        }
    }
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
