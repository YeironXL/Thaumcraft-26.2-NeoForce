package art.arcane.thaumcraft.registry;

import art.arcane.thaumcraft.Thaumcraft;
import art.arcane.thaumcraft.blockentity.ThaumcraftMachineBlockEntity;
import art.arcane.thaumcraft.ModBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> TYPES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, Thaumcraft.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ThaumcraftMachineBlockEntity>> MACHINE =
            TYPES.register("thaumcraft_machine", () -> new BlockEntityType<>(
                    ThaumcraftMachineBlockEntity::new,
                    ModBlocks.INFUSION_MATRIX.get(),
                    ModBlocks.CONDENSER.get(),
                    ModBlocks.THAUMATORIUM.get()
            ));

    public static void register(IEventBus bus) {
        TYPES.register(bus);
    }
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<art.arcane.thaumcraft.blockentity.ArcaneWorkbenchBlockEntity>> ARCANE_WORKBENCH =
            TYPES.register("arcane_workbench", () -> new BlockEntityType<>(art.arcane.thaumcraft.blockentity.ArcaneWorkbenchBlockEntity::new,ModBlocks.ARCANE_WORKBENCH.get()));
    public static final DeferredHolder<BlockEntityType<?>,BlockEntityType<art.arcane.thaumcraft.blockentity.CrucibleBlockEntity>> CRUCIBLE =
            TYPES.register("crucible",() -> new BlockEntityType<>(art.arcane.thaumcraft.blockentity.CrucibleBlockEntity::new,ModBlocks.CRUCIBLE.get()));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<art.arcane.thaumcraft.blockentity.HungryChestBlockEntity>> HUNGRY_CHEST =
            TYPES.register("hungry_chest", () -> new BlockEntityType<>(
                    art.arcane.thaumcraft.blockentity.HungryChestBlockEntity::new, ModBlocks.HUNGRY_CHEST.get()));

    public static final DeferredHolder<BlockEntityType<?>,BlockEntityType<art.arcane.thaumcraft.blockentity.EssentiaJarBlockEntity>> ESSENTIA_JAR =
        TYPES.register("essentia_jar", () -> new BlockEntityType<>(art.arcane.thaumcraft.blockentity.EssentiaJarBlockEntity::new,ModBlocks.JAR_NORMAL.get(),ModBlocks.JAR_VOID.get(),ModBlocks.ALEMBIC.get()));
    public static final DeferredHolder<BlockEntityType<?>,BlockEntityType<art.arcane.thaumcraft.blockentity.EssentiaTubeBlockEntity>> ESSENTIA_TUBE =
        TYPES.register("essentia_tube",()->new BlockEntityType<>(art.arcane.thaumcraft.blockentity.EssentiaTubeBlockEntity::new,ModBlocks.TUBE.get(),ModBlocks.TUBE_VALVE.get(),ModBlocks.TUBE_FILTER.get(),ModBlocks.TUBE_RESTRICT.get(),ModBlocks.TUBE_ONEWAY.get(),ModBlocks.TUBE_BUFFER.get()));
    public static final DeferredHolder<BlockEntityType<?>,BlockEntityType<art.arcane.thaumcraft.blockentity.EssentiaSmelterBlockEntity>> ESSENTIA_SMELTER =
        TYPES.register("essentia_smelter",()->new BlockEntityType<>(art.arcane.thaumcraft.blockentity.EssentiaSmelterBlockEntity::new,ModBlocks.SMELTER_BASIC.get(),ModBlocks.SMELTER_THAUMIUM.get(),ModBlocks.SMELTER_VOID.get()));
    public static final DeferredHolder<BlockEntityType<?>,BlockEntityType<art.arcane.thaumcraft.blockentity.EssentiaCentrifugeBlockEntity>> ESSENTIA_CENTRIFUGE =
        TYPES.register("essentia_centrifuge",()->new BlockEntityType<>(art.arcane.thaumcraft.blockentity.EssentiaCentrifugeBlockEntity::new,ModBlocks.CENTRIFUGE.get()));
    public static final DeferredHolder<BlockEntityType<?>,BlockEntityType<art.arcane.thaumcraft.blockentity.ResearchTableBlockEntity>> RESEARCH_TABLE = TYPES.register("research_table",()->new BlockEntityType<>(art.arcane.thaumcraft.blockentity.ResearchTableBlockEntity::new,ModBlocks.RESEARCH_TABLE.get()));
    public static final DeferredHolder<BlockEntityType<?>,BlockEntityType<art.arcane.thaumcraft.blockentity.FocalManipulatorBlockEntity>> FOCAL_MANIPULATOR = TYPES.register("focal_manipulator",()->new BlockEntityType<>(art.arcane.thaumcraft.blockentity.FocalManipulatorBlockEntity::new,ModBlocks.WAND_WORKBENCH.get()));
    private ModBlockEntities() {}
}
