package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.research.ResearchCatalog;
import art.arcane.thaumcraft.research.PlayerResearch;
import art.arcane.thaumcraft.research.ResearchRules;
import art.arcane.thaumcraft.network.AdvanceResearchPayload;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Original research map and book presentation; advancement remains server-owned. */
public final class ThaumonomiconScreen extends Screen {
    private static final Identifier ATLAS=Identifier.parse("thaumcraft:textures/gui/gui_research_browser.png");
    private PlayerResearch progress;
    private int observations;
    private boolean pending,dragging;
    private String category="BASICS",query="";
    private ResearchCatalog.Entry selected;
    private int spread;
    private double panX,panY;
    private boolean initialCenter=true;
    private int left,top,panelWidth,panelHeight,mapX,mapY,mapWidth,mapHeight;
    private List<ResearchCatalog.Entry> visibleEntries=List.of();
    private final List<ResearchNodeButton> nodes=new ArrayList<>();
    private final ResearchBackgroundTextures backgrounds=new ResearchBackgroundTextures();
    private Button advanceButton,previousButton,nextButton;

    public ThaumonomiconScreen(String snapshot){super(Component.translatable("screen.thaumcraft.thaumonomicon"));receiveSnapshot(snapshot);}
    public void receiveSnapshot(String snapshot){
        var state=JsonParser.parseString(snapshot).getAsJsonObject();
        progress=new PlayerResearch();
        state.getAsJsonArray("researched").forEach(key->progress.unlock(key.getAsString()));
        if(state.has("stages"))state.getAsJsonObject("stages").entrySet().forEach(entry->progress.setStage(entry.getKey(),entry.getValue().getAsInt()));
        observations=state.get("scanned_count").getAsInt();pending=false;spread=0;
        if(minecraft!=null&&width>0&&height>0)rebuildWidgets();
    }
    private Button button(Component label,int x,int y,int width,Button.OnPress action){
        return addRenderableWidget(Button.builder(label,action).bounds(x,y,width,20).build(ThaumcraftButton::new));
    }
    @Override protected void init(){
        nodes.clear();dragging=false;
        if(!categoryVisible(category)){category="BASICS";selected=null;initialCenter=true;}
        panelWidth=selected==null?width:333;panelHeight=selected==null?height:235;
        left=(width-panelWidth)/2;top=(height-panelHeight)/2;
        if(selected==null)initMap();else initBook();
    }
    private void initMap(){
        mapX=16;mapY=16;mapWidth=width-32;mapHeight=height-32;
        int searchWidth=Math.min(160,panelWidth/3);
        EditBox search=new EditBox(font,left+panelWidth-searchWidth-12,top+8,searchWidth,18,Component.translatable("screen.thaumcraft.search"));
        search.setHint(ThaumcraftTheme.ink(Component.translatable("screen.thaumcraft.search")));search.setMaxLength(80);search.setValue(query);
        search.setResponder(value->{query=value;updateNodeVisibility();});search.visible=false;addRenderableWidget(search);
        addRenderableWidget(Button.builder(Component.translatable("screen.thaumcraft.search"),b->{search.visible=!search.visible;if(search.visible)setFocused(search);}).bounds(1,height-17,16,16).tooltip(Tooltip.create(Component.translatable("screen.thaumcraft.search"))).build(builder->new Button(builder){
            @Override protected void extractContents(GuiGraphicsExtractor g,int mx,int my,float tick){
                g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,getX(),getY(),160,16,16,16,256,256);
            }
        }));
        var categories=visibleCategories();
        for(int index=0;index<categories.size();index++){
            String key=categories.get(index);int categoryIndex=ResearchCatalog.CATEGORIES.indexOf(key);
            var entries=ResearchCatalog.entries().values().stream().filter(entry->entry.category().equals(key)&&!entry.meta().contains("AUTOUNLOCK")).toList();
            long done=entries.stream().filter(entry->ResearchRules.complete(progress,entry.key())).count();
            var label=ThaumcraftTheme.ink(Component.translatable("tc.research_category."+key).append(" ("+(entries.isEmpty()?0:done*100/entries.size())+"%)"));
            addRenderableWidget(Button.builder(label,b->selectCategory(key)).bounds(1,10+index*24,16,16)
                    .tooltip(Tooltip.create(label)).build(builder->new ResearchCategoryButton(builder,categoryIndex,key.equals(category))));
        }
        visibleEntries=ResearchCatalog.entries().values().stream().filter(entry->entry.category().equals(category))
            .filter(entry->ResearchMapData.node(entry.key())!=null&&ResearchRules.visible(progress,entry)).toList();
        for(var entry:visibleEntries){
            var node=new ResearchNodeButton(entry,available(entry),ResearchRules.complete(progress,entry.key()),b->openResearch(entry.key()));
            nodes.add(node);addRenderableWidget(node);
        }
        if(initialCenter){initialCenter=false;centerMap();}else updateNodeVisibility();
    }
    private void cycleCategory(int direction){
        var categories=visibleCategories();
        selectCategory(categories.get(Math.floorMod(categories.indexOf(category)+direction,categories.size())));
    }
    private boolean categoryVisible(String key){return key.equals("BASICS")||ResearchCatalog.CATEGORIES.contains(key)&&ResearchRules.knows(progress,"UNLOCK"+key);}
    private List<String> visibleCategories(){return ResearchCatalog.CATEGORIES.stream().filter(this::categoryVisible).toList();}
    public boolean selectCategory(String key){
        if(!categoryVisible(key))return false;
        category=key;selected=null;query="";panX=0;panY=0;initialCenter=true;rebuildWidgets();return true;
    }
    private void centerMap(){
        if(visibleEntries.isEmpty()){panX=0;panY=0;return;}
        var anchor=visibleEntries.stream().filter(this::available).findFirst().orElse(visibleEntries.getFirst());
        if(category.equals("BASICS"))anchor=ResearchCatalog.entries().get("FIRSTSTEPS");
        var position=ResearchMapData.node(anchor.key());
        panX=-position.column()*24.0;panY=-position.row()*24.0-mapHeight/2.0+24;updateNodeVisibility();
    }
    private int nodeX(ResearchCatalog.Entry entry){return mapX+mapWidth/2+(int)Math.round(panX)+ResearchMapData.node(entry.key()).column()*24;}
    private int nodeY(ResearchCatalog.Entry entry){return mapY+mapHeight/2+(int)Math.round(panY)+ResearchMapData.node(entry.key()).row()*24;}
    private void updateNodeVisibility(){
        String match=query.strip().toLowerCase(Locale.ROOT);
        for(var node:nodes){
            int x=nodeX(node.entry)-16,y=nodeY(node.entry)-16;node.setPosition(x,y);
            boolean matches=match.isEmpty()||node.entry.key().toLowerCase(Locale.ROOT).contains(match)||Component.translatable(node.entry.name()).getString().toLowerCase(Locale.ROOT).contains(match);
            node.visible=matches&&x>=mapX&&y>=mapY&&x+32<=mapX+mapWidth&&y+32<=mapY+mapHeight;
        }
    }
    public boolean openResearch(String key){
        var entry=ResearchCatalog.entries().get(key);
        if(entry==null||!ResearchRules.visible(progress,entry)||!entry.category().equals(category))return false;
        selected=entry;spread=0;dragging=false;rebuildWidgets();return true;
    }
    private Button atlasButton(Component label,int x,int y,int w,int h,int u,int v,Button.OnPress action){
        return addRenderableWidget(Button.builder(label,action).bounds(x,y,w,h).tooltip(Tooltip.create(label)).build(builder->new BookAtlasButton(builder,u,v)));
    }
    private static class BookAtlasButton extends Button{
        private final int u,v;
        BookAtlasButton(Builder builder,int u,int v){super(builder);this.u=u;this.v=v;}
        @Override protected void extractContents(GuiGraphicsExtractor g,int mx,int my,float tick){
            g.blit(RenderPipelines.GUI_TEXTURED,Identifier.parse("thaumcraft:textures/gui/gui_researchbook.png"),getX(),getY(),u*2,v*2,getWidth(),getHeight(),getWidth()*2,getHeight()*2,512,512,active?0xFFFFFFFF:0xFF777777);
        }
    }
    private void initBook(){
        atlasButton(Component.translatable("screen.thaumcraft.map.back"),left+156,top+217,20,12,38,202,b->backToMap());
        previousButton=atlasButton(Component.translatable("screen.thaumcraft.previous_page"),left+22,top+217,12,8,0,184,b->spread=Math.max(0,spread-1));
        previousButton.setTooltip(Tooltip.create(Component.translatable("screen.thaumcraft.previous_page")));
        nextButton=atlasButton(Component.translatable("screen.thaumcraft.next_page"),left+300,top+217,12,8,12,184,b->spread++);
        nextButton.setTooltip(Tooltip.create(Component.translatable("screen.thaumcraft.next_page")));
        if(available(selected)&&!selected.stages().isEmpty()){
            int stageIndex=Math.clamp(progress.stage(selected.key())-1,0,selected.stages().size()-1);
            var diagrams=ResearchRecipeScreen.resolve(selected.stages().get(stageIndex).recipes());
            if(!diagrams.isEmpty())atlasButton(Component.translatable("screen.thaumcraft.recipes"),left+318,top+18,28,16,120,232,b->openRecipes());
        }
        advanceButton=addRenderableWidget(Button.builder(Component.translatable("tc.stage.complete"),b->{
            if(pending||!available(selected)||ResearchRules.complete(progress,selected.key()))return;
            pending=true;b.active=false;ClientPacketDistributor.sendToServer(new AdvanceResearchPayload(selected.key(),progress.stage(selected.key())));
        }).bounds(left+214,top+197,64,12).build(builder->new BookAtlasButton(builder,84,216){
            @Override protected void extractContents(GuiGraphicsExtractor g,int mx,int my,float tick){
                super.extractContents(g,mx,my,tick);
                var text=ThaumcraftTheme.ink(getMessage());
                g.text(font,text,getX()+(getWidth()-font.width(text))/2,getY()+2,0xFFFFFFFF,true);
            }
        }));

    }
    public boolean openRecipes(){
        if(selected==null||!available(selected)||selected.stages().isEmpty())return false;
        int index=Math.clamp(progress.stage(selected.key())-1,0,selected.stages().size()-1);
        var diagrams=ResearchRecipeScreen.resolve(selected.stages().get(index).recipes());if(diagrams.isEmpty())return false;
        minecraft.gui.setScreen(new ResearchRecipeScreen(this,diagrams));return true;
    }
    private void backToMap(){selected=null;spread=0;rebuildWidgets();}
    private boolean available(ResearchCatalog.Entry entry){return ResearchRules.complete(progress,entry.key())||ResearchRules.available(progress,entry);}
    private String body(){
        StringBuilder body=new StringBuilder();
        if(!available(selected)&&!selected.parents().isEmpty()){
            body.append(Component.translatable("screen.thaumcraft.prerequisites").getString()).append('\n');
            for(String key:selected.parents()){
                var parent=ResearchCatalog.entries().get(key);
                body.append(ResearchRules.knows(progress,key)?"+ ":"- ").append(parent==null?key:Component.translatable(parent.name()).getString()).append('\n');
            }
            body.append('\n');
        }
        if(available(selected)&&!selected.stages().isEmpty()){
            int index=Math.clamp(progress.stage(selected.key())-1,0,selected.stages().size()-1);var stage=selected.stages().get(index);
            
            body.append(Component.translatable(stage.text()).getString());
            if(!stage.requirements().isEmpty()){
                body.append("\n\n").append(Component.translatable("screen.thaumcraft.requirements").getString()).append('\n');
                stage.requirements().forEach((type,values)->{
                    body.append(Component.translatable("screen.thaumcraft."+type).getString()).append(":\n");
                    values.forEach(value->body.append("- ").append(ResearchRequirementText.format(type,value).getString()).append('\n'));
                });
            }
        }
        return body.toString();
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float tick){
        g.fillGradient(0,0,width,height,0xEC0D0C16,0xEC241C2D);
        if(selected==null)renderMap(g);else renderBook(g);
        g.nextStratum();
        super.extractRenderState(g,mouseX,mouseY,tick);
    }
    private void renderMap(GuiGraphicsExtractor g){
        Identifier background=backgrounds.get(ResearchMapData.background(category));
        int u=Math.floorMod((int)(256-panX/2),Math.max(1,1024-mapWidth));
        int v=Math.floorMod((int)(256-panY/2),Math.max(1,1024-mapHeight));
        g.blit(RenderPipelines.GUI_TEXTURED,background,mapX,mapY,u,v,mapWidth,mapHeight,1024,1024);
        g.nextStratum();
        // Original browser fills the screen, with tiled 22-pixel wooden borders.
        for(int x=16;x<width-16;x+=64){
            int w=Math.min(64,width-16-x);
            g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,x,-2,48,13,w,22,256,256);
            g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,x,height-20,48,13,w,22,256,256);
        }
        for(int y=16;y<height-16;y+=64){
            int h=Math.min(64,height-16-y);
            g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,-2,y,13,48,22,h,256,256);
            g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,width-20,y,13,48,22,h,256,256);
        }
        for(int x:new int[]{-2,width-20})for(int y:new int[]{-2,height-20})
            g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,x,y,13,13,22,22,256,256);
        updateNodeVisibility();
        g.enableScissor(mapX,mapY,mapX+mapWidth,mapY+mapHeight);
        for(var entry:visibleEntries)for(String raw:entry.parents()){
            if(raw.startsWith("~"))continue;
            String key=raw.split("@",2)[0];
            var parent=ResearchCatalog.entries().get(key);
            if(parent==null||!visibleEntries.contains(parent))continue;
            if(parent.siblings().contains(entry.key()))continue;
            int color=ResearchRules.knows(progress,raw)?0xFF999999:0xFF333333;
            researchLink(g,entry,parent,color,true,entry.meta().contains("REVERSE"));
        }
        for(var entry:visibleEntries)for(String key:entry.siblings()){
            if(key.startsWith("~"))continue;
            var sibling=ResearchCatalog.entries().get(key);
            if(sibling==null||!visibleEntries.contains(sibling))continue;
            int color=ResearchRules.complete(progress,key)?0xFF4D4D66:0xFF303040;
            researchLink(g,sibling,entry,color,false,entry.meta().contains("REVERSE"));
        }
        if(visibleEntries.isEmpty())ThaumcraftTheme.text(g,font,Component.translatable("screen.thaumcraft.map.empty"),mapX+12,mapY+12,0xFFE5D6B3,false);
        g.disableScissor();
    }
    /** Original atlas segments, including the authored large and small rounded corners. */
    private void researchLink(GuiGraphicsExtractor g,ResearchCatalog.Entry child,ResearchCatalog.Entry parent,int color,boolean arrow,boolean flipped){
        var from=flipped?parent:child;var to=flipped?child:parent;
        int x=nodeX(from)-12,y=nodeY(from)-12;
        int xd=Math.abs(nodeX(to)-nodeX(from))/24,yd=Math.abs(nodeY(to)-nodeY(from))/24;
        int xm=Integer.signum(nodeX(to)-nodeX(from)),ym=Integer.signum(nodeY(to)-nodeY(from));
        boolean big=xd>1&&yd>1;
        int arrowU;
        if(flipped)arrowU=xm<0?160:xm>0?128:ym>0?64:96;
        else arrowU=ym<0?64:ym>0?96:xm>0?160:128;
        if(arrow&&(xd!=0||yd!=0))linkTile(g,nodeX(child)-16,nodeY(child)-16,arrowU,112,32,color);
        int v=1;
        while(v<yd-(big?1:0)){linkTile(g,x,y+ym*24*v,0,228,24,color);v++;}
        if(xm!=0&&ym!=0){
            int u=xm<0?(ym>0?0:96):(ym>0?48:144);
            if(big)linkTile(g,x+(xm<0?-24:0),y+ym*24*v+(ym<0?-24:0),u,180,48,color);
            else linkTile(g,x,y+ym*24*v,xm<0?(ym>0?48:96):(ym>0?72:120),228,24,color);
        }
        v+=big?1:0;
        for(int h=big?2:1;h<xd;h++)linkTile(g,x+xm*24*h,y+ym*24*v,24,228,24,color);
    }
    private static void linkTile(GuiGraphicsExtractor g,int x,int y,int u,int v,int size,int color){
        g.blit(RenderPipelines.GUI_TEXTURED,ATLAS,x,y,u,v,size,size,256,256,color);
    }
    private void renderBook(GuiGraphicsExtractor g){
        ThaumcraftTheme.book(g,left,top,panelWidth,panelHeight);
        int pageWidth=140,contentY=top+39;
        int perPage=Math.max(1,(panelHeight-82)/11);
        var pages=ResearchBookText.illustratedPages(font,body(),Math.max(40,pageWidth),perPage*11);
        int spreads=Math.max(1,(pages.size()+1)/2);spread=Math.clamp(spread,0,spreads-1);
        previousButton.active=previousButton.visible=spread>0;nextButton.active=nextButton.visible=spread+1<spreads;
        advanceButton.visible=available(selected)&&!ResearchRules.complete(progress,selected.key());
        advanceButton.active=advanceButton.visible&&!pending;
        var titleLines=font.split(ThaumcraftTheme.ink(Component.translatable(selected.name())),pageWidth);
        if(!titleLines.isEmpty()){
            var heading=ThaumcraftTheme.ink(Component.translatable(selected.name()));float size=Math.min(1f,140f/Math.max(1,font.width(heading)));
            g.blit(RenderPipelines.GUI_TEXTURED,Identifier.parse("thaumcraft:textures/gui/gui_researchbook.png"),left+43,top+10,48,368,96,4,192,8,512,512);
            g.blit(RenderPipelines.GUI_TEXTURED,Identifier.parse("thaumcraft:textures/gui/gui_researchbook.png"),left+43,top+27,48,368,96,4,192,8,512,512);
            g.pose().pushMatrix();g.pose().translate(left+94-font.width(heading)*size/2,top+17);g.pose().scale(size,size);g.text(font,heading,0,0,0xFF202020,false);g.pose().popMatrix();
        }

        for(int page=0;page<2;page++){
            int x=page==0?left+24:left+176;
            g.enableScissor(x,contentY,x+pageWidth,top+panelHeight-36);
            int index=spread*2+page;
            if(index<pages.size())for(var element:pages.get(index)){
                if(element instanceof ResearchBookText.Text text)g.text(font,text.line(),x,contentY+text.y(),0xFF000000,false);
                else if(element instanceof ResearchBookText.Image image && minecraft.getResourceManager().getResource(image.texture()).isPresent())
                    g.blit(RenderPipelines.GUI_TEXTURED,image.texture(),x+(pageWidth-image.width())/2,contentY+image.y(),image.u(),image.v(),image.width(),image.height(),image.sourceWidth(),image.sourceHeight(),256,256);
            }
            g.disableScissor();
        }

    }
    private boolean insideMap(double x,double y){return selected==null&&x>=mapX&&x<mapX+mapWidth&&y>=mapY&&y<mapY+mapHeight;}
    @Override public boolean mouseClicked(MouseButtonEvent event,boolean doubleClick){
        if(super.mouseClicked(event,doubleClick))return true;
        if(event.button()==0&&insideMap(event.x(),event.y())){dragging=true;return true;}return false;
    }
    @Override public boolean mouseDragged(MouseButtonEvent event,double dx,double dy){
        if(dragging&&event.button()==0){panX=Math.clamp(panX+dx,-2048,2048);panY=Math.clamp(panY+dy,-2048,2048);updateNodeVisibility();return true;}
        return super.mouseDragged(event,dx,dy);
    }
    @Override public boolean mouseReleased(MouseButtonEvent event){dragging=false;return super.mouseReleased(event);}
    @Override public boolean mouseScrolled(double x,double y,double scrollX,double scrollY){
        if(selected==null&&x>=left+12&&x<left+panelWidth-12&&y>=top+30&&y<top+50){if(scrollY!=0)cycleCategory(scrollY>0?-1:1);return true;}
        if(insideMap(x,y)){panX=Math.clamp(panX+scrollX*24,-2048,2048);panY=Math.clamp(panY+scrollY*24,-2048,2048);updateNodeVisibility();return true;}
        return super.mouseScrolled(x,y,scrollX,scrollY);
    }
    @Override public boolean keyPressed(KeyEvent event){
        if(event.isEscape()&&selected!=null){backToMap();return true;}
        if(selected==null&&!(getFocused() instanceof EditBox)){
            if(event.isLeft())panX+=24;else if(event.isRight())panX-=24;else if(event.isUp())panY+=24;else if(event.isDown())panY-=24;else return super.keyPressed(event);
            panX=Math.clamp(panX,-2048,2048);panY=Math.clamp(panY,-2048,2048);updateNodeVisibility();return true;
        }
        return super.keyPressed(event);
    }
    @Override public void onClose(){if(selected!=null)backToMap();else super.onClose();}
    @Override public void removed(){backgrounds.close();super.removed();}
    @Override public boolean isPauseScreen(){return false;}
}
