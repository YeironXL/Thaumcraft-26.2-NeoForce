package art.arcane.thaumcraft.scan;
import java.util.*;
/** Deterministic recipe graph evaluation. Unknown inputs contribute no tags, as in TC6. */
public final class RecipeAspectResolver {
    public record Recipe(String output,List<String> ingredients,List<String> remainders,int count,int vis){
        public Recipe {ingredients=List.copyOf(ingredients);remainders=List.copyOf(remainders);if(count<1||vis<0)throw new IllegalArgumentException("Invalid recipe");}
    }
    private final Map<String,Map<String,Integer>> explicit;
    private final Map<String,List<Recipe>> recipes;
    private final Map<String,Map<String,Integer>> additions;
    private final Map<String,String> copies;
    private final Map<String,Map<String,Integer>> cache=new HashMap<>();
    public RecipeAspectResolver(Map<String,Map<String,Integer>> explicit,List<Recipe> recipes){this(explicit,recipes,Map.of(),Map.of());}
    public RecipeAspectResolver(Map<String,Map<String,Integer>> explicit,List<Recipe> recipes,Map<String,Map<String,Integer>> additions,Map<String,String> copies){
        var extras=new LinkedHashMap<String,Map<String,Integer>>();additions.forEach((key,tags)->extras.put(key,Map.copyOf(tags)));this.additions=Map.copyOf(extras);this.copies=Map.copyOf(copies);
        var copy=new LinkedHashMap<String,Map<String,Integer>>();explicit.forEach((key,tags)->copy.put(key,Map.copyOf(tags)));this.explicit=Map.copyOf(copy);
        var grouped=new LinkedHashMap<String,List<Recipe>>();for(var recipe:recipes)grouped.computeIfAbsent(recipe.output(),key->new ArrayList<>()).add(recipe);
        var frozen=new LinkedHashMap<String,List<Recipe>>();grouped.forEach((key,value)->frozen.put(key,List.copyOf(value)));this.recipes=Map.copyOf(frozen);
    }
    public Map<String,Integer> get(String item){return cache.computeIfAbsent(item,key->resolve(key,new HashSet<>()));}
    private Map<String,Integer> resolve(String item,Set<String> visiting){
        var fixed=explicit.get(item);if(fixed!=null)return fixed;
        if(visiting.size()>=100||!visiting.add(item))return Map.of();
        try{
            var alternatives=new ArrayList<Map<String,Integer>>();
            for(var recipe:recipes.getOrDefault(item,List.of())){
                var ingredients=new ArrayList<Map<String,Integer>>();for(var ingredient:recipe.ingredients())ingredients.add(resolve(ingredient,visiting));
                var remainders=new ArrayList<Map<String,Integer>>();for(var remainder:recipe.remainders())remainders.add(resolve(remainder,visiting));
                alternatives.add(RecipeAspectMath.derive(ingredients,remainders,recipe.count(),recipe.vis()));
            }
            var result=new LinkedHashMap<String,Integer>(copies.containsKey(item)?resolve(copies.get(item),visiting):RecipeAspectMath.cheapest(alternatives));
            additions.getOrDefault(item,Map.of()).forEach((aspect,amount)->{if(amount>0)result.merge(aspect,amount,Math::addExact);});
            return Map.copyOf(result);
        }finally{visiting.remove(item);}
    }
}
