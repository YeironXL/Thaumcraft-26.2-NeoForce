package art.arcane.thaumcraft.menu;
import art.arcane.thaumcraft.ModItems;
import art.arcane.thaumcraft.blockentity.FocalManipulatorBlockEntity;
import art.arcane.thaumcraft.focus.TouchFireFocus;
import art.arcane.thaumcraft.registry.ModMenus;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
public final class FocalManipulatorMenu extends AbstractContainerMenu {
    private final Container container; private final ContainerData data;
    public FocalManipulatorMenu(int id,Inventory inventory){this(id,inventory,new SimpleContainer(1),new SimpleContainerData(6));data.set(1,1);}
    public FocalManipulatorMenu(int id,Inventory inventory,Container container,ContainerData data){
        super(ModMenus.FOCAL_MANIPULATOR.get(),id);checkContainerSize(container,1);checkContainerDataCount(data,6);this.container=container;this.data=data;
        addSlot(new Slot(container,0,31,191){public boolean mayPlace(ItemStack stack){return !working()&&stack.is(ModItems.FOCUS_1.get());}public boolean mayPickup(Player player){return !working();}public int getMaxStackSize(){return 1;}});
        for(int row=0;row<3;row++)for(int col=0;col<9;col++)addSlot(new Slot(inventory,col+row*9+9,18*row-62,64+18*col));
        for(int row=0;row<3;row++)for(int col=0;col<3;col++)addSlot(new Slot(inventory,col+row*3,18*col-62,7+18*row));
        addDataSlots(data);
    }
    public int value(int index){return data.get(index);}public boolean working(){return value(5)!=0;}
    public int button(int action){return value(0)*64+action;}
    public static int selection(int power,int duration){return 1+(power-1)*6+duration;}
    @Override public boolean stillValid(Player player){return container.stillValid(player);}
    @Override public boolean clickMenuButton(Player player,int encoded){
        if(!(player instanceof ServerPlayer server)||!stillValid(player)||!(container instanceof FocalManipulatorBlockEntity table)||working()||encoded<0||encoded/64!=value(0))return false;
        int action=encoded%64;
        if(action==0){if(!table.start(server,new TouchFireFocus(value(1),value(2)))){if(server.connection!=null)server.sendOverlayMessage(net.minecraft.network.chat.Component.translatable("screen.thaumcraft.requirements_unmet"));return false;}}
        else {if(action>30)return false;int power=(action-1)/6+1,duration=(action-1)%6;
            try{new TouchFireFocus(power,duration);}catch(IllegalArgumentException invalid){return false;}data.set(1,power);data.set(2,duration);}
        data.set(0,(value(0)+1)%512);broadcastChanges();return true;
    }
    @Override public ItemStack quickMoveStack(Player player,int index){
        if(index<0||index>=slots.size()||(index==0&&working()))return ItemStack.EMPTY;
        var slot=slots.get(index);if(!slot.hasItem())return ItemStack.EMPTY;var stack=slot.getItem();var copy=stack.copy();
        if(index==0){if(!moveItemStackTo(stack,1,37,true))return ItemStack.EMPTY;}
        else if(slots.get(0).mayPlace(stack)){if(!moveItemStackTo(stack,0,1,false))return ItemStack.EMPTY;}
        else if(index<28){if(!moveItemStackTo(stack,28,37,false))return ItemStack.EMPTY;}
        else if(!moveItemStackTo(stack,1,28,false))return ItemStack.EMPTY;
        if(stack.isEmpty())slot.setByPlayer(ItemStack.EMPTY);else slot.setChanged();slot.onTake(player,stack);return copy;
    }
}
