package art.arcane.thaumcraft.scan;
import java.util.*;
/** TC6 ingredient accounting; recipe discovery and cycle handling are supplied separately. */
public final class RecipeAspectMath {
    public static Map<String,Integer> derive(List<Map<String,Integer>> ingredients,List<Map<String,Integer>> remainders,int outputCount,int arcaneVis){
        if(outputCount<1||arcaneVis<0)throw new IllegalArgumentException("Invalid recipe costs");
        var total=new LinkedHashMap<String,Integer>();
        for(var ingredient:ingredients)ingredient.forEach((aspect,amount)->{if(amount>0)total.merge(aspect,amount,Math::addExact);});
        for(var remainder:remainders)remainder.forEach((aspect,amount)->{if(amount>0)total.computeIfPresent(aspect,(key,value)->Math.max(0,value-amount));});
        var result=new LinkedHashMap<String,Integer>();
        total.forEach((aspect,amount)->{float value=amount*0.75f/outputCount;if(value<1f&&value>0.75f)value=1f;int scaled=(int)value;if(scaled>0)result.put(aspect,scaled);});
        if(arcaneVis>0){int magic=(int)(Math.sqrt(1+arcaneVis/2)/outputCount);if(magic>0)result.merge("praecantatio",magic,Math::addExact);}
        return Collections.unmodifiableMap(result);
    }
    public static Map<String,Integer> cheapest(List<Map<String,Integer>> alternatives){
        Map<String,Integer> best=Map.of();long size=Long.MAX_VALUE;
        for(var candidate:alternatives){long sum=candidate.values().stream().mapToLong(Integer::longValue).sum();if(sum>0&&sum<size){best=candidate;size=sum;}}
        return Map.copyOf(best);
    }
    private RecipeAspectMath(){}
}
