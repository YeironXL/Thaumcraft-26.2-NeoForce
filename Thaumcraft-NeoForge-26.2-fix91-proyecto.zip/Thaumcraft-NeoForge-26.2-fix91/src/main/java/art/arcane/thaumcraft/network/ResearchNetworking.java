package art.arcane.thaumcraft.network;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

public final class ResearchNetworking {
    public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToClient(ResearchSnapshotPayload.TYPE, ResearchSnapshotPayload.CODEC);
        event.registrar("1").playToClient(AspectSnapshotPayload.TYPE, AspectSnapshotPayload.CODEC);
        event.registrar("1").playToClient(ThaumometerAuraPayload.TYPE, ThaumometerAuraPayload.CODEC);
        event.registrar("1").playToServer(AdvanceResearchPayload.TYPE, AdvanceResearchPayload.CODEC, AdvanceResearchPayload::handle);
    }
    private ResearchNetworking() {}
}
