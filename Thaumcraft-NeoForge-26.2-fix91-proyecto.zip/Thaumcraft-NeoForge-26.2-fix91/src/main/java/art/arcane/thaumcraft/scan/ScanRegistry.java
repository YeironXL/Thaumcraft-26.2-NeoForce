package art.arcane.thaumcraft.scan;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import art.arcane.thaumcraft.aspect.Aspect;
import art.arcane.thaumcraft.aspect.AspectRegistry;

/** Default aspect assignments used by the first native scanning layer. */
public final class ScanRegistry {
    private static final Map<String, Map<Aspect, Integer>> ENTRIES = new LinkedHashMap<>();
    static {
        // Explicit object tags from TC6 ConfigAspects, mapped to modern registry names.
        for (String id : new String[]{"stone", "granite", "diorite", "andesite", "dirt"})
            register("minecraft:" + id, AspectRegistry.TERRA, 5);
        register("minecraft:cobblestone", AspectRegistry.TERRA, 5);
        register("minecraft:cobblestone", AspectRegistry.PERDITIO, 1);
        register("minecraft:grass_block", AspectRegistry.TERRA, 5);
        register("minecraft:grass_block", AspectRegistry.HERBA, 2);
        register("minecraft:iron_ingot", AspectRegistry.METALLUM, 15);
        register("minecraft:gold_ingot", AspectRegistry.METALLUM, 10);
        register("minecraft:gold_ingot", AspectRegistry.DESIDERIUM, 10);
        register("minecraft:glass", AspectRegistry.VITREUS, 5);
        register("minecraft:feather", AspectRegistry.AER, 5);
        register("minecraft:feather", AspectRegistry.VOLATUS, 5);
        register("minecraft:redstone", AspectRegistry.POTENTIA, 10);
        for (String id : new String[]{"coal", "charcoal"}) {
            register("minecraft:" + id, AspectRegistry.POTENTIA, 10);
            register("minecraft:" + id, AspectRegistry.IGNIS, 10);
        }
        register("minecraft:diamond", AspectRegistry.VITREUS, 15);
        register("minecraft:diamond", AspectRegistry.DESIDERIUM, 15);
        register("minecraft:emerald", AspectRegistry.VITREUS, 15);
        register("minecraft:emerald", AspectRegistry.DESIDERIUM, 10);
        register("minecraft:quartz", AspectRegistry.VITREUS, 5);
        register("minecraft:obsidian", AspectRegistry.TERRA, 5);
        register("minecraft:obsidian", AspectRegistry.IGNIS, 5);
        register("minecraft:obsidian", AspectRegistry.TENEBRAE, 5);
        register("thaumcraft:salis_mundus", AspectRegistry.PRAECANTATIO, 5);
        register("thaumcraft:salis_mundus", AspectRegistry.POTENTIA, 5);
        register("minecraft:glowstone_dust", AspectRegistry.SENSUS, 5);
        register("minecraft:glowstone_dust", AspectRegistry.LUX, 10);
        register("minecraft:rotten_flesh", AspectRegistry.HUMANUS, 5);
        register("minecraft:rotten_flesh", AspectRegistry.VICTUS, 5);
        register("minecraft:rotten_flesh", AspectRegistry.PERDITIO, 5);
        // TC6 ore-dictionary base tags mapped to the six historical vanilla wood families.
        for(String wood:new String[]{"oak","spruce","birch","jungle","acacia","dark_oak"}){
            register("minecraft:"+wood+"_log",AspectRegistry.HERBA,20);
            register("minecraft:"+wood+"_wood",AspectRegistry.HERBA,20);
        }
        for(String sand:new String[]{"sand","red_sand"}){register("minecraft:"+sand,AspectRegistry.TERRA,5);register("minecraft:"+sand,AspectRegistry.PERDITIO,5);}
        base("flint",Map.of("terra",5,"instrumentum",5));
        base("string",Map.of("bestia",5,"fabrico",1));
        base("slime_ball",Map.of("aqua",5,"victus",5,"alkimia",1));
        base("bone",Map.of("mortuus",5,"victus",5));
        base("egg",Map.of("victus",5,"bestia",5));
        base("spider_eye",Map.of("sensus",5,"bestia",5,"mortuus",5));
        base("gunpowder",Map.of("ignis",10,"perditio",10,"alkimia",5));
        base("sugar_cane",Map.of("herba",5,"aqua",3,"aer",2));
        base("ink_sac",Map.of("aqua",2,"bestia",2));
        register("minecraft:leather", AspectRegistry.BESTIA, 5);
        register("minecraft:leather", AspectRegistry.PRAEMUNIO, 5);
    }
    private static void base(String item,Map<String,Integer> tags){tags.forEach((tag,count)->{
        var aspect=AspectRegistry.get(tag);if(aspect==null)throw new IllegalStateException("Unknown base aspect "+tag);
        register("minecraft:"+item,aspect,count);
    });}
    public static void register(String id, Aspect aspect, int amount) {
        ENTRIES.computeIfAbsent(id, k -> new LinkedHashMap<>()).merge(aspect, Math.max(1, amount), Integer::sum);
    }
    private static volatile Map<String,Map<Aspect,Integer>> derived=Map.of();
    public static void installDerived(Map<String,Map<String,Integer>> values){
        if(values.size()>64)throw new IllegalArgumentException("Too many initial aspect entries");
        var copy=new LinkedHashMap<String,Map<Aspect,Integer>>();values.forEach((id,tags)->{if(net.minecraft.resources.Identifier.tryParse(id)==null)throw new IllegalArgumentException("Invalid item id");var mapped=new LinkedHashMap<Aspect,Integer>();tags.forEach((tag,count)->{var aspect=AspectRegistry.get(tag);if(aspect==null||count<1||count>10000)throw new IllegalArgumentException("Invalid aspect amount");mapped.put(aspect,count);});copy.put(id,Map.copyOf(mapped));});derived=Map.copyOf(copy);
    }
    public static void clearDerived(){derived=Map.of();}
    public static Map<Aspect, Integer> get(String id) {
        return ENTRIES.containsKey(id) ? Collections.unmodifiableMap(ENTRIES.get(id)) : derived.getOrDefault(id,Map.of());
    }
    public static Map<String, Map<Aspect, Integer>> all() { return Collections.unmodifiableMap(ENTRIES); }
    private ScanRegistry() {}
}
