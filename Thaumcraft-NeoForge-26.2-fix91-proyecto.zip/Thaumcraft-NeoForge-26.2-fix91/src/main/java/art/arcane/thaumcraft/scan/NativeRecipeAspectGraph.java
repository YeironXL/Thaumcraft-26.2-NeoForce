package art.arcane.thaumcraft.scan;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.*;
import java.util.*;
/** Extracts ordinary shaped/shapeless recipes. Special and arcane recipes require separate adapters. */
public final class NativeRecipeAspectGraph {
    public static RecipeAspectResolver build(RecipeManager manager){
        var seeds=new LinkedHashMap<String,Map<String,Integer>>();ScanRegistry.all().forEach((id,tags)->{var values=new LinkedHashMap<String,Integer>();tags.forEach((aspect,count)->values.put(aspect.id(),count));seeds.put(id,values);});
        var recipes=new ArrayList<RecipeAspectResolver.Recipe>();
        for(var holder:manager.recipeMap().byType(RecipeType.CRAFTING)){
            var recipe=holder.value();List<Optional<Ingredient>> ingredients;int width,height;
            if(recipe instanceof ShapedRecipe shaped){ingredients=shaped.getIngredients();width=shaped.getWidth();height=shaped.getHeight();}
            else if(recipe instanceof ShapelessRecipe shapeless){ingredients=shapeless.placementInfo().ingredients().stream().map(Optional::of).toList();width=ingredients.size();height=1;}
            else continue;
            if(width<1||height<1)continue;
            var stacks=new ArrayList<ItemStack>();var keys=new ArrayList<String>();boolean unsupported=false;
            for(var ingredient:ingredients){var stack=ingredient.map(value->{var choices=value.items().toList();var known=choices.stream().filter(item->{String key=BuiltInRegistries.ITEM.getKey(item.value()).toString();return seeds.containsKey(key)||List.of("oak","spruce","birch","jungle","acacia","dark_oak").stream().anyMatch(wood->key.equals("minecraft:"+wood+"_planks"));}).findFirst();return known.or(()->choices.stream().findFirst()).map(item->new ItemStack(item.value())).orElse(ItemStack.EMPTY);}).orElse(ItemStack.EMPTY);stacks.add(stack);
                if(!stack.isEmpty()){String key=id(stack);keys.add(key);if(key.equals("thaumcraft:crystal_essence")||key.equals("thaumcraft:phial_filled"))unsupported=true;}}
            // Plain registry IDs cannot represent typed essence; do not infer misleading tags.
            if(unsupported)continue;
            var input=CraftingInput.of(width,height,stacks);var result=recipe.assemble(input);if(result.isEmpty())continue;
            var returns=new ArrayList<String>();for(var remainder:recipe.getRemainingItems(input))if(!remainder.isEmpty())returns.add(id(remainder));
            recipes.add(new RecipeAspectResolver.Recipe(id(result),keys,returns,result.getCount(),0));
        }
        return new RecipeAspectResolver(seeds,recipes,Map.of(
                "minecraft:paper",Map.of("cognitio",2),
                "minecraft:arrow",Map.of("aversio",5),
                "minecraft:lever",Map.of("machina",5),
                "minecraft:piston",Map.of("machina",10,"motus",10),
                "minecraft:crafting_table",Map.of("fabrico",20),
                "minecraft:bookshelf",Map.of("cognitio",8),
                "minecraft:torch",Map.of("lux",5),
                "thaumcraft:arcane_workbench",Map.of("praecantatio",5,"auram",5)),
                Map.of("thaumcraft:arcane_workbench","minecraft:crafting_table"));
    }
    private static String id(ItemStack stack){return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();}
    private NativeRecipeAspectGraph(){}
}
