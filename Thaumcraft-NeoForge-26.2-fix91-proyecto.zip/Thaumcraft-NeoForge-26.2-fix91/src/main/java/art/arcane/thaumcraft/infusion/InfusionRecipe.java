package art.arcane.thaumcraft.infusion;

import art.arcane.thaumcraft.api.AspectList;
import java.util.*;

/** Data model for stabilised infusion crafting. */
public record InfusionRecipe(String id, String centralItem, List<String> components, AspectList cost, String resultItem, int instability) {
    public InfusionRecipe { Objects.requireNonNull(id); Objects.requireNonNull(centralItem); components=List.copyOf(components); Objects.requireNonNull(cost); Objects.requireNonNull(resultItem); if(instability<0) throw new IllegalArgumentException("instability"); }
    public boolean matches(String central, List<String> offered) { return centralItem.equals(central) && offered.size()==components.size() && new HashSet<>(offered).equals(new HashSet<>(components)); }
}
