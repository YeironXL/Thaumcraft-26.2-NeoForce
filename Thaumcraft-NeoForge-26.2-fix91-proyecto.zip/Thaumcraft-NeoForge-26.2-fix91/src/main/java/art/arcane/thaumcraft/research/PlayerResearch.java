package art.arcane.thaumcraft.research;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/** Serializable-independent research state for one player; integration layer can persist it. */
public final class PlayerResearch {
    public static final MapCodec<PlayerResearch> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Codec.STRING.listOf().optionalFieldOf("researched", List.of()).forGetter(value -> List.copyOf(value.researched)),
            Codec.STRING.listOf().optionalFieldOf("scanned", List.of()).forGetter(value -> List.copyOf(value.scanned)),
            Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("knowledge", 0).forGetter(PlayerResearch::knowledge),
            Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("permanent_warp", 0).forGetter(PlayerResearch::permanentWarp),
            Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("normal_warp", 0).forGetter(PlayerResearch::normalWarp),
            Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("temporary_warp", 0).forGetter(PlayerResearch::temporaryWarp),
            Codec.unboundedMap(Codec.STRING, Codec.intRange(0, Integer.MAX_VALUE)).optionalFieldOf("stages", Map.of()).forGetter(PlayerResearch::stages),
            Codec.STRING.listOf().optionalFieldOf("crafted", List.of()).forGetter(value -> List.copyOf(value.crafted)),
            Codec.unboundedMap(Codec.STRING, Codec.intRange(0, Integer.MAX_VALUE)).optionalFieldOf("category_knowledge", Map.of()).forGetter(value -> Map.copyOf(value.categoryKnowledge))
    ).apply(instance, PlayerResearch::restore));
    private final Set<String> researched = new LinkedHashSet<>();
    private final Set<String> scanned = new LinkedHashSet<>();
    private int knowledge;
    private int permanentWarp;
    private int normalWarp;
    private int temporaryWarp;
    private final Map<String, Integer> stages = new LinkedHashMap<>();
    private final Set<String> crafted = new LinkedHashSet<>();
    private final Map<String, Integer> categoryKnowledge = new LinkedHashMap<>();
    private static PlayerResearch restore(List<String> researched, List<String> scanned, int knowledge,
            int permanentWarp, int normalWarp, int temporaryWarp, Map<String, Integer> stages,
            List<String> crafted, Map<String, Integer> categoryKnowledge) {
        PlayerResearch value = new PlayerResearch();
        value.researched.addAll(researched);
        value.scanned.addAll(scanned);
        value.knowledge = knowledge;
        value.permanentWarp = permanentWarp;
        value.normalWarp = normalWarp;
        value.temporaryWarp = temporaryWarp;
        stages.forEach((key, stage) -> { if (value.researched.contains(key)) value.stages.put(key, stage); });
        value.crafted.addAll(crafted);
        value.categoryKnowledge.putAll(categoryKnowledge);
        return value;
    }
    public boolean unlock(String key) { return researched.add(key); }
    public boolean has(String key) {
        int separator = key.indexOf('@');
        if (separator < 0) return researched.contains(key);
        try { return researched.contains(key.substring(0, separator)) && stage(key.substring(0, separator)) >= Integer.parseInt(key.substring(separator + 1)); }
        catch (NumberFormatException exception) { return false; }
    }
    public int stage(String key) { return researched.contains(key) ? stages.getOrDefault(key, 0) : -1; }
    public void setStage(String key, int value) { if (researched.contains(key) && value > 0) stages.put(key, value); }
    public Map<String, Integer> stages() { return Map.copyOf(stages); }
    public boolean recordCraft(String item) { return crafted.add(item); }
    public boolean crafted(String item) { return crafted.contains(item); }
    public int knowledge(String type, String category) { return categoryKnowledge.getOrDefault(type + ";" + category, 0); }
    public void addKnowledge(String type, String category, int rawAmount) {
        String key = type + ";" + category;
        categoryKnowledge.put(key, (int)Math.clamp((long)categoryKnowledge.getOrDefault(key, 0) + rawAmount, 0L, Integer.MAX_VALUE));
    }
    public boolean scan(String key) { return scanned.add(key); }
    public boolean scanned(String key) { return scanned.contains(key); }
    public int knowledge() { return knowledge; }
    public void addKnowledge(int amount) { knowledge = (int)Math.clamp((long)knowledge + amount, 0L, Integer.MAX_VALUE); }
    public Set<String> researched() { return Set.copyOf(researched); }
    public void clearOldCelestial(String prefix) { researched.removeIf(key -> key.startsWith("CEL_") && !key.startsWith(prefix)); }
    public Set<String> scannedObjects() { return Set.copyOf(scanned); }
    public int permanentWarp() { return permanentWarp; }
    public int normalWarp() { return normalWarp; }
    public int temporaryWarp() { return temporaryWarp; }
    public void setPermanentWarp(int value) { permanentWarp = Math.max(0, value); }
    public void setNormalWarp(int value) { normalWarp = Math.max(0, value); }
    public void setTemporaryWarp(int value) { temporaryWarp = Math.max(0, value); }
}
