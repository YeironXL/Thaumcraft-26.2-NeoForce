package art.arcane.thaumcraft.registry;

import art.arcane.thaumcraft.Thaumcraft;
import art.arcane.thaumcraft.research.PlayerResearch;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public final class ModAttachments {
    private static final DeferredRegister<AttachmentType<?>> TYPES =
            DeferredRegister.create(NeoForgeRegistries.Keys.ATTACHMENT_TYPES, Thaumcraft.MOD_ID);
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<PlayerResearch>> RESEARCH =
            TYPES.register("player_research", () -> AttachmentType.builder(PlayerResearch::new)
                    .serialize(PlayerResearch.CODEC).copyOnDeath().build());
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<art.arcane.thaumcraft.aura.ChunkAura>> AURA =
            TYPES.register("chunk_aura", () -> AttachmentType.builder(art.arcane.thaumcraft.aura.ChunkAura::new)
                    .serialize(art.arcane.thaumcraft.aura.ChunkAura.CODEC).build());
    public static void register(IEventBus bus) { TYPES.register(bus); }
    private ModAttachments() {}
}
