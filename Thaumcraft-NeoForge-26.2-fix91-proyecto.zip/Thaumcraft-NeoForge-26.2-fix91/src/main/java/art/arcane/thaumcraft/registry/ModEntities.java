package art.arcane.thaumcraft.registry;

import art.arcane.thaumcraft.Thaumcraft;
import art.arcane.thaumcraft.entity.AlumentumProjectile;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    private static final DeferredRegister<EntityType<?>> TYPES=DeferredRegister.create(Registries.ENTITY_TYPE,Thaumcraft.MOD_ID);
    public static final DeferredHolder<EntityType<?>,EntityType<AlumentumProjectile>> ALUMENTUM=TYPES.register("alumentum",()->
        EntityType.Builder.<AlumentumProjectile>of(AlumentumProjectile::new,MobCategory.MISC)
            .sized(0.25F,0.25F).clientTrackingRange(4).updateInterval(10)
            .build(ResourceKey.create(Registries.ENTITY_TYPE,Identifier.fromNamespaceAndPath(Thaumcraft.MOD_ID,"alumentum"))));
    public static void register(IEventBus bus) { TYPES.register(bus); }
    private ModEntities() {}
}
