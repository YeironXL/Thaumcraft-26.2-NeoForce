package art.arcane.thaumcraft.progression;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

import net.minecraft.server.level.ServerPlayer;

import art.arcane.thaumcraft.research.PlayerResearch;
import art.arcane.thaumcraft.registry.ModAttachments;

/**
 * Server-owned progression saved with each player and copied on respawn.
 */
public final class PlayerProgressManager {

    private PlayerProgressManager() {}

    public static PlayerResearch get(ServerPlayer player) {
        return player.getData(ModAttachments.RESEARCH.get());
    }

    public static boolean unlock(ServerPlayer player, String key) {
        return get(player).unlock(key);
    }

    public static boolean has(ServerPlayer player, String key) {
        return get(player).has(key);
    }

    public static boolean scan(ServerPlayer player, String key) {
        return get(player).scan(key);
    }

    public static Set<String> researched(ServerPlayer player) {
        return Collections.unmodifiableSet(new LinkedHashSet<>(get(player).researched()));
    }

    public static Set<String> scanned(ServerPlayer player) {
        return Collections.unmodifiableSet(new LinkedHashSet<>(get(player).scannedObjects()));
    }

    public static int getWarp(ServerPlayer player, WarpType type) {
        PlayerResearch research = get(player);
        return switch (type) {
            case NORMAL -> research.normalWarp();
            case TEMPORARY -> research.temporaryWarp();
            case PERMANENT -> research.permanentWarp();
        };
    }

    public static int addWarp(ServerPlayer player, WarpType type, int delta) {
        PlayerResearch research = get(player);
        int next = (int)Math.clamp((long)getWarp(player, type) + delta, 0L, Integer.MAX_VALUE);
        switch (type) {
            case NORMAL -> research.setNormalWarp(next);
            case TEMPORARY -> research.setTemporaryWarp(next);
            case PERMANENT -> research.setPermanentWarp(next);
        }
        return next;
    }

    public enum WarpType { PERMANENT, NORMAL, TEMPORARY }
}
