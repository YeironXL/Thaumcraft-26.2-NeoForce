package art.arcane.thaumcraft.scan;

import art.arcane.thaumcraft.aspect.Aspect;
import art.arcane.thaumcraft.aspect.AspectRegistry;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

public final class EntityScanRegistry {
    private static final Map<String,Map<Aspect,Integer>> ENTRIES=new LinkedHashMap<>();
    static {
        try (var reader=new InputStreamReader(EntityScanRegistry.class.getResourceAsStream("/assets/thaumcraft/migration/entity_aspects.json"),StandardCharsets.UTF_8)) {
            JsonParser.parseReader(reader).getAsJsonObject().entrySet().forEach(entity -> {
                var aspects=new LinkedHashMap<Aspect,Integer>();
                entity.getValue().getAsJsonObject().entrySet().forEach(tag -> aspects.put(java.util.Objects.requireNonNull(AspectRegistry.get(tag.getKey())),tag.getValue().getAsInt()));
                ENTRIES.put(entity.getKey(),Map.copyOf(aspects));
            });
        } catch (java.io.IOException exception) { throw new ExceptionInInitializerError(exception); }
    }
    public static Map<Aspect,Integer> get(String id) { return ENTRIES.getOrDefault(id,Map.of()); }
    private EntityScanRegistry() {}
}
