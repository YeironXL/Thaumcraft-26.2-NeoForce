package art.arcane.thaumcraft.crafting;

import art.arcane.thaumcraft.registry.ModRecipes;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.Level;
import java.util.Map;

public record CrucibleRecipe(Ingredient catalyst,ItemStackTemplate result,String research,Map<String,Integer> aspects,String catalystAspect) implements Recipe<SingleRecipeInput> {
    public static final MapCodec<CrucibleRecipe> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            Ingredient.CODEC.fieldOf("catalyst").forGetter(CrucibleRecipe::catalyst),
            ItemStackTemplate.CODEC.fieldOf("result").forGetter(CrucibleRecipe::result),
            Codec.STRING.fieldOf("research").forGetter(CrucibleRecipe::research),
            Codec.unboundedMap(Codec.STRING,Codec.intRange(1,1000000)).fieldOf("aspects").forGetter(CrucibleRecipe::aspects),
            Codec.STRING.optionalFieldOf("catalyst_aspect","").forGetter(CrucibleRecipe::catalystAspect)
    ).apply(i,CrucibleRecipe::new));
    public static final StreamCodec<RegistryFriendlyByteBuf,CrucibleRecipe> STREAM_CODEC=StreamCodec.composite(
            Ingredient.CONTENTS_STREAM_CODEC,CrucibleRecipe::catalyst,ItemStackTemplate.STREAM_CODEC,CrucibleRecipe::result,
            ByteBufCodecs.STRING_UTF8,CrucibleRecipe::research,
            ByteBufCodecs.map(java.util.HashMap::new,ByteBufCodecs.STRING_UTF8,ByteBufCodecs.VAR_INT),CrucibleRecipe::aspects,ByteBufCodecs.STRING_UTF8,CrucibleRecipe::catalystAspect,CrucibleRecipe::new);
    public CrucibleRecipe { aspects=Map.copyOf(aspects); }
    /** TC6 chooses the affordable known recipe with the greatest total aspect cost; ties keep first. */
    public static CrucibleRecipe select(Iterable<CrucibleRecipe> recipes,java.util.function.Predicate<CrucibleRecipe> eligible){
        long highest=0;CrucibleRecipe chosen=null;
        for(var recipe:recipes){if(!eligible.test(recipe))continue;long total=recipe.aspects().values().stream().mapToLong(Integer::longValue).sum();if(total>highest){highest=total;chosen=recipe;}}
        return chosen;
    }
    @Override public boolean matches(SingleRecipeInput input,Level level) { return catalyst.test(input.item()) && (catalystAspect.isEmpty() || catalystAspect.equals(art.arcane.thaumcraft.item.CrystalEssenceItem.aspect(input.item()))); }
    @Override public ItemStack assemble(SingleRecipeInput input) { return result.create(); }
    @Override public RecipeSerializer<CrucibleRecipe> getSerializer() { return ModRecipes.CRUCIBLE.get(); }
    @Override public RecipeType<CrucibleRecipe> getType() { return ModRecipes.CRUCIBLE_TYPE.get(); }
    @Override public boolean showNotification() { return false; }
    @Override public String group() { return "thaumcraft:crucible"; }
    @Override public PlacementInfo placementInfo() { return PlacementInfo.NOT_PLACEABLE; }
    @Override public RecipeBookCategory recipeBookCategory() { return RecipeBookCategories.CRAFTING_MISC; }
}
