package art.arcane.thaumcraft.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/** Original research-browser category frame with the authored category icon. */
final class ResearchCategoryButton extends Button {
    private final int category;
    private final boolean selected;
    ResearchCategoryButton(Builder builder,int category,boolean selected){super(builder);this.category=category;this.selected=selected;}
    @Override protected void extractContents(GuiGraphicsExtractor g,int mouseX,int mouseY,float tick){
        g.blit(RenderPipelines.GUI_TEXTURED,Identifier.parse("thaumcraft:textures/gui/gui_research_browser.png"),getX()-3,getY()-3,13,13,22,22,256,256,selected?0xFF99FFFF:0xFFFFFFFF);
        g.blit(RenderPipelines.GUI_TEXTURED,TheoryCardButton.categoryIcon(category),getX(),getY(),0,0,16,16,32,32,32,32,selected||isHoveredOrFocused()?0xFFFFFFFF:0xCCAAAAAA);
        if(isFocused())g.outline(getX(),getY(),22,22,0xFFE5C46C);
    }
}
