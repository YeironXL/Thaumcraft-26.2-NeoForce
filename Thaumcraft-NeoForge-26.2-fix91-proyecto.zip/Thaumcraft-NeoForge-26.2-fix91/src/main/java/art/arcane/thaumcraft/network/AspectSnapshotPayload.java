package art.arcane.thaumcraft.network;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import java.util.*;
public record AspectSnapshotPayload(String data) implements CustomPacketPayload{
    public static final Type<AspectSnapshotPayload> TYPE=new Type<>(Identifier.fromNamespaceAndPath("thaumcraft","aspect_snapshot"));
    public static final StreamCodec<RegistryFriendlyByteBuf,AspectSnapshotPayload> CODEC=StreamCodec.composite(ByteBufCodecs.STRING_UTF8,AspectSnapshotPayload::data,AspectSnapshotPayload::new);
    public Type<AspectSnapshotPayload> type(){return TYPE;}
    public static AspectSnapshotPayload of(Map<String,Map<String,Integer>> values){return new AspectSnapshotPayload(new com.google.gson.Gson().toJson(values));}
    public Map<String,Map<String,Integer>> values(){var result=new LinkedHashMap<String,Map<String,Integer>>();var json=com.google.gson.JsonParser.parseString(data).getAsJsonObject();if(json.size()>64)throw new IllegalArgumentException("Oversized aspects");json.entrySet().forEach(entry->{var tags=new LinkedHashMap<String,Integer>();entry.getValue().getAsJsonObject().entrySet().forEach(tag->tags.put(tag.getKey(),tag.getValue().getAsInt()));result.put(entry.getKey(),tags);});return result;}
}
