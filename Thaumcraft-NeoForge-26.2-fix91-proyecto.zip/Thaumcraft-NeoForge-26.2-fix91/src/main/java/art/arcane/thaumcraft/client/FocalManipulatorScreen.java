package art.arcane.thaumcraft.client;
import art.arcane.thaumcraft.menu.FocalManipulatorMenu;
import art.arcane.thaumcraft.focus.TouchFireFocus;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
public class FocalManipulatorScreen extends AbstractContainerScreen<FocalManipulatorMenu>{
    private final Button[] controls=new Button[5];
    public FocalManipulatorScreen(FocalManipulatorMenu menu,Inventory inventory,Component title){super(menu,inventory,title,231,231);inventoryLabelX=-62;inventoryLabelY=54;}
    private void send(int action){if(minecraft.gameMode!=null)minecraft.gameMode.handleInventoryButtonClick(menu.containerId,menu.button(action));}
    private void change(int dp,int dd){int p=menu.value(1)+dp,d=menu.value(2)+dd;if(p>=1&&p<=5&&d>=0&&d<=5&&2+2*p+d<=15)send(FocalManipulatorMenu.selection(p,d));}
    @Override protected void init(){super.init();for(int i=0;i<4;i++){final int action=i;controls[i]=addRenderableWidget(Button.builder(Component.literal(i%2==0?"−":"+"),b->change(action<2?(action==0?-1:1):0,action>=2?(action==2?-1:1):0)).bounds(leftPos+231+(i%2)*32,topPos+182+(i/2)*26,10,10).build(builder->new Button(builder){
            @Override protected void extractContents(GuiGraphicsExtractor g,int mx,int my,float tick){g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,net.minecraft.resources.Identifier.parse("thaumcraft:textures/gui/gui_base.png"),getX(),getY(),action%2==0?20:30,0,10,10,256,256,active?0xFFFFFFFF:0xFF777777);}
        }));}
        controls[4]=addRenderableWidget(Button.builder(Component.translatable("screen.thaumcraft.focus.start"),b->send(0)).bounds(leftPos+220,topPos-1,24,16).tooltip(net.minecraft.client.gui.components.Tooltip.create(Component.translatable("screen.thaumcraft.focus.start"))).build(builder->new Button(builder){
            @Override protected void extractContents(GuiGraphicsExtractor g,int mx,int my,float tick){g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,net.minecraft.resources.Identifier.parse("thaumcraft:textures/gui/gui_base.png"),getX(),getY(),232,240,24,16,256,256,active?0xFFFFFFFF:0xFF777777);}
        }));}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float tick){int p=menu.value(1),d=menu.value(2);
        for(int i=0;i<4;i++){int np=p+(i<2?(i==0?-1:1):0),nd=d+(i>=2?(i==2?-1:1):0);controls[i].active=!menu.working()&&np>=1&&np<=5&&nd>=0&&nd<=5&&2+2*np+nd<=15;}
        controls[4].active=!menu.working()&&menu.slots.get(0).hasItem();super.extractRenderState(g,mouseX,mouseY,tick);}
    @Override public void extractBackground(GuiGraphicsExtractor g,int mouseX,int mouseY,float tick){super.extractBackground(g,mouseX,mouseY,tick);g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,net.minecraft.resources.Identifier.parse("thaumcraft:textures/gui/gui_wandtable2.png"),leftPos,topPos,0,0,231,231,256,256);
        g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,net.minecraft.resources.Identifier.parse("thaumcraft:textures/gui/gui_wandtable3.png"),leftPos-71,topPos-3,0,0,71,239,256,256);

        var atlas=net.minecraft.resources.Identifier.parse("thaumcraft:textures/gui/gui_wandtable.png");
        if(menu.slots.get(0).hasItem()){
            for(int node=0;node<2;node++){
                int cx=leftPos+132,cy=topPos+48+node*32;
                g.pose().pushMatrix();g.pose().translate(cx,cy);g.pose().rotate(-(float)Math.PI/2);
                var ring=net.minecraft.resources.Identifier.parse("thaumcraft:textures/foci/"+(node==0?"_medium":"_effect")+".png");
                g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,ring,-14,-14,0,0,28,28,32,32,32,32,node==0?(0xFF000000|11371909):(0xFF000000|16734721));
                var icon=net.minecraft.resources.Identifier.parse("thaumcraft:textures/foci/"+(node==0?"touch":"fire")+".png");
                g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,icon,-8,-8,0,0,16,16,32,32,32,32);
                g.pose().popMatrix();
                if(node>0)g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,atlas,cx-6,cy-22,54,232,12,12,256,256);
            }
        }
        g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,atlas,leftPos,topPos,0,0,231,231,256,256);
    }
    @Override protected void extractLabels(GuiGraphicsExtractor g,int mouseX,int mouseY){
        var f=new TouchFireFocus(menu.value(1),menu.value(2));
        for(int i=0;i<3;i++){
            var icon=net.minecraft.resources.Identifier.parse("thaumcraft:textures/gui/"+new String[]{"complex","costxp","costvis"}[i]+".png");
            g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,icon,241,39+i*14,0,0,16,16,16,16,16,16);
            g.text(font,Integer.toString(i==0?2+2*f.power()+f.duration():i==1?f.craftingLevels():f.craftingVis()),260,39+i*14,0xFFFFC43F,true);
        }
        g.text(font,Component.translatable("screen.thaumcraft.focus.power",f.power()),231,170,0xFFFFFFFF,true);
        g.text(font,Component.translatable("screen.thaumcraft.focus.duration",f.duration()),231,196,0xFFFFFFFF,true);
        if(menu.working())g.text(font,Component.translatable("screen.thaumcraft.focus.remaining",menu.value(3)),231,90,0xFFFFFFFF,true);
    }
}
