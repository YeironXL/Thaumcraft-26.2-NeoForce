package art.arcane.thaumcraft.item;
import art.arcane.thaumcraft.ModItems;
import art.arcane.thaumcraft.registry.ModComponents;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ItemContainerContents;
import java.util.List;
/** Native inventory gesture preserves the whole equipped item, including custom components. */
public final class CasterGauntletItem extends Item {
    public CasterGauntletItem(Properties properties){super(properties.stacksTo(1));}
    public static ItemStack equipped(ItemStack gauntlet){
        if(!gauntlet.is(ModItems.CASTER_BASIC.get()))return ItemStack.EMPTY;
        var contents=gauntlet.get(ModComponents.EQUIPPED_FOCUS.get());
        return contents==null||contents.getSlots()!=1?ItemStack.EMPTY:contents.getStackInSlot(0);
    }
    @Override public net.minecraft.world.InteractionResult use(net.minecraft.world.level.Level level,Player player,net.minecraft.world.InteractionHand hand){
        if(!usable(equipped(player.getItemInHand(hand))))return net.minecraft.world.InteractionResult.PASS;
        return player instanceof net.minecraft.server.level.ServerPlayer server?art.arcane.thaumcraft.focus.TouchFireCasting.cast(server,hand):net.minecraft.world.InteractionResult.SUCCESS;
    }
    @Override public void appendHoverText(ItemStack stack,Item.TooltipContext context,net.minecraft.world.item.component.TooltipDisplay display,java.util.function.Consumer<net.minecraft.network.chat.Component> lines,TooltipFlag flag){
        super.appendHoverText(stack,context,display,lines,flag);
        lines.accept(net.minecraft.network.chat.Component.translatable("item.thaumcraft.caster_basic.mount_help"));
        var focus=equipped(stack).get(ModComponents.TOUCH_FIRE_FOCUS.get());
        if(focus!=null)lines.accept(net.minecraft.network.chat.Component.translatable("item.thaumcraft.caster_basic.focus_help",focus.power(),focus.duration(),focus.castingVis(),focus.cooldownTicks()));
    }
    private static boolean usable(ItemStack focus){return focus.is(ModItems.FOCUS_1.get())&&focus.getCount()==1&&focus.has(ModComponents.TOUCH_FIRE_FOCUS.get());}
    @Override public boolean overrideOtherStackedOnMe(ItemStack self,ItemStack other,Slot slot,ClickAction action,Player player,SlotAccess cursor){
        if(action!=ClickAction.SECONDARY||self.getCount()!=1||!slot.allowModification(player))return false;
        var previous=equipped(self);
        if(other.isEmpty()){
            if(previous.isEmpty()||!cursor.set(previous))return false;
            self.remove(ModComponents.EQUIPPED_FOCUS.get());
        }else{
            if(!usable(other))return false;
            var mounted=other.copy();
            if(!cursor.set(previous))return false;
            self.set(ModComponents.EQUIPPED_FOCUS.get(),ItemContainerContents.fromItems(List.of(mounted)));
        }
        slot.setChanged();return true;
    }
}
