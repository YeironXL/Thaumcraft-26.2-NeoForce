package art.arcane.thaumcraft.item;

import art.arcane.thaumcraft.ModBlocks;
import art.arcane.thaumcraft.ModItems;
import art.arcane.thaumcraft.progression.PlayerProgressManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.Blocks;

/** First-pass Salis Mundus progression triggers. */
public final class SalisMundusItem extends Item {
    public SalisMundusItem(Item.Properties properties) {
        super(properties.rarity(net.minecraft.world.item.Rarity.UNCOMMON));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (context.getLevel().isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (!(context.getPlayer() instanceof ServerPlayer player)) {
            return InteractionResult.PASS;
        }
        if (player.isShiftKeyDown() || !player.mayUseItemAt(context.getClickedPos(), context.getClickedFace(), context.getItemInHand()))
            return InteractionResult.PASS;

        BlockPos pos = context.getClickedPos();
        var state = context.getLevel().getBlockState(pos);

        if (state.is(Blocks.BOOKSHELF)) {
            if (!PlayerProgressManager.has(player, "!gotdream")) return InteractionResult.PASS;
            context.getLevel().setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
            net.minecraft.world.level.block.Block.popResource(context.getLevel(), pos, new ItemStack(ModItems.THAUMONOMICON.get()));
            PlayerProgressManager.get(player).recordCraft("thaumcraft:thaumonomicon");
            consume(context.getItemInHand(), player);
            context.getLevel().levelEvent(2001, pos, net.minecraft.world.level.block.Block.getId(state));
            return InteractionResult.SUCCESS;
        }

        if (state.is(Blocks.CRAFTING_TABLE) || state.is(Blocks.CAULDRON)) {
            String prerequisite = state.is(Blocks.CRAFTING_TABLE) ? "FIRSTSTEPS@1" : "UNLOCKALCHEMY@1";
            if (!PlayerProgressManager.has(player, prerequisite)) return InteractionResult.PASS;
            var result = state.is(Blocks.CRAFTING_TABLE) ? ModBlocks.ARCANE_WORKBENCH.get() : ModBlocks.CRUCIBLE.get();
            context.getLevel().setBlockAndUpdate(pos, result.defaultBlockState());
            PlayerProgressManager.get(player).recordCraft(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(result).toString());
            consume(context.getItemInHand(), player);
            context.getLevel().levelEvent(2001, pos, net.minecraft.world.level.block.Block.getId(state));
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }

    private static void consume(ItemStack stack, ServerPlayer player) {
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
    }
}
