package art.arcane.thaumcraft.item;

import art.arcane.thaumcraft.progression.PlayerProgressManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;

/** Shows the player's current warp state while the full HUD is being ported. */
public final class SanityCheckerItem extends Item {
    public SanityCheckerItem(Item.Properties properties) {
        super(properties.stacksTo(1).rarity(Rarity.UNCOMMON));
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResult.SUCCESS;
        }
        int permanent = PlayerProgressManager.getWarp(serverPlayer, PlayerProgressManager.WarpType.PERMANENT);
        int normal = PlayerProgressManager.getWarp(serverPlayer, PlayerProgressManager.WarpType.NORMAL);
        int temporary = PlayerProgressManager.getWarp(serverPlayer, PlayerProgressManager.WarpType.TEMPORARY);
        serverPlayer.sendOverlayMessage(Component.literal(
                "Warp — Permanent: " + permanent + " | Normal: " + normal + " | Temporary: " + temporary));
        return InteractionResult.SUCCESS;
    }
}
