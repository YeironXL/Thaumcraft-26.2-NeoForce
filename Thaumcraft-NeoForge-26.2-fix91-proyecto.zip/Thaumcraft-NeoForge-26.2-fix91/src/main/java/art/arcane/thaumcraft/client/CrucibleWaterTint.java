package art.arcane.thaumcraft.client;

import art.arcane.thaumcraft.blockentity.CrucibleBlockEntity;
import net.minecraft.client.color.block.BlockTintSource;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

/** RGB multipliers from TC6 TileCrucibleRenderer.renderFluid; no biome water tint. */
public final class CrucibleWaterTint implements BlockTintSource {
    public static int colorFor(long aspects){
        float recolor=Math.max(0,aspects)/500f;
        if(recolor>0)recolor=.5f+recolor/2;
        recolor=Math.min(1,recolor);
        return 0xFF000000 | Math.round(255*(1-recolor/3))<<16 | Math.round(255*(1-recolor))<<8 | Math.round(255*(1-recolor/2));
    }
    @Override public int color(BlockState state){return colorFor(0);}
    @Override public int colorInWorld(BlockState state,BlockAndTintGetter world,BlockPos pos){
        return colorFor(world.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible?crucible.mixture().total():0);
    }
}
