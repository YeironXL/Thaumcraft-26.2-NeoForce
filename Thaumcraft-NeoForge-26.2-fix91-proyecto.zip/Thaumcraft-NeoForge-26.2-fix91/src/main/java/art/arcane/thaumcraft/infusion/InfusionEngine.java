package art.arcane.thaumcraft.infusion;

import art.arcane.thaumcraft.api.AspectContainer;
import art.arcane.thaumcraft.aspect.Aspect;
import java.util.ArrayList;
import java.util.List;

/** Deterministic infusion validation layer. GUI/network integration can call this from the server. */
public final class InfusionEngine {
    public record Requirement(Aspect aspect, int amount) {}
    public record Recipe(String id, String centralItem, List<String> components, List<Requirement> aspects, String resultItem) {}
    private final List<Recipe> recipes = new ArrayList<>();
    public void add(Recipe recipe) { recipes.add(recipe); }
    public List<Recipe> recipes() { return List.copyOf(recipes); }
    public boolean canCraft(Recipe recipe, String central, List<String> components, AspectContainer pool) {
        if (!recipe.centralItem().equals(central)) return false;
        if (!recipe.components().equals(components)) return false;
        for (Requirement r : recipe.aspects()) if (!pool.contains(r.aspect(), r.amount())) return false;
        return true;
    }
}
