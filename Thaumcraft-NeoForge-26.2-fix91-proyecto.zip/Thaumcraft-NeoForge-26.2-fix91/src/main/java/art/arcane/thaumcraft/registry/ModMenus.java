package art.arcane.thaumcraft.registry;

import art.arcane.thaumcraft.Thaumcraft;
import art.arcane.thaumcraft.menu.ArcaneWorkbenchMenu;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModMenus {
    private static final DeferredRegister<MenuType<?>> TYPES = DeferredRegister.create(Registries.MENU,Thaumcraft.MOD_ID);
    public static final DeferredHolder<MenuType<?>, MenuType<ArcaneWorkbenchMenu>> ARCANE_WORKBENCH = TYPES.register("arcane_workbench", () -> new MenuType<>(ArcaneWorkbenchMenu::new,FeatureFlags.DEFAULT_FLAGS));
    public static void register(IEventBus bus) { TYPES.register(bus); }
    public static final DeferredHolder<MenuType<?>, MenuType<art.arcane.thaumcraft.menu.EssentiaSmelterMenu>> ESSENTIA_SMELTER = TYPES.register("essentia_smelter", () -> new MenuType<>(art.arcane.thaumcraft.menu.EssentiaSmelterMenu::new,FeatureFlags.DEFAULT_FLAGS));
    public static final DeferredHolder<MenuType<?>,MenuType<art.arcane.thaumcraft.menu.ResearchTableMenu>> RESEARCH_TABLE=TYPES.register("research_table",()->new MenuType<>(art.arcane.thaumcraft.menu.ResearchTableMenu::new,FeatureFlags.DEFAULT_FLAGS));
    public static final DeferredHolder<MenuType<?>,MenuType<art.arcane.thaumcraft.menu.FocalManipulatorMenu>> FOCAL_MANIPULATOR=TYPES.register("focal_manipulator",()->new MenuType<>(art.arcane.thaumcraft.menu.FocalManipulatorMenu::new,FeatureFlags.DEFAULT_FLAGS));
    private ModMenus() {}
}
