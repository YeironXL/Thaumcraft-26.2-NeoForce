package art.arcane.thaumcraft.block;

import art.arcane.thaumcraft.blockentity.CrucibleBlockEntity;
import art.arcane.thaumcraft.registry.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.*;

public final class CrucibleBlock extends BaseEntityBlock {
    private static final MapCodec<CrucibleBlock> CODEC=simpleCodec(CrucibleBlock::new);
    public static final IntegerProperty WATER=IntegerProperty.create("water",0,4);
    private static final VoxelShape SHAPE=Shapes.or(Block.box(0,0,0,16,5,16),Block.box(0,5,0,2,16,16),
            Block.box(14,5,0,16,16,16),Block.box(2,5,0,14,16,2),Block.box(2,5,14,14,16,16));
    public CrucibleBlock(Properties properties) { super(properties.strength(2).sound(SoundType.METAL).noOcclusion()); registerDefaultState(defaultBlockState().setValue(WATER,0)); }
    @Override protected MapCodec<CrucibleBlock> codec() { return CODEC; }
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> builder) { builder.add(WATER); }
    @Override protected VoxelShape getShape(BlockState state,BlockGetter level,BlockPos pos,CollisionContext context) { return SHAPE; }
    @Override public BlockEntity newBlockEntity(BlockPos pos,BlockState state) { return new CrucibleBlockEntity(pos,state); }
    @Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level,BlockState state,BlockEntityType<T> type) {
        return createTickerHelper(type,ModBlockEntities.CRUCIBLE.get(),CrucibleBlockEntity::tick);
    }
    @Override protected InteractionResult useItemOn(ItemStack stack,BlockState state,Level level,BlockPos pos,Player player,InteractionHand hand,BlockHitResult hit) {
        if (!player.mayUseItemAt(pos,hit.getDirection(),stack)) return InteractionResult.PASS;
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer actor) || !(level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible)) return InteractionResult.PASS;
        if (stack.is(Items.WATER_BUCKET) && crucible.mixture().fill()) {
            player.setItemInHand(hand,ItemUtils.createFilledResult(stack,player,new ItemStack(Items.BUCKET)));
            crucible.changed(); return InteractionResult.SUCCESS;
        }
        if (!player.isShiftKeyDown() && hit.getDirection() == Direction.UP && crucible.processOne(stack,actor)) {
            stack.shrink(1); return InteractionResult.SUCCESS;
        }
        return InteractionResult.TRY_WITH_EMPTY_HAND;
    }
    @Override protected InteractionResult useWithoutItem(BlockState state,Level level,BlockPos pos,Player player,BlockHitResult hit) {
        if (!player.isShiftKeyDown() || !player.getMainHandItem().isEmpty()) return InteractionResult.PASS;
        if (!level.isClientSide() && level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible) crucible.empty();
        return InteractionResult.SUCCESS;
    }
    @Override protected boolean hasAnalogOutputSignal(BlockState state) { return true; }
    @Override protected int getAnalogOutputSignal(BlockState state,Level level,BlockPos pos,Direction direction) {
        if (!(level.getBlockEntity(pos) instanceof CrucibleBlockEntity crucible)) return 0;
        long total=crucible.mixture().total(); return total == 0 ? 0 : (int)Math.min(15,1+total*14/500);
    }
}
