package art.arcane.thaumcraft.verification;

import art.arcane.thaumcraft.*;
import art.arcane.thaumcraft.aura.NativeAura;
import art.arcane.thaumcraft.blockentity.*;
import art.arcane.thaumcraft.crafting.CrucibleRecipe;
import art.arcane.thaumcraft.item.CrystalEssenceItem;
import art.arcane.thaumcraft.progression.PlayerProgressManager;
import art.arcane.thaumcraft.registry.ModRecipes;
import art.arcane.thaumcraft.research.*;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.GameType;
import java.util.*;

public final class EarlyFocusVerification {
    private static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    private static ItemStack craft(GameTestHelper h,int width,int height,List<ItemStack> stacks){
        var input=CraftingInput.of(width,height,stacks);return h.getLevel().getServer().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,input,h.getLevel()).orElseThrow().value().assemble(input);
    }
    private static void fire(ServerPlayer player,net.minecraft.world.damagesource.DamageSource source){
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(new net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Pre(player,new net.neoforged.neoforge.common.damagesource.DamageContainer(source,1)));
    }
    private static ServerPlayer verifyBeginning(GameTestHelper h){
        var world=h.getLevel();var player=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);var research=PlayerProgressManager.get(player);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(new net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent(player));
        check(player.getInventory().countItem(ModItems.THAUMONOMICON.get())==1&&research.researched().stream().noneMatch(key->key.equals("FIRSTSTEPS")),"New player already progressed or missed book");
        player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new ItemStack(ModItems.THAUMONOMICON.get()));ModItems.THAUMONOMICON.get().use(world,player,net.minecraft.world.InteractionHand.MAIN_HAND);
        check(research.has("!gotthaumonomicon")&&ResearchProgression.advance(research,"FIRSTSTEPS",-1,cost->cost.isEmpty()),"Opening starter book did not unlock first research stage");
        var relative=new BlockPos(14,1,4);h.setBlock(relative,net.minecraft.world.level.block.Blocks.CRAFTING_TABLE);var pos=h.absolutePos(relative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(pos));
        player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new ItemStack(ModItems.SALIS_MUNDUS.get(),2));
        var context=new net.minecraft.world.item.context.UseOnContext(player,net.minecraft.world.InteractionHand.MAIN_HAND,new net.minecraft.world.phys.BlockHitResult(net.minecraft.world.phys.Vec3.atCenterOf(pos),net.minecraft.core.Direction.UP,pos,false));
        check(ModItems.SALIS_MUNDUS.get().useOn(context)==net.minecraft.world.InteractionResult.SUCCESS&&player.getMainHandItem().getCount()==1&&world.getBlockState(pos).is(ModBlocks.ARCANE_WORKBENCH.get()),"Survival Salis conversion failed");
        check(ResearchProgression.advance(research,"FIRSTSTEPS",1,cost->cost.isEmpty())&&research.stage("FIRSTSTEPS")==2,"Workbench craft history did not advance first stage");
        var bench=h.getBlockEntity(relative,ArcaneWorkbenchBlockEntity.class);for(int slot:new int[]{1,3,5,7})bench.setItem(slot,new ItemStack(Items.GOLD_INGOT));bench.setItem(4,new ItemStack(Items.GLASS_PANE));
        for(int primal=0;primal<6;primal++)bench.setItem(9+primal,CrystalEssenceItem.of(ArcaneWorkbenchBlockEntity.PRIMALS.get(primal),1));
        var aura=NativeAura.get(world,world.getChunkAt(pos));aura.spend(aura.vis());aura.addVis(20);
        var thermometer=bench.takeOutput(player,1);check(thermometer.is(ModItems.THAUMOMETER.get())&&aura.vis()==0,"Initial thaumometer recipe/cost blocked player");player.getInventory().add(thermometer);
        check(!ResearchProgression.advance(research,"FIRSTSTEPS",2,cost->cost.isEmpty()),"First steps bypassed observation requirement");
        for(var entry:art.arcane.thaumcraft.scan.ScanRegistry.all().entrySet())art.arcane.thaumcraft.scan.ScanProgression.record(research,entry.getKey(),entry.getValue());
        check(ResearchProgression.advance(research,"FIRSTSTEPS",2,cost->cost.isEmpty())&&ResearchRules.complete(research,"FIRSTSTEPS"),"Available initial scan targets did not supply required observations");
        check(ResearchProgression.advance(research,"UNLOCKALCHEMY",-1,cost->cost.isEmpty()),"Alchemy could not start after first steps");
        System.out.println("New-player beginning passed with supplied materials: login/book, first research, Salis conversion, thaumometer craft, genuine scan rewards and alchemy entry.");
        return player;
    }
    private static void verifyInitialAlchemy(GameTestHelper h,ServerPlayer player){
        var world=h.getLevel();var state=PlayerProgressManager.get(player);int basics=state.knowledge("OBSERVATION","BASICS"),alchemy=state.knowledge("OBSERVATION","ALCHEMY");
        check(ResearchProgression.advance(state,"UNLOCKALCHEMY",1,cost->cost.isEmpty())&&state.knowledge("OBSERVATION","BASICS")==basics-16&&state.knowledge("OBSERVATION","ALCHEMY")==alchemy-16,"Initial alchemy knowledge cost/entry failed");
        check(!ResearchProgression.advance(state,"UNLOCKALCHEMY",2,cost->cost.isEmpty()),"Alchemy skipped crucible conversion");
        var relative=new BlockPos(14,1,8);h.setBlock(relative,net.minecraft.world.level.block.Blocks.CAULDRON);var pos=h.absolutePos(relative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(pos));
        player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new ItemStack(ModItems.SALIS_MUNDUS.get()));
        var context=new net.minecraft.world.item.context.UseOnContext(player,net.minecraft.world.InteractionHand.MAIN_HAND,new net.minecraft.world.phys.BlockHitResult(net.minecraft.world.phys.Vec3.atCenterOf(pos),net.minecraft.core.Direction.UP,pos,false));
        check(ModItems.SALIS_MUNDUS.get().useOn(context)==net.minecraft.world.InteractionResult.SUCCESS&&player.getMainHandItem().isEmpty()&&world.getBlockState(pos).is(ModBlocks.CRUCIBLE.get()),"Initial crucible conversion did not pay Salis");
        check(ResearchProgression.advance(state,"UNLOCKALCHEMY",2,cost->cost.isEmpty())&&state.stage("UNLOCKALCHEMY")==3,"Crucible history failed to advance alchemy");
        var pot=h.getBlockEntity(relative,CrucibleBlockEntity.class);pot.mixture().fill();h.setBlock(relative.below(),net.minecraft.world.level.block.Blocks.CAMPFIRE.defaultBlockState().setValue(net.minecraft.world.level.block.CampfireBlock.LIT,true));
        for(int tick=0;tick<151;tick++)CrucibleBlockEntity.tick(world,pos,pot.getBlockState(),pot);
        check(pot.mixture().boiling(),"Lit campfire beneath new crucible did not boil supplied water: heat="+pot.mixture().heat()+" below="+world.getBlockState(pos.below()));
        check(pot.processOne(new ItemStack(Items.COAL),player)&&pot.processOne(new ItemStack(Items.GLOWSTONE_DUST),player),"Initial Nitor ingredient dissolution failed");
        check(!ResearchProgression.advance(state,"UNLOCKALCHEMY",3,cost->cost.isEmpty()),"Alchemy completed before Nitor craft");
        check(pot.processOne(new ItemStack(Items.GLOWSTONE_DUST),player)&&pot.mixture().water()==950&&pot.mixture().total()==5&&state.crafted("thaumcraft:nitor_yellow"),"Initial Nitor production/cost/residual aspects incorrect");
        check(ResearchProgression.advance(state,"UNLOCKALCHEMY",3,cost->cost.isEmpty())&&ResearchRules.complete(state,"UNLOCKALCHEMY"),"Same new player could not complete initial alchemy");
        check(ResearchProgression.advance(state,"UNLOCKAUROMANCY",-1,cost->cost.isEmpty()),"Same new player could not enter auromancy");
        System.out.println("Continuous initial alchemy passed: paid observations, Salis/cauldron, lit campfire heating, real coal/glowstone dissolution, Nitor, residual Sensus5 and auromancy entry.");
    }
    private static void verifyInitialAuromancy(GameTestHelper h,ServerPlayer player){
        var world=h.getLevel();var state=PlayerProgressManager.get(player);
        check(!ResearchProgression.advance(state,"UNLOCKAUROMANCY",1,cost->cost.isEmpty()),"Auromancy skipped height discoveries");
        player.tickCount=0;player.setPos(player.getX(),world.getMinY()+5,player.getZ());
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(player));
        check(state.has("m_deepdown")&&!state.has("m_uphigh")&&!ResearchProgression.advance(state,"UNLOCKAUROMANCY",1,cost->cost.isEmpty()),"One height discovery bypassed the other");
        player.setPos(player.getX(),world.getMinY()+world.getHeight()*0.4+10,player.getZ());
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(player));
        check(state.has("m_uphigh")&&ResearchProgression.advance(state,"UNLOCKAUROMANCY",1,cost->cost.isEmpty()),"Actual height events failed auromancy progression");
        var relative=new BlockPos(14,1,4);var pos=h.absolutePos(relative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(pos));
        var bench=h.getBlockEntity(relative,ArcaneWorkbenchBlockEntity.class);bench.clearContent();
        var aura=NativeAura.get(world,world.getChunkAt(pos));aura.spend(aura.vis());aura.addVis(50);
        bench.setItem(0,new ItemStack(ModItems.PLATE_IRON.get()));bench.setItem(1,new ItemStack(Items.QUARTZ));
        bench.setItem(9,CrystalEssenceItem.of("aer",1));bench.setItem(12,CrystalEssenceItem.of("aqua",1));
        var resonator=bench.takeOutput(player,1);
        check(resonator.is(ModItems.VIS_RESONATOR.get())&&aura.vis()==0&&bench.getItem(9).isEmpty()&&bench.getItem(12).isEmpty(),"Initial resonator did not charge 50 vis and two crystals");
        check(!ResearchProgression.advance(state,"UNLOCKAUROMANCY",2,cost->cost.isEmpty()),"Resonator alone completed auromancy");
        bench.clearContent();for(int slot:new int[]{0,1,2})bench.setItem(slot,new ItemStack(Items.IRON_INGOT));for(int slot:new int[]{3,5,6,8})bench.setItem(slot,new ItemStack(Items.LEATHER));
        int thermometerSlot=player.getInventory().findSlotMatchingItem(new ItemStack(ModItems.THAUMOMETER.get()));
        check(thermometerSlot>=0,"Actual crafted thaumometer lost before gauntlet recipe");
        bench.setItem(4,resonator);bench.setItem(7,player.getInventory().removeItem(thermometerSlot,1));
        for(int primal=0;primal<6;primal++)bench.setItem(9+primal,CrystalEssenceItem.of(ArcaneWorkbenchBlockEntity.PRIMALS.get(primal),1));aura.addVis(100);
        var gauntlet=bench.takeOutput(player,1);check(gauntlet.is(ModItems.CASTER_BASIC.get())&&aura.vis()==0,"Initial gauntlet did not charge 100 vis");
        for(int slot=0;slot<15;slot++)check(bench.getItem(slot).isEmpty(),"Gauntlet recipe retained ingredients/crystals: "+slot);
        player.getInventory().add(gauntlet);
        check(ResearchProgression.advance(state,"UNLOCKAUROMANCY",2,cost->cost.isEmpty())&&ResearchRules.complete(state,"UNLOCKAUROMANCY"),"Same new player could not complete gauntlet introduction");
        check(ResearchProgression.advance(state,"BASEAUROMANCY",-1,cost->cost.isEmpty()),"First focus research remained inaccessible");
        System.out.println("Continuous auromancy passed: actual height discovery events, resonator 50 vis/two crystals, gauntlet 100 vis/six crystals, consumption of the previously crafted thaumometer and first-focus entry.");
    }
    private static void verifyContinuousFocus(GameTestHelper h,ServerPlayer player){
        var world=h.getLevel();var state=PlayerProgressManager.get(player);
        check(!ResearchProgression.advance(state,"BASEAUROMANCY",1,cost->cost.isEmpty()),"First focus research skipped blank focus");
        var potRelative=new BlockPos(14,1,8);var pot=h.getBlockEntity(potRelative,CrucibleBlockEntity.class);
        art.arcane.thaumcraft.scan.DerivedAspectEvents.rebuild(world.getServer());
        var sacrificialRelative=new BlockPos(12,1,4);h.setBlock(sacrificialRelative,net.minecraft.world.level.block.Blocks.CRAFTING_TABLE);var sacrificialPos=h.absolutePos(sacrificialRelative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(sacrificialPos));var heldBeforeConversion=player.getMainHandItem();player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new ItemStack(ModItems.SALIS_MUNDUS.get()));if(!heldBeforeConversion.isEmpty())check(player.getInventory().add(heldBeforeConversion),"Could not preserve carried gauntlet before conversion");
        var conversion=new net.minecraft.world.item.context.UseOnContext(player,net.minecraft.world.InteractionHand.MAIN_HAND,new net.minecraft.world.phys.BlockHitResult(net.minecraft.world.phys.Vec3.atCenterOf(sacrificialPos),net.minecraft.core.Direction.UP,sacrificialPos,false));
        check(ModItems.SALIS_MUNDUS.get().useOn(conversion)==net.minecraft.world.InteractionResult.SUCCESS&&player.getMainHandItem().isEmpty(),"Sacrificial workbench conversion failed");
        check(world.destroyBlock(sacrificialPos,true,player),"Sacrificial workbench could not be harvested");
        var recovered=world.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,new net.minecraft.world.phys.AABB(sacrificialPos).inflate(0.1),entity->entity.getItem().is(ModItems.BLOCK_ARCANE_WORKBENCH.get()));
        if(recovered.size()!=1){
            var nearby=new java.util.ArrayList<String>();
            for(var entity:world.getAllEntities())if(entity instanceof net.minecraft.world.entity.item.ItemEntity drop && drop.position().distanceToSqr(net.minecraft.world.phys.Vec3.atCenterOf(sacrificialPos))<64)
                nearby.add(drop.getItem()+" at "+drop.position()+" removed="+drop.isRemoved());
            System.err.println("Workbench harvest diagnostics: pos="+sacrificialPos+", blockDrops="+world.getGameRules().get(net.minecraft.world.level.gamerules.GameRules.BLOCK_DROPS)+", nearby="+nearby);
        }
        check(recovered.size()==1,"Harvested arcane workbench did not drop one block item: "+recovered.stream().map(entity->entity.getItem().toString()+" at "+entity.position()).toList());var benchIngredient=recovered.getFirst().getItem().copy();recovered.getFirst().discard();
        check(pot.processOne(benchIngredient,player)&&pot.processOne(new ItemStack(ModItems.SALIS_MUNDUS.get()),player),"Real workbench/Salis could not supply Aura/Magic");
        for(int glass=0;glass<4;glass++)check(pot.processOne(new ItemStack(Items.GLASS),player),"Glass dissolution failed");
        check(pot.mixture().aspects().getOrDefault("vitreus",0)==20&&pot.mixture().aspects().getOrDefault("praecantatio",0)==10&&pot.mixture().aspects().getOrDefault("auram",0)==5,"Actual blank focus ingredients supplied incorrect costs");
        check(pot.processOne(CrystalEssenceItem.of("ordo",1),player)&&state.crafted("thaumcraft:focus_1")&&pot.mixture().water()==900&&pot.mixture().total()==39,"Continuous blank focus recipe/cost/residual aspects failed");
        art.arcane.thaumcraft.scan.ScanRegistry.clearDerived();
        var outputs=world.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,new net.minecraft.world.phys.AABB(h.absolutePos(potRelative)).inflate(2),entity->entity.getItem().is(ModItems.FOCUS_1.get()));
        check(outputs.size()==1,"Blank focus did not produce exactly one physical output");var blank=outputs.getFirst().getItem().copy();outputs.getFirst().discard();
        check(ResearchProgression.advance(state,"BASEAUROMANCY",1,cost->cost.isEmpty()),"Actual blank focus did not advance research");
        fire(player,world.damageSources().onFire());check(state.has("f_onfire")&&!ResearchProgression.advance(state,"BASEAUROMANCY",2,cost->cost.isEmpty()),"Manipulator requirement bypassed");
        var benchRelative=new BlockPos(14,1,4);var bench=h.getBlockEntity(benchRelative,ArcaneWorkbenchBlockEntity.class);var benchPos=h.absolutePos(benchRelative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(benchPos));bench.clearContent();
        var aura=NativeAura.get(world,world.getChunkAt(benchPos));aura.spend(aura.vis());aura.addVis(50);
        bench.setItem(0,new ItemStack(ModItems.PLATE_IRON.get()));bench.setItem(1,new ItemStack(Items.QUARTZ));bench.setItem(9,CrystalEssenceItem.of("aer",1));bench.setItem(12,CrystalEssenceItem.of("aqua",1));
        var resonator=bench.takeOutput(player,1);check(resonator.is(ModItems.VIS_RESONATOR.get())&&aura.vis()==0,"Second resonator for manipulator failed");bench.clearContent();
        var stone=new ItemStack(Items.STONE);var stones=craft(h,3,3,List.of(stone,stone,stone,stone,CrystalEssenceItem.of("ignis",1),stone,stone,stone,stone));
        var slabs=craft(h,3,1,List.of(stones,stones,stones));var slab=new ItemStack(Items.SMOOTH_STONE_SLAB);var pedestal=craft(h,3,2,List.of(slab,slab,slab,stone,ItemStack.EMPTY,stone));
        bench.setItem(0,new ItemStack(ModItems.PLATE_IRON.get()));bench.setItem(1,slabs.copyWithCount(1));bench.setItem(2,new ItemStack(ModItems.PLATE_IRON.get()));bench.setItem(3,stones.copyWithCount(1));bench.setItem(4,resonator);bench.setItem(5,stones.copyWithCount(1));bench.setItem(6,new ItemStack(Items.GOLD_INGOT));bench.setItem(7,pedestal);bench.setItem(8,new ItemStack(Items.GOLD_INGOT));bench.setItem(10,CrystalEssenceItem.of("terra",1));bench.setItem(12,CrystalEssenceItem.of("aqua",1));aura.addVis(100);
        var manipulator=bench.takeOutput(player,1);check(manipulator.is(ModItems.BLOCK_WAND_WORKBENCH.get())&&aura.vis()==0&&ResearchProgression.advance(state,"BASEAUROMANCY",2,cost->cost.isEmpty())&&ResearchRules.complete(state,"BASEAUROMANCY"),"Continuous manipulator craft/research failed");
        var tableRelative=new BlockPos(14,1,12);h.setBlock(tableRelative,ModBlocks.WAND_WORKBENCH.get());var table=h.getBlockEntity(tableRelative,FocalManipulatorBlockEntity.class);var tablePos=h.absolutePos(tableRelative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(tablePos));table.setItem(0,blank);
        player.giveExperienceLevels(2);var configuration=new art.arcane.thaumcraft.focus.TouchFireFocus(1,0);
        var menu=(art.arcane.thaumcraft.menu.FocalManipulatorMenu)table.createMenu(9,player.getInventory(),player);
        check(menu.clickMenuButton(player,menu.button(0))&&player.experienceLevel==0&&table.job().remainingVis()==43,"Continuous focus configuration costs failed");
        aura=NativeAura.get(world,world.getChunkAt(tablePos));aura.spend(aura.vis());aura.addVis(43);
        for(int tick=0;tick<60;tick++)FocalManipulatorBlockEntity.tick(world,tablePos,table.getBlockState(),table);
        var configured=table.removeItem(0,1);check(!table.working()&&aura.vis()==0&&configuration.equals(configured.get(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get())),"Actual crafted focus did not complete configuration");
        int gauntletSlot=player.getInventory().findSlotMatchingItem(new ItemStack(ModItems.CASTER_BASIC.get()));check(gauntletSlot>=0,"Continuous gauntlet lost before mounting");var gauntlet=player.getInventory().removeItem(gauntletSlot,1);
        var container=new net.minecraft.world.SimpleContainer(1);container.setItem(0,gauntlet);var carried=new net.minecraft.world.SimpleContainer(1);carried.setItem(0,configured);
        var cursor=net.minecraft.world.entity.SlotAccess.of(()->carried.getItem(0),stack->carried.setItem(0,stack));
        check(gauntlet.getItem().overrideOtherStackedOnMe(gauntlet,configured,new net.minecraft.world.inventory.Slot(container,0,0,0),net.minecraft.world.inventory.ClickAction.SECONDARY,player,cursor)&&carried.isEmpty(),"Continuous focus could not mount in actual crafted gauntlet");
        var castingRelative=new BlockPos(14,1,16);for(int y=1;y<=3;y++)for(int z=16;z<=20;z++)h.setBlock(new BlockPos(14,y,z),net.minecraft.world.level.block.Blocks.AIR);var castingPos=h.absolutePos(castingRelative);player.setPos(castingPos.getX()+0.5,castingPos.getY(),castingPos.getZ()+0.5);player.setYRot(0);player.setXRot(0);player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,gauntlet);
        var victim=(net.minecraft.world.entity.Mob)h.spawn(net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getValue(net.minecraft.resources.Identifier.parse("minecraft:husk")),castingRelative.offset(0,0,2));victim.setPos(castingPos.getX()+0.5,castingPos.getY(),castingPos.getZ()+2.5);victim.setNoAi(true);victim.setHealth(20);victim.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR).setBaseValue(0);
        var castingAura=NativeAura.get(world,world.getChunkAt(castingPos));castingAura.spend(castingAura.vis());castingAura.addVis(1);
        check(ModItems.CASTER_BASIC.get().use(world,player,net.minecraft.world.InteractionHand.MAIN_HAND)==net.minecraft.world.InteractionResult.SUCCESS&&victim.getHealth()==16&&victim.getRemainingFireTicks()>0&&Math.abs(castingAura.vis()-0.2f)<0.001,"Continuous first cast failed original damage/fire/0.8-vis cost");victim.discard();
        System.out.println("Continuous first focus passed: physical crucible output, fire discovery, crafted manipulator, menu configuration with two levels/two crystals/43 vis, mounting in crafted gauntlet and actual item-use cast with damage4/fire/0.8 vis.");
    }
    private static void verifyContinuousTheory(GameTestHelper h,ServerPlayer player){
        var world=h.getLevel();var state=PlayerProgressManager.get(player);var relative=new BlockPos(10,1,12);h.setBlock(relative,ModBlocks.TABLE_WOOD.get());var pos=h.absolutePos(relative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(pos));
        var tools=craft(h,2,2,List.of(new ItemStack(Items.GLASS_BOTTLE),new ItemStack(Items.FEATHER),new ItemStack(Items.INK_SAC),ItemStack.EMPTY));check(tools.is(ModItems.SCRIBING_TOOLS.get()),"Continuous writing tools recipe failed");
        player.getInventory().add(player.getMainHandItem().copy());player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,tools);
        var context=new net.minecraft.world.item.context.UseOnContext(player,net.minecraft.world.InteractionHand.MAIN_HAND,new net.minecraft.world.phys.BlockHitResult(net.minecraft.world.phys.Vec3.atCenterOf(pos),net.minecraft.core.Direction.UP,pos,false));ModItems.SCRIBING_TOOLS.get().useOn(context);
        var table=h.getBlockEntity(relative,ResearchTableBlockEntity.class);check(player.getMainHandItem().isEmpty()&&state.crafted("thaumcraft:research_table"),"Continuous table formation lost tools or craft history");table.setItem(1,new ItemStack(Items.PAPER,64));
        player.giveExperienceLevels(10);for(var aspect:art.arcane.thaumcraft.aspect.AspectRegistry.all().values())if(!aspect.isPrimal())check(player.getInventory().add(CrystalEssenceItem.of(aspect.id(),8)),"Compound crystal fixture exceeded player inventory");player.getRandom().setSeed(38);
        var menu=(art.arcane.thaumcraft.menu.ResearchTableMenu)table.createMenu(10,player.getInventory(),player);check(menu.clickMenuButton(player,menu.button(0)),"Same player could not start theory");int draws=0,choices=0;
        for(int step=0;step<200&&!table.session().complete();step++){
            if(table.session().cards().isEmpty()){check(menu.clickMenuButton(player,menu.button(2)),"Continuous theory draw deadlocked");draws++;}
            boolean selected=false;for(int card=0;card<table.session().cards().size()&&!selected;card++)selected=menu.clickMenuButton(player,menu.button(4+card));check(selected,"Continuous theory offered no payable card");choices++;
        }
        check(table.session().complete()&&draws>0&&choices>0&&table.getItem(1).getCount()==64-draws&&table.getItem(0).getDamageValue()==choices,"Continuous theory completion/paper/ink cost failed");
        var rewards=table.session().rewards();var before=new HashMap<String,Integer>();rewards.forEach((category,raw)->before.put(category,state.knowledge("THEORY",category)));int claim=menu.button(7);
        check(menu.clickMenuButton(player,claim)&&table.session()==null&&!menu.clickMenuButton(player,claim),"Continuous theory claim missing or duplicated");rewards.forEach((category,raw)->check(state.knowledge("THEORY",category)==before.get(category)+raw,"Continuous theory reward differs from original conversion"));
        System.out.println("Continuous research passed: crafted writing tools, table formation, owned menu session, supplied compound crystals/experience, paper and ink costs, completion and exactly-once original theory rewards.");
    }
    private static void verifyAccessibleFocusCrystal(GameTestHelper h,ServerPlayer player){
        var world=h.getLevel();var state=PlayerProgressManager.get(player);
        check(ResearchProgression.advance(state,"BASEALCHEMY",-1,cost->cost.isEmpty())&&ResearchRules.complete(state,"BASEALCHEMY"),"Base alchemy inaccessible after introduction");
        var active=art.arcane.thaumcraft.scan.DerivedAspectEvents.rebuild(world.getServer());
        check(active.get("minecraft:arrow").equals(Map.of("terra",1,"instrumentum",1,"aer",1,"volatus",1,"aversio",5)),"Arrow recipe-derived tags/TC6 Aversion addition incorrect: "+active.get("minecraft:arrow"));
        var arrows=craft(h,1,3,List.of(new ItemStack(Items.FLINT),new ItemStack(Items.STICK),new ItemStack(Items.FEATHER)));check(arrows.is(Items.ARROW)&&arrows.getCount()==4,"Accessible arrow recipe missing");
        var nuggets=craft(h,1,1,List.of(new ItemStack(Items.QUARTZ)));check(nuggets.is(ModItems.NUGGET_QUARTZ.get())&&nuggets.getCount()==9,"Quartz crystal catalyst recipe missing");
        var relative=new BlockPos(10,1,4);h.setBlock(relative,ModBlocks.CRUCIBLE.get());var pot=h.getBlockEntity(relative,CrucibleBlockEntity.class);pot.mixture().fill();for(int tick=0;tick<151;tick++)pot.mixture().heatTick(true);
        check(pot.processOne(arrows.copyWithCount(1),player)&&pot.mixture().aspects().getOrDefault("aversio",0)==5,"Arrow failed real Aversion dissolution");
        check(pot.processOne(nuggets.copyWithCount(1),player)&&pot.mixture().aspects().getOrDefault("aversio",0)==3&&pot.mixture().water()==950,"Aversion crystallization original cost incorrect");
        var outputs=world.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,new net.minecraft.world.phys.AABB(h.absolutePos(relative)).inflate(2),entity->entity.getItem().is(ModItems.CRYSTAL_ESSENCE.get())&&CrystalEssenceItem.aspect(entity.getItem()).equals("aversio"));
        check(outputs.size()==1&&outputs.getFirst().getItem().getCount()==1,"Aversion catalyst did not produce one physical crystal: "+outputs.stream().map(entity->entity.getItem().toString()+" at "+entity.position()).toList());check(player.getInventory().add(outputs.getFirst().getItem().copy()),"Produced Aversion crystal could not enter inventory");outputs.getFirst().discard();
        var fireRelative=new BlockPos(10,1,8);h.setBlock(fireRelative,ModBlocks.CRUCIBLE.get());var firePot=h.getBlockEntity(fireRelative,CrucibleBlockEntity.class);firePot.mixture().fill();for(int tick=0;tick<151;tick++)firePot.mixture().heatTick(true);
        check(firePot.processOne(new ItemStack(Items.COAL),player),"Coal could not supply first-focus Fire");
        for(int catalyst=0;catalyst<9;catalyst++)check(firePot.processOne(nuggets.copyWithCount(1),player),"Coal crystallization failed before ninth catalyst");
        check(firePot.mixture().water()==550&&firePot.mixture().total()==2,"Coal crystallization did not retain two aspects/pay nine times");
        var fireOutputs=world.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,new net.minecraft.world.phys.AABB(h.absolutePos(fireRelative)).inflate(2),entity->entity.getItem().is(ModItems.CRYSTAL_ESSENCE.get()));
        check(fireOutputs.size()==9&&fireOutputs.stream().anyMatch(entity->CrystalEssenceItem.aspect(entity.getItem()).equals("ignis")),"Coal/quartz did not produce physical Fire crystals");
        for(var entity:fireOutputs){check(player.getInventory().add(entity.getItem().copy()),"Could not collect coal crystal outputs");entity.discard();}
        System.out.println("Accessible first-focus Fire passed: actual coal dissolution, nine loaded quartz-nugget catalysts, nine physical crystal outputs including Ignis, 450mB paid and two residual aspects; produced Ignis is retained for configuration.");
        art.arcane.thaumcraft.scan.ScanRegistry.clearDerived();
        System.out.println("Accessible first-focus Aversion passed: original arrow complex tags, loaded flint/stick/feather recipe, quartz nuggets, actual crucible dissolution and one crystal for two Aversion/50mB with three Aversion retained.");
    }
    private static void verifyContinuousMetallurgy(GameTestHelper h,ServerPlayer player){
        var world=h.getLevel();var state=PlayerProgressManager.get(player);check(ResearchProgression.advance(state,"METALLURGY",-1,cost->cost.isEmpty()),"Metallurgy did not open after base alchemy");
        var relative=new BlockPos(8,1,12);h.setBlock(relative,ModBlocks.CRUCIBLE.get());var pot=h.getBlockEntity(relative,CrucibleBlockEntity.class);pot.mixture().fill();for(int tick=0;tick<151;tick++)pot.mixture().heatTick(true);
        check(pot.processOne(new ItemStack(ModItems.SALIS_MUNDUS.get()),player)&&pot.processOne(new ItemStack(Items.STONE),player),"Thaumium source dissolution failed");
        check(pot.processOne(new ItemStack(Items.IRON_INGOT),player)&&!state.crafted("thaumcraft:ingot_thaumium")&&pot.mixture().water()==1000&&pot.mixture().aspects().getOrDefault("praecantatio",0)==5,"Thaumium bypassed metallurgy stage2");
        check(pot.processOne(new ItemStack(Items.FLINT),player)&&pot.processOne(new ItemStack(Items.IRON_INGOT),player)&&state.crafted("thaumcraft:ingot_brass")&&pot.mixture().water()==950,"Original brass recipe/cost/history failed");
        int observation=state.knowledge("OBSERVATION","ALCHEMY");check(ResearchProgression.advance(state,"METALLURGY",1,cost->cost.isEmpty())&&state.stage("METALLURGY")==2&&state.knowledge("OBSERVATION","ALCHEMY")==observation-16,"Brass did not advance metallurgy with observation cost");
        check(pot.processOne(new ItemStack(Items.IRON_INGOT),player)&&state.crafted("thaumcraft:ingot_thaumium")&&pot.mixture().water()==900&&!pot.mixture().aspects().containsKey("praecantatio")&&pot.mixture().aspects().getOrDefault("terra",0)==5,"Thaumium did not pay original Magic5/Earth5");
        var outputs=world.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,new net.minecraft.world.phys.AABB(h.absolutePos(relative)).inflate(2),entity->entity.getItem().is(ModItems.INGOT_THAUMIUM.get()));check(outputs.size()==1&&outputs.getFirst().getItem().getCount()==1,"Thaumium did not yield one physical ingot");outputs.getFirst().discard();
        System.out.println("Continuous metallurgy passed: no direct research grants, early thaumium rejection, real Flint/iron brass, paid observation stage, Salis/stone thaumium ingredients, exact five Magic/five Earth/50mB and physical ingot; theory completion remains separate.");
    }
    private static void verifyThaumiumSmelterUpgrade(GameTestHelper h){
        var world=h.getLevel();var player=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);var relative=new BlockPos(8,1,8);h.setBlock(relative,ModBlocks.ARCANE_WORKBENCH.get());var bench=h.getBlockEntity(relative,ArcaneWorkbenchBlockEntity.class);var pos=h.absolutePos(relative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(pos));
        bench.setItem(0,new ItemStack(ModItems.PLATE_BRASS.get()));bench.setItem(2,new ItemStack(ModItems.PLATE_BRASS.get()));bench.setItem(1,new ItemStack(ModItems.BLOCK_SMELTER_BASIC.get()));bench.setItem(4,new ItemStack(ModItems.BLOCK_METAL_ALCHEMICAL.get()));for(int slot:new int[]{3,5,6,7,8})bench.setItem(slot,new ItemStack(ModItems.PLATE_THAUMIUM.get()));bench.setItem(11,CrystalEssenceItem.of("ignis",2));
        var aura=NativeAura.get(world,world.getChunkAt(pos));aura.spend(aura.vis());aura.addVis(250);
        check(bench.preview(player).isEmpty()&&bench.takeOutput(player,1).isEmpty()&&aura.vis()==250&&bench.getItem(11).getCount()==2,"Thaumium smelter upgrade bypassed research or charged failure");
        var state=PlayerProgressManager.get(player);state.unlock("ESSENTIASMELTERTHAUMIUM");state.setStage("ESSENTIASMELTERTHAUMIUM",3);
        aura.spend(1);check(bench.takeOutput(player,1).isEmpty()&&aura.vis()==249&&bench.getItem(11).getCount()==2,"Insufficient upgrade aura consumed ingredients");aura.addVis(1);
        var result=bench.takeOutput(player,1);check(result.is(ModItems.BLOCK_SMELTER_THAUMIUM.get())&&result.getCount()==1&&aura.vis()==0&&state.crafted("thaumcraft:smelter_thaumium"),"Thaumium upgrade did not charge 250 vis or record crafting");
        for(int slot=0;slot<15;slot++)check(bench.getItem(slot).isEmpty(),"Thaumium smelter retained upgrade ingredient/crystal: "+slot);
        bench.clearContent();bench.setItem(0,new ItemStack(ModItems.BLOCK_PLANK_GREATWOOD.get()));bench.setItem(2,new ItemStack(ModItems.BLOCK_PLANK_GREATWOOD.get()));bench.setItem(1,new ItemStack(ModItems.BLOCK_TUBE_FILTER.get()));bench.setItem(3,new ItemStack(ModItems.PLATE_BRASS.get()));bench.setItem(5,new ItemStack(ModItems.PLATE_BRASS.get()));bench.setItem(4,new ItemStack(ModItems.BLOCK_METAL_ALCHEMICAL.get()));bench.setItem(6,new ItemStack(ModItems.PLATE_IRON.get()));bench.setItem(8,new ItemStack(ModItems.PLATE_IRON.get()));bench.setItem(7,new ItemStack(ModItems.BLOCK_BELLOWS.get()));bench.setItem(9,CrystalEssenceItem.of("aer",1));bench.setItem(10,CrystalEssenceItem.of("terra",1));aura.addVis(100);
        check(bench.takeOutput(player,1).isEmpty()&&aura.vis()==100,"Auxiliary recipe bypassed research gate");state.unlock("IMPROVEDSMELTING");state.setStage("IMPROVEDSMELTING",3);
        check(bench.takeOutput(player,1).is(ModItems.BLOCK_SMELTER_AUX.get())&&aura.vis()==0&&state.crafted("thaumcraft:smelter_aux"),"Auxiliary original 100-vis recipe failed");for(int slot=0;slot<15;slot++)check(bench.getItem(slot).isEmpty(),"Auxiliary recipe retained paid ingredient/crystal");
        System.out.println("Auxiliary smelter crafting passed: separate completed-research fixture, research gate, original recipe materials, 100 vis, Aer/Terra crystals and exact consumption.");
        System.out.println("Thaumium smelter upgrade recipe passed: isolated researched-player fixture, research gate, insufficient aura atomicity, original 250 vis/two Fire crystals, two brass/five thaumium plates, basic smelter/alchemical construct and craft history.");
    }
    private static void verifySmelterBellows(GameTestHelper h){
        var world=h.getLevel();var relative=new BlockPos(6,1,12);h.setBlock(relative,ModBlocks.SMELTER_BASIC.get());var smelter=h.getBlockEntity(relative,EssentiaSmelterBlockEntity.class);var pos=h.absolutePos(relative);var facing=smelter.getBlockState().getValue(art.arcane.thaumcraft.block.EssentiaSmelterBlock.FACING);
        smelter.setItem(0,new ItemStack(Items.COAL));smelter.setItem(1,new ItemStack(ModItems.ALUMENTUM.get()));
        for(var side:net.minecraft.core.Direction.Plane.HORIZONTAL)world.setBlockAndUpdate(pos.relative(side),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());
        check(smelter.cookDuration()==40&&smelter.bellowsCount()==0,"Baseline coal smelting duration changed");
        world.setBlockAndUpdate(pos.relative(facing),ModBlocks.BELLOWS.get().defaultBlockState().setValue(art.arcane.thaumcraft.block.EssentiaBellowsBlock.FACING,facing.getOpposite()));check(smelter.bellowsCount()==0,"Front bellows sped up smelter");
        int count=0;for(var side:net.minecraft.core.Direction.Plane.HORIZONTAL){if(side==facing)continue;world.setBlockAndUpdate(pos.relative(side),ModBlocks.BELLOWS.get().defaultBlockState().setValue(art.arcane.thaumcraft.block.EssentiaBellowsBlock.FACING,side.getOpposite()));count++;check(smelter.bellowsCount()==count&&smelter.cookDuration()==40-count*5,"Original bellows speed reduction incorrect");}
        var rear=pos.relative(facing.getOpposite());world.setBlockAndUpdate(rear,ModBlocks.BELLOWS.get().defaultBlockState().setValue(art.arcane.thaumcraft.block.EssentiaBellowsBlock.FACING,facing.getOpposite()));check(smelter.bellowsCount()==2&&smelter.cookDuration()==30,"Misaligned bellows counted");
        world.setBlockAndUpdate(rear,ModBlocks.BELLOWS.get().defaultBlockState().setValue(art.arcane.thaumcraft.block.EssentiaBellowsBlock.FACING,facing));world.setBlockAndUpdate(rear.above(),net.minecraft.world.level.block.Blocks.REDSTONE_BLOCK.defaultBlockState());check(smelter.bellowsCount()==2,"Powered bellows counted");world.setBlockAndUpdate(rear.above(),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());
        var aura=NativeAura.get(world,world.getChunkAt(pos));float before=aura.flux();world.getRandom().setSeed(0);
        for(int tick=0;tick<24;tick++)EssentiaSmelterBlockEntity.tick(world,pos,smelter.getBlockState(),smelter);check(!smelter.input().isEmpty(),"Three bellows cooked coal too early");
        EssentiaSmelterBlockEntity.tick(world,pos,smelter.getBlockState(),smelter);check(smelter.input().isEmpty()&&Math.abs(smelter.total()+aura.flux()-before-20)<0.001,"Bellows changed aspect conservation or failed 25-tick coal cooking");
        for(var side:net.minecraft.core.Direction.Plane.HORIZONTAL)world.setBlockAndUpdate(pos.relative(side),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());
        System.out.println("Smelter bellows passed: front excluded, zero/one/two/three timings 40/35/30/25, orientation/redstone gates, live 25-tick distillation and 20-aspect conservation including flux.");
    }
    private static void verifyAuxiliaryOutlets(GameTestHelper h){
        var world=h.getLevel();var relative=new BlockPos(6,1,8);h.setBlock(relative,ModBlocks.SMELTER_BASIC.get());var smelter=h.getBlockEntity(relative,EssentiaSmelterBlockEntity.class);var pos=h.absolutePos(relative);var front=smelter.getBlockState().getValue(art.arcane.thaumcraft.block.EssentiaSmelterBlock.FACING);
        var jars=new ArrayList<EssentiaJarBlockEntity>();world.setBlockAndUpdate(pos.above(),ModBlocks.ALEMBIC.get().defaultBlockState());jars.add((EssentiaJarBlockEntity)world.getBlockEntity(pos.above()));
        for(var side:net.minecraft.core.Direction.Plane.HORIZONTAL){var outlet=pos.relative(side);world.setBlockAndUpdate(outlet,ModBlocks.SMELTER_AUX.get().defaultBlockState().setValue(art.arcane.thaumcraft.block.SmelterAuxBlock.FACING,side.getOpposite()));world.setBlockAndUpdate(outlet.above(),ModBlocks.ALEMBIC.get().defaultBlockState());if(side!=front)jars.add((EssentiaJarBlockEntity)world.getBlockEntity(outlet.above()));}
        smelter.setItem(0,new ItemStack(Items.COAL));smelter.setItem(1,new ItemStack(ModItems.ALUMENTUM.get()));for(int tick=0;tick<40;tick++)EssentiaSmelterBlockEntity.tick(world,pos,smelter.getBlockState(),smelter);
        int before=smelter.total();var timeData=(net.minecraft.world.level.storage.ServerLevelData)world.getLevelData();long previousTime=world.getGameTime();try{timeData.setGameTime(previousTime+Math.floorMod(-previousTime,15));EssentiaSmelterBlockEntity.tick(world,pos,smelter.getBlockState(),smelter);}finally{timeData.setGameTime(previousTime);}
        int delivered=jars.stream().mapToInt(jar->jar.contents().amount()).sum();check(delivered>0&&delivered==before-smelter.total(),"Auxiliary outlets duplicated/lost aspects");for(var jar:jars)check(jar.contents().amount()>0,"An auxiliary/main column did not receive essentia");
        check(((EssentiaJarBlockEntity)world.getBlockEntity(pos.relative(front).above())).contents().amount()==0,"Front accessory exported essentia");
        for(var side:net.minecraft.core.Direction.Plane.HORIZONTAL){world.setBlockAndUpdate(pos.relative(side).above(),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());world.setBlockAndUpdate(pos.relative(side),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());}world.setBlockAndUpdate(pos.above(),net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());
        System.out.println("Auxiliary smelter outlets passed: main plus three oriented non-front alembic columns, physical transfer and exact conservation; front outlet rejected.");
    }
    private static void verifyContinuousArtificeEntry(GameTestHelper h,ServerPlayer player){
        var state=PlayerProgressManager.get(player);check(ResearchProgression.advance(state,"UNLOCKARTIFICE",-1,cost->cost.isEmpty()),"Artifice entry blocked after actual metallurgy stage2");
        check(!state.has("!machina")&&!ResearchProgression.advance(state,"UNLOCKARTIFICE",1,cost->cost.isEmpty()),"Artifice bypassed Machine discovery");
        var active=art.arcane.thaumcraft.scan.DerivedAspectEvents.rebuild(h.getLevel().getServer());check(active.get("minecraft:lever").equals(Map.of("terra",3,"machina",5)),"Lever original mechanism addition/base recipe tags wrong: "+active.get("minecraft:lever"));
        check(active.get("minecraft:piston").equals(Map.of("herba",6,"terra",15,"perditio",3,"metallum",11,"potentia",7,"machina",10,"motus",10)),"Piston original mechanism/motion additions or recipe tags wrong: "+active.get("minecraft:piston"));
        var lever=craft(h,1,2,List.of(new ItemStack(Items.STICK),new ItemStack(Items.COBBLESTONE)));check(lever.is(Items.LEVER),"Lever loaded recipe failed");
        check(art.arcane.thaumcraft.scan.ScanProgression.record(state,"minecraft:lever",art.arcane.thaumcraft.scan.ScanRegistry.get("minecraft:lever"))&&state.has("!machina"),"Actual lever scan rewards missed Machine discovery");
        int observations=state.knowledge("OBSERVATION","ARTIFICE");check(ResearchProgression.advance(state,"UNLOCKARTIFICE",1,cost->cost.isEmpty())&&ResearchRules.complete(state,"UNLOCKARTIFICE")&&state.knowledge("OBSERVATION","ARTIFICE")==observations-16,"Artifice observation cost/entry did not complete");
        var benchRelative=new BlockPos(14,1,4);var bench=h.getBlockEntity(benchRelative,ArcaneWorkbenchBlockEntity.class);var pos=h.absolutePos(benchRelative);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(pos));bench.clearContent();for(int slot:new int[]{0,2,3,5})bench.setItem(slot,new ItemStack(Items.LEATHER));for(int slot:new int[]{1,7})bench.setItem(slot,new ItemStack(ModItems.INGOT_BRASS.get()));for(int slot:new int[]{6,8})bench.setItem(slot,new ItemStack(ModItems.THAUMOMETER.get()));
        var aura=NativeAura.get(h.getLevel(),h.getLevel().getChunkAt(pos));aura.spend(aura.vis());aura.addVis(50);var goggles=bench.takeOutput(player,1);check(goggles.is(ModItems.GOGGLES.get())&&aura.vis()==0&&goggles.getMaxDamage()==350&&goggles.getMaxStackSize()==1,"Original goggles recipe/durability failed");for(int slot=0;slot<15;slot++)check(bench.getItem(slot).isEmpty(),"Goggles retained original ingredients");
        check(goggles.get(net.minecraft.core.component.DataComponents.EQUIPPABLE).slot()==net.minecraft.world.entity.EquipmentSlot.HEAD&&goggles.get(net.minecraft.core.component.DataComponents.REPAIRABLE).isValidRepairItem(new ItemStack(ModItems.INGOT_BRASS.get()))&&!goggles.get(net.minecraft.core.component.DataComponents.REPAIRABLE).isValidRepairItem(new ItemStack(Items.IRON_INGOT)),"Goggles equipment/repair material incorrect");player.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD,goggles);check(Math.abs(art.arcane.thaumcraft.focus.VisDiscounts.multiplier(player)-0.95F)<0.0001,"Equipped goggles missing original five percent discount");
        System.out.println("Goggles passed: actual unlocked-artifice player, original recipe 50 vis/no crystals/two thaumometers, native head equipment, 350 durability, brass repair and five percent casting discount.");
        art.arcane.thaumcraft.scan.ScanRegistry.clearDerived();System.out.println("Continuous artifice entry passed: actual metallurgy parent, missing Machine gate, original lever/piston recipe aspects, crafted lever scan discovery and paid 16 Artifice observations.");
    }
    private static void verifyFocusData(){
        var codec=art.arcane.thaumcraft.focus.TouchFireFocus.CODEC;
        int accepted=0;
        for(int power=1;power<=5;power++)for(int duration=0;duration<=5;duration++){
            var input=new com.google.gson.JsonArray();input.add(power);input.add(duration);
            var decoded=codec.parse(com.mojang.serialization.JsonOps.INSTANCE,input);
            if(2+power*2+duration>15){check(decoded.result().isEmpty(),"Focus exceeded lesser complexity limit");continue;}
            var focus=decoded.getOrThrow();accepted++;
            check(focus.complexity()==2+power*2+duration&&focus.craftingVis()==focus.complexity()*10+3,"Original focus complexity/crafting vis changed");
            check(focus.castingVis()==focus.complexity()/5f&&focus.cooldownTicks()==Math.max(5,focus.complexity()/5*(focus.complexity()/4)),"Original casting cost/cooldown changed");
            check(focus.damage()==3+power&&focus.fireSeconds()==1+duration*duration,"Original fire damage/duration changed");
            var stack=new ItemStack(ModItems.FOCUS_1.get());stack.set(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get(),focus);
            var buffer=new net.minecraft.network.FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
            try{var stream=net.minecraft.network.codec.ByteBufCodecs.fromCodec(codec);stream.encode(buffer,focus);check(stream.decode(buffer).equals(focus),"Focus network roundtrip changed settings");}finally{buffer.release();}
            var saved=codec.encodeStart(com.mojang.serialization.JsonOps.INSTANCE,stack.copy().get(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get())).getOrThrow();
            check(codec.parse(com.mojang.serialization.JsonOps.INSTANCE,saved).getOrThrow().equals(focus),"Focus persisted settings changed");
        }
        check(accepted==28,"Unexpected lesser focus setting count");
        for(String malformed:List.of("[0,0]","[6,0]","[1,-1]","[1,6]","[5,5]","[]","[1]","[1,0,0]"))
            check(codec.parse(com.mojang.serialization.JsonOps.INSTANCE,com.google.gson.JsonParser.parseString(malformed)).result().isEmpty(),"Invalid focus data accepted");
        System.out.println("Touch/fire focus data passed: 28 settings, complexity cap, costs, damage, copy, persistence and network roundtrip.");
    }
    private static void verifyCraftingJob(GameTestHelper h){
        var player=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);
        var focus=new art.arcane.thaumcraft.focus.TouchFireFocus(1,0);
        var input=new ItemStack(ModItems.FOCUS_1.get());player.giveExperienceLevels(10);
        player.getInventory().add(CrystalEssenceItem.of("aversio",1));
        check(art.arcane.thaumcraft.focus.FocusCraftingJob.start(player,input,focus).isEmpty()&&player.experienceLevel==10,"Unknown research charged focus costs");
        var research=PlayerProgressManager.get(player);research.unlock("BASEAUROMANCY");research.setStage("BASEAUROMANCY",4);
        check(art.arcane.thaumcraft.focus.FocusCraftingJob.start(player,input,focus).isEmpty()&&player.experienceLevel==10&&player.getInventory().countItem(ModItems.CRYSTAL_ESSENCE.get())==1,"Missing crystal partially paid focus costs");
        player.getInventory().add(CrystalEssenceItem.of("ignis",1));
        var job=art.arcane.thaumcraft.focus.FocusCraftingJob.start(player,input,focus).orElseThrow();
        check(player.experienceLevel==8&&player.getInventory().countItem(ModItems.CRYSTAL_ESSENCE.get())==0&&job.remainingVis()==43,"Focus start did not charge exact original costs");
        check(!job.apply(input)&&input.get(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get())==null,"Unfinished focus became usable");
        var pos=h.absolutePos(new BlockPos(8,1,8));var aura=NativeAura.get(h.getLevel(),h.getLevel().getChunkAt(pos));aura.spend(aura.vis());
        check(job.drain(h.getLevel(),pos).equals(job),"Missing aura advanced paid job");aura.addVis(7);
        job=job.drain(h.getLevel(),pos);check(job.remainingVis()==36&&(int)aura.vis()==0,"Partial aura drain was lost");
        var codec=art.arcane.thaumcraft.focus.FocusCraftingJob.CODEC;var saved=codec.encodeStart(com.mojang.serialization.JsonOps.INSTANCE,job).getOrThrow();job=codec.parse(com.mojang.serialization.JsonOps.INSTANCE,saved).getOrThrow();
        aura.addVis(100);job=job.drain(h.getLevel(),pos);check(job.remainingVis()==16,"Manipulator exceeded 20 vis per second");job=job.drain(h.getLevel(),pos);
        check(job.complete()&&(int)aura.vis()==64&&job.apply(input)&&input.get(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get()).equals(focus),"Completed focus did not preserve costs/settings");
        check(job.drain(h.getLevel(),pos).equals(job)&&(int)aura.vis()==64,"Completed job charged more aura");
        System.out.println("Focus crafting job passed: research gate, atomic costs, partial aura, saved progress, drain limit and completion.");
    }
    private static void verifyManipulator(GameTestHelper h){
        var relative=new BlockPos(9,1,9);h.setBlock(relative,ModBlocks.WAND_WORKBENCH.get());
        var table=h.getBlockEntity(relative,FocalManipulatorBlockEntity.class);var pos=h.absolutePos(relative);var world=h.getLevel();
        var player=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(pos));
        var research=PlayerProgressManager.get(player);research.unlock("BASEAUROMANCY");research.setStage("BASEAUROMANCY",4);
        player.giveExperienceLevels(10);player.getInventory().add(CrystalEssenceItem.of("aversio",2));player.getInventory().add(CrystalEssenceItem.of("ignis",2));
        table.setItem(0,new ItemStack(ModItems.FOCUS_1.get()));var config=new art.arcane.thaumcraft.focus.TouchFireFocus(1,0);
        var menu=(art.arcane.thaumcraft.menu.FocalManipulatorMenu)table.createMenu(2,player.getInventory(),player);
        check(menu.slots.size()==37,"Manipulator inventory layout changed");
        int select=menu.button(art.arcane.thaumcraft.menu.FocalManipulatorMenu.selection(2,1));
        check(menu.clickMenuButton(player,select)&&menu.value(1)==2&&menu.value(2)==1&&!menu.clickMenuButton(player,select),"Manipulator accepted stale selection");
        check(!menu.clickMenuButton(player,menu.button(30)),"Manipulator accepted excessive complexity");
        check(menu.clickMenuButton(player,menu.button(1)),"Manipulator could not select minimum focus");
        int start=menu.button(0);check(menu.clickMenuButton(player,start)&&!menu.clickMenuButton(player,start)&&player.experienceLevel==8,"Manipulator repeated payment");
        check(!menu.slots.get(0).mayPickup(player)&&menu.quickMoveStack(player,0).isEmpty(),"Working manipulator menu permitted extraction");
        table.setItem(0,ItemStack.EMPTY);table.clearContent();check(table.removeItem(0,1).isEmpty()&&table.removeItemNoUpdate(0).isEmpty()&&table.getItem(0).is(ModItems.FOCUS_1.get()),"Working manipulator allowed input removal/replacement");
        var aura=NativeAura.get(world,world.getChunkAt(pos));aura.spend(aura.vis());aura.addVis(100);
        for(int tick=0;tick<19;tick++)FocalManipulatorBlockEntity.tick(world,pos,table.getBlockState(),table);
        check(table.job().remainingVis()==43&&(int)aura.vis()==100,"Manipulator drained before 20 ticks");
        var saved=table.saveWithoutMetadata(world.registryAccess());var restored=new FocalManipulatorBlockEntity(pos,table.getBlockState());restored.setLevel(world);
        restored.loadWithComponents(net.minecraft.world.level.storage.TagValueInput.create(net.minecraft.util.ProblemReporter.DISCARDING,world.registryAccess(),saved));
        FocalManipulatorBlockEntity.tick(world,pos,restored.getBlockState(),restored);check(restored.job().remainingVis()==23,"Saved manipulator timer/progress lost");
        for(int tick=0;tick<40;tick++)FocalManipulatorBlockEntity.tick(world,pos,restored.getBlockState(),restored);
        check(!restored.working()&&(int)aura.vis()==57&&restored.removeItem(0,1).get(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get()).equals(config),"Manipulator completion failed or focus remained locked");
        System.out.println("Focal manipulator block passed: single payment, input lock, 20-tick drain, save/load timer and configured output.");
    }
    private static void verifyMounting(GameTestHelper h){
        var player=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);var inventory=new net.minecraft.world.SimpleContainer(1);var carried=new net.minecraft.world.SimpleContainer(1);
        var gauntlet=new ItemStack(ModItems.CASTER_BASIC.get());inventory.setItem(0,gauntlet);var slot=new net.minecraft.world.inventory.Slot(inventory,0,0,0);
        var cursor=net.minecraft.world.entity.SlotAccess.of(()->carried.getItem(0),stack->carried.setItem(0,stack));
        var item=(art.arcane.thaumcraft.item.CasterGauntletItem)gauntlet.getItem();
        var focus=new ItemStack(ModItems.FOCUS_1.get());carried.setItem(0,focus);
        check(!item.overrideOtherStackedOnMe(gauntlet,focus,slot,net.minecraft.world.inventory.ClickAction.SECONDARY,player,cursor),"Blank focus mounted");
        focus.set(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get(),new art.arcane.thaumcraft.focus.TouchFireFocus(2,1));
        focus.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,net.minecraft.network.chat.Component.literal("Test focus"));
        check(!item.overrideOtherStackedOnMe(gauntlet,focus,slot,net.minecraft.world.inventory.ClickAction.PRIMARY,player,cursor),"Primary click mounted focus");
        check(item.overrideOtherStackedOnMe(gauntlet,focus,slot,net.minecraft.world.inventory.ClickAction.SECONDARY,player,cursor)&&carried.isEmpty(),"Configured focus not transferred from cursor");
        var equipped=art.arcane.thaumcraft.item.CasterGauntletItem.equipped(gauntlet);check(ItemStack.isSameItemSameComponents(equipped,focus),"Mount lost custom components");
        equipped.remove(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get());check(art.arcane.thaumcraft.item.CasterGauntletItem.equipped(gauntlet).has(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get()),"Mounted focus exposed mutable storage");
        var ops=h.getLevel().registryAccess().createSerializationContext(com.mojang.serialization.JsonOps.INSTANCE);
        var saved=ItemStack.CODEC.encodeStart(ops,gauntlet).getOrThrow();var restored=ItemStack.CODEC.parse(ops,saved).getOrThrow();
        check(ItemStack.isSameItemSameComponents(art.arcane.thaumcraft.item.CasterGauntletItem.equipped(restored),focus),"Mounted focus did not survive item persistence");
        var replacement=new ItemStack(ModItems.FOCUS_1.get());replacement.set(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get(),new art.arcane.thaumcraft.focus.TouchFireFocus(1,0));carried.setItem(0,replacement);
        check(item.overrideOtherStackedOnMe(gauntlet,replacement,slot,net.minecraft.world.inventory.ClickAction.SECONDARY,player,cursor)&&ItemStack.isSameItemSameComponents(carried.getItem(0),focus),"Swap lost old focus");
        carried.clearContent();check(item.overrideOtherStackedOnMe(gauntlet,ItemStack.EMPTY,slot,net.minecraft.world.inventory.ClickAction.SECONDARY,player,cursor)&&ItemStack.isSameItemSameComponents(carried.getItem(0),replacement)&&art.arcane.thaumcraft.item.CasterGauntletItem.equipped(gauntlet).isEmpty(),"Unmount lost or duplicated focus");
        check(!item.overrideOtherStackedOnMe(gauntlet,ItemStack.EMPTY,slot,net.minecraft.world.inventory.ClickAction.SECONDARY,player,cursor),"Empty gauntlet produced focus");
        var pos=player.blockPosition();var aura=NativeAura.get(h.getLevel(),h.getLevel().getChunkAt(pos));aura.spend(aura.vis());aura.addVis(10);
        check(!NativeAura.spendLocal(h.getLevel(),pos,Float.NaN)&&!NativeAura.spendLocal(h.getLevel(),pos,Float.POSITIVE_INFINITY)&&!NativeAura.spendLocal(h.getLevel(),pos,-1f)&&!NativeAura.spendLocal(h.getLevel(),pos,11f)&&aura.vis()==10f,"Invalid casting cost mutated aura");
        check(NativeAura.spendLocal(h.getLevel(),pos,0.8f)&&Math.abs(aura.vis()-9.2f)<0.0001,"Fractional casting cost was rounded");
        System.out.println("Gauntlet mounting passed: blank rejection, gesture, full components, immutable storage, persistence, swap and removal.");
    }
    private static void verifyCasting(GameTestHelper h){
        var world=h.getLevel();var player=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);var pos=h.absolutePos(new BlockPos(5,1,5));
        for(int y=1;y<=3;y++)for(int z=5;z<=10;z++)h.setBlock(new BlockPos(5,y,z),net.minecraft.world.level.block.Blocks.AIR);
        player.setPos(pos.getX()+0.5,pos.getY(),pos.getZ()+0.5);player.setYRot(0);player.setXRot(0);
        var gauntlet=new ItemStack(ModItems.CASTER_BASIC.get());var focus=new ItemStack(ModItems.FOCUS_1.get());focus.set(art.arcane.thaumcraft.registry.ModComponents.TOUCH_FIRE_FOCUS.get(),new art.arcane.thaumcraft.focus.TouchFireFocus(1,0));
        gauntlet.set(art.arcane.thaumcraft.registry.ModComponents.EQUIPPED_FOCUS.get(),net.minecraft.world.item.component.ItemContainerContents.fromItems(List.of(focus)));player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,gauntlet);
        var aura=NativeAura.get(world,world.getChunkAt(pos));aura.spend(aura.vis());aura.addVis(10);
        var target=(net.minecraft.world.entity.Mob)h.spawn(net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getValue(net.minecraft.resources.Identifier.parse("minecraft:husk")),new BlockPos(5,1,7));target.setPos(pos.getX()+0.5,pos.getY(),pos.getZ()+2.5);target.setNoAi(true);target.setHealth(20);target.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR).setBaseValue(0);
        check(art.arcane.thaumcraft.focus.TouchFireCasting.cast(player,net.minecraft.world.InteractionHand.MAIN_HAND)==net.minecraft.world.InteractionResult.SUCCESS,"Configured gauntlet failed to cast");
        check(Math.abs(aura.vis()-9.2f)<0.001&&target.getHealth()==16&&target.getRemainingFireTicks()>0,"Touch fire costs/damage/ignition incorrect: vis="+aura.vis()+" health="+target.getHealth()+" fire="+target.getRemainingFireTicks());
        check(art.arcane.thaumcraft.focus.TouchFireCasting.cast(player,net.minecraft.world.InteractionHand.MAIN_HAND)==net.minecraft.world.InteractionResult.FAIL&&Math.abs(aura.vis()-9.2f)<0.001,"Cooldown allowed repeated payment/cast");
        player.setItemInHand(net.minecraft.world.InteractionHand.OFF_HAND,gauntlet.copy());
        check(art.arcane.thaumcraft.focus.TouchFireCasting.cast(player,net.minecraft.world.InteractionHand.OFF_HAND)==net.minecraft.world.InteractionResult.FAIL&&Math.abs(aura.vis()-9.2f)<0.001,"Other hand bypassed shared cooldown");
        target.discard();
        var discounted=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);discounted.setPos(player.position());discounted.setYRot(0);discounted.setXRot(0);discounted.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,gauntlet.copy());discounted.getInventory().add(new ItemStack(ModItems.GOGGLES.get()));check(art.arcane.thaumcraft.focus.VisDiscounts.multiplier(discounted)==1F,"Carried goggles incorrectly discounted casting");discounted.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD,new ItemStack(ModItems.GOGGLES.get()));aura.spend(aura.vis());aura.addVis(1);check(art.arcane.thaumcraft.focus.TouchFireCasting.cast(discounted,net.minecraft.world.InteractionHand.MAIN_HAND)==net.minecraft.world.InteractionResult.SUCCESS&&Math.abs(aura.vis()-0.24F)<0.001,"Goggles did not reduce real cast from 0.8 to 0.76 vis");
        for(int scenario=0;scenario<3;scenario++){
            var caster=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);caster.setPos(player.position());caster.setYRot(0);caster.setXRot(0);caster.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,gauntlet.copy());
            var victim=(net.minecraft.world.entity.Mob)h.spawn(net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getValue(net.minecraft.resources.Identifier.parse("minecraft:husk")),new BlockPos(5,1,7));victim.setPos(pos.getX()+0.5,pos.getY(),pos.getZ()+(scenario==1?6.5:2.5));victim.setNoAi(true);victim.setHealth(20);
            if(scenario==0)h.setBlock(new BlockPos(5,2,6),net.minecraft.world.level.block.Blocks.STONE);
            aura.spend(aura.vis());if(scenario!=2)aura.addVis(10);
            var result=art.arcane.thaumcraft.focus.TouchFireCasting.cast(caster,net.minecraft.world.InteractionHand.MAIN_HAND);
            check(victim.getHealth()==20&&victim.getRemainingFireTicks()<=0,"Touch cast bypassed obstacle/range/vis gate: "+scenario);
            if(scenario==2){check(result==net.minecraft.world.InteractionResult.FAIL&&aura.vis()==0,"Missing aura cast or changed aura");aura.addVis(10);check(art.arcane.thaumcraft.focus.TouchFireCasting.cast(caster,net.minecraft.world.InteractionHand.MAIN_HAND)==net.minecraft.world.InteractionResult.FAIL&&aura.vis()==10,"Failed payment did not apply original cooldown");}
            else check(result==net.minecraft.world.InteractionResult.SUCCESS&&Math.abs(aura.vis()-9.2f)<0.001,"Missed/blocked cast did not charge original cost");
            h.setBlock(new BlockPos(5,2,6),net.minecraft.world.level.block.Blocks.AIR);victim.discard();
        }
        System.out.println("First touch/fire cast passed: mounted configuration, fractional vis, entity damage, ignition and cooldown.");
    }
    public static void test(GameTestHelper h){
        var template=net.minecraft.world.item.ItemStackTemplate.fromNonEmptyStack(new ItemStack(Items.STONE));
        var low=new CrucibleRecipe(Ingredient.of(Items.QUARTZ),template,"",Map.of("aer",2),"");
        var high=new CrucibleRecipe(Ingredient.of(Items.QUARTZ),template,"",Map.of("aer",2,"ignis",5),"");
        var tie=new CrucibleRecipe(Ingredient.of(Items.QUARTZ),template,"",Map.of("terra",7),"");
        check(CrucibleRecipe.select(List.of(low,high,tie),recipe->true)==high,"Crucible did not select greatest aspect cost or preserve first tie");
        check(CrucibleRecipe.select(List.of(low,high,tie),recipe->recipe!=high&&recipe!=tie)==low&&CrucibleRecipe.select(List.of(low),recipe->false)==null,"Crucible priority bypassed eligibility or empty selection");
        var ingredientMath=art.arcane.thaumcraft.scan.RecipeAspectMath.derive(List.of(Map.of("arbor",20)),List.of(),4,0);
        check(ingredientMath.equals(Map.of("arbor",3)),"Recipe aspect output count/75 percent changed");
        check(art.arcane.thaumcraft.scan.RecipeAspectMath.derive(List.of(Map.of("aqua",5,"terra",4)),List.of(Map.of("aqua",5)),1,100).equals(Map.of("terra",3,"praecantatio",7)),"Remainder deduction or arcane vis contribution changed");
        check(art.arcane.thaumcraft.scan.RecipeAspectMath.derive(List.of(Map.of("aer",1,"ordo",6)),List.of(),5,0).equals(Map.of("ordo",1)),"TC6 fractional aspect rounding changed");
        check(art.arcane.thaumcraft.scan.RecipeAspectMath.cheapest(List.of(Map.of(),Map.of("terra",4),Map.of("ignis",2))).equals(Map.of("ignis",2)),"Original cheapest nonempty recipe choice changed");
        var graph=new art.arcane.thaumcraft.scan.RecipeAspectResolver(Map.of("log",Map.of("arbor",20),"bucket",Map.of("metallum",15)),List.of(
            new art.arcane.thaumcraft.scan.RecipeAspectResolver.Recipe("plank",List.of("log"),List.of(),4,0),
            new art.arcane.thaumcraft.scan.RecipeAspectResolver.Recipe("table",List.of("plank","plank","plank","plank"),List.of(),1,0),
            new art.arcane.thaumcraft.scan.RecipeAspectResolver.Recipe("cycle_a",List.of("cycle_b"),List.of(),1,0),
            new art.arcane.thaumcraft.scan.RecipeAspectResolver.Recipe("cycle_b",List.of("cycle_a"),List.of(),1,0)));
        check(graph.get("plank").equals(Map.of("arbor",3))&&graph.get("table").equals(Map.of("arbor",9)),"Recursive recipe aspect derivation failed");
        check(graph.get("cycle_a").isEmpty()&&graph.get("unknown").isEmpty()&&graph.get("bucket").equals(Map.of("metallum",15)),"Cycle/unknown/explicit tag handling failed");
        var nativeGraph=art.arcane.thaumcraft.scan.NativeRecipeAspectGraph.build(h.getLevel().getServer().getRecipeManager());
        check(nativeGraph.get("minecraft:iron_nugget").equals(Map.of("metallum",1)),"Native nine-nugget output recipe aspect calculation failed");
        check(nativeGraph.get("minecraft:iron_ingot").equals(Map.of("metallum",15)),"Native graph overwrote explicit tags with reversible recipe");
        check(nativeGraph.get("minecraft:oak_planks").equals(Map.of("herba",3)),"Real wood recipe lost original Plant20 log assignment");
        check(nativeGraph.get("minecraft:paper").equals(Map.of("herba",3,"aqua",2,"aer",1,"cognitio",2)),"Real sugarcane paper base derivation incorrect");
        check(nativeGraph.get("minecraft:crafting_table").equals(Map.of("herba",9,"fabrico",20)),"Crafting table complex addition missing");
        check(nativeGraph.get("thaumcraft:arcane_workbench").equals(Map.of("herba",9,"fabrico",20,"praecantatio",5,"auram",5)),"Arcane workbench copied tags incorrectly scaled");
        var active=art.arcane.thaumcraft.scan.DerivedAspectEvents.rebuild(h.getLevel().getServer());
        check(active.size()==23&&EssentiaSmelterBlockEntity.tags(new ItemStack(ModItems.BLOCK_ARCANE_WORKBENCH.get())).getOrDefault("auram",0)==5,"Derived workbench aura not visible to smelter");
        check(active.get("minecraft:book").equals(Map.of("herba",6,"aqua",4,"aer",2,"cognitio",4,"bestia",3,"praemunio",3)),"Book early-game aspects incorrect: "+active.get("minecraft:book"));
        check(active.get("minecraft:bucket").equals(Map.of("metallum",33)),"Bucket aspects incorrect");
        check(active.get("minecraft:glass_bottle").equals(Map.of("vitreus",3)),"Bottle output quantity not applied");
        check(active.get("minecraft:bowl").equals(Map.of("herba",1)),"Bowl output quantity not applied");
        check(active.get("minecraft:chest").equals(Map.of("herba",18)),"Chest aspects incorrect");
        check(active.get("minecraft:furnace").equals(Map.of("terra",30,"perditio",6)),"Furnace aspects incorrect");
        check(art.arcane.thaumcraft.scan.ScanRegistry.get("minecraft:paper").getOrDefault(art.arcane.thaumcraft.aspect.AspectRegistry.get("cognitio"),0)==2,"Derived paper mind not visible to scanning");
        var smelterRelative=new BlockPos(12,1,12);h.setBlock(smelterRelative,ModBlocks.SMELTER_BASIC.get());var derivedSmelter=h.getBlockEntity(smelterRelative,EssentiaSmelterBlockEntity.class);var smelterPos=h.absolutePos(smelterRelative);
        derivedSmelter.setItem(0,new ItemStack(ModItems.BLOCK_ARCANE_WORKBENCH.get()));derivedSmelter.setItem(1,new ItemStack(ModItems.ALUMENTUM.get()));
        var distillationAura=NativeAura.get(h.getLevel(),h.getLevel().getChunkAt(smelterPos));float fluxBefore=distillationAura.flux();h.getLevel().getRandom().setSeed(0);
        for(int tick=0;tick<78;tick++)EssentiaSmelterBlockEntity.tick(h.getLevel(),smelterPos,derivedSmelter.getBlockState(),derivedSmelter);
        var storedTags=net.minecraft.world.level.storage.TagValueInput.create(net.minecraft.util.ProblemReporter.DISCARDING,h.getLevel().registryAccess(),derivedSmelter.saveWithoutMetadata(h.getLevel().registryAccess())).read("aspects",com.mojang.serialization.Codec.unboundedMap(com.mojang.serialization.Codec.STRING,com.mojang.serialization.Codec.INT)).orElseThrow();
        check(derivedSmelter.input().isEmpty()&&storedTags.getOrDefault("auram",0)>0,"Live workbench distillation failed to produce Aura");
        check(Math.abs(derivedSmelter.total()+distillationAura.flux()-fluxBefore-39)<0.001,"Derived distillation did not conserve 39 aspects including flux");
        System.out.println("Derived workbench distillation passed: 78 cooking ticks, Aura output, exact 39-aspect conservation including flux.");
        var snapshot=art.arcane.thaumcraft.network.AspectSnapshotPayload.of(active);var syncBuffer=new net.minecraft.network.RegistryFriendlyByteBuf(io.netty.buffer.Unpooled.buffer(),h.getLevel().registryAccess());
        try{art.arcane.thaumcraft.network.AspectSnapshotPayload.CODEC.encode(syncBuffer,snapshot);var decoded=art.arcane.thaumcraft.network.AspectSnapshotPayload.CODEC.decode(syncBuffer);art.arcane.thaumcraft.scan.ScanRegistry.clearDerived();check(art.arcane.thaumcraft.scan.ScanRegistry.get("thaumcraft:arcane_workbench").isEmpty(),"Derived map survived cleanup");art.arcane.thaumcraft.scan.ScanRegistry.installDerived(decoded.values());check(EssentiaSmelterBlockEntity.tags(new ItemStack(ModItems.BLOCK_ARCANE_WORKBENCH.get())).get("auram")==5,"Aspect payload changed smelter eligibility");}finally{syncBuffer.release();art.arcane.thaumcraft.scan.ScanRegistry.clearDerived();}
        check(art.arcane.thaumcraft.scan.ScanRegistry.get("minecraft:iron_ingot").get(art.arcane.thaumcraft.aspect.AspectRegistry.METALLUM)==15,"Derived cleanup removed explicit tags");
        var beginningPlayer=verifyBeginning(h);
        verifyInitialAlchemy(h,beginningPlayer);
        verifyInitialAuromancy(h,beginningPlayer);
        verifyAccessibleFocusCrystal(h,beginningPlayer);
        verifyContinuousFocus(h,beginningPlayer);
        verifyContinuousTheory(h,beginningPlayer);
        verifyContinuousMetallurgy(h,beginningPlayer);
        verifyContinuousArtificeEntry(h,beginningPlayer);
        verifyThaumiumSmelterUpgrade(h);
        verifySmelterBellows(h);
        verifyAuxiliaryOutlets(h);
        verifyFocusData();
        verifyCraftingJob(h);
        verifyManipulator(h);
        verifyMounting(h);
        verifyCasting(h);
        var world=h.getLevel();var stone=new ItemStack(Items.STONE);var crystal=CrystalEssenceItem.of("ignis",1);
        var arcane=craft(h,3,3,List.of(stone,stone,stone,stone,crystal,stone,stone,stone,stone));
        check(arcane.is(ModItems.BLOCK_STONE_ARCANE.get())&&arcane.getCount()==9,"Arcane stone base recipe lost original output or crystal variants");
        var slabs=craft(h,3,1,List.of(arcane,arcane,arcane));check(slabs.is(ModItems.BLOCK_SLAB_ARCANE_STONE.get())&&slabs.getCount()==6,"Arcane slab recipe missing");
        var smoothSlab=new ItemStack(Items.SMOOTH_STONE_SLAB);
        var table=craft(h,3,2,List.of(smoothSlab,smoothSlab,smoothSlab,stone,ItemStack.EMPTY,stone));check(table.is(ModItems.BLOCK_TABLE_STONE.get())&&table.getCount()==1,"Original stone table recipe missing");
        check(new ItemStack(ModItems.FOCUS_1.get()).getMaxStackSize()==1&&new ItemStack(ModItems.CASTER_BASIC.get()).getMaxStackSize()==1,"Focus or gauntlet could stack");
        var player=(ServerPlayer)h.makeMockServerPlayer(GameType.SURVIVAL);var research=PlayerProgressManager.get(player);research.unlock("UNLOCKAUROMANCY");research.setStage("UNLOCKAUROMANCY",4);
        check(ResearchProgression.advance(research,"BASEAUROMANCY",-1,cost->cost.isEmpty())&&research.stage("BASEAUROMANCY")==1,"Auromancy intro could not start");
        fire(player,world.damageSources().onFire());check(!research.has("f_onfire"),"Fire discovery bypassed the focus prerequisite");
        var benchPos=new BlockPos(2,1,2);h.setBlock(benchPos,ModBlocks.ARCANE_WORKBENCH.get());var bench=h.getBlockEntity(benchPos,ArcaneWorkbenchBlockEntity.class);var absolute=h.absolutePos(benchPos);player.setPos(net.minecraft.world.phys.Vec3.atCenterOf(absolute));
        var aura=NativeAura.get(world,world.getChunkAt(absolute));aura.spend(aura.vis());aura.addVis(100);
        bench.setItem(0,new ItemStack(ModItems.PLATE_IRON.get()));bench.setItem(1,slabs.copyWithCount(1));bench.setItem(2,new ItemStack(ModItems.PLATE_IRON.get()));
        bench.setItem(3,arcane.copyWithCount(1));bench.setItem(4,new ItemStack(ModItems.VIS_RESONATOR.get()));bench.setItem(5,arcane.copyWithCount(1));
        bench.setItem(6,new ItemStack(Items.GOLD_INGOT));bench.setItem(7,table);bench.setItem(8,new ItemStack(Items.GOLD_INGOT));
        bench.setItem(10,CrystalEssenceItem.of("terra",1));bench.setItem(12,CrystalEssenceItem.of("aqua",1));
        check(bench.preview(player).isEmpty()&&bench.takeOutput(player,1).isEmpty()&&aura.vis()==100,"Manipulator recipe bypassed research or charged a failed craft");
        var focus=world.getServer().getRecipeManager().recipeMap().byType(ModRecipes.CRUCIBLE_TYPE.get()).stream().map(holder->holder.value()).filter(recipe->recipe.result().create().is(ModItems.FOCUS_1.get())).findFirst().orElseThrow();
        check(focus.matches(new SingleRecipeInput(CrystalEssenceItem.of("ordo",1)),world)&&!focus.matches(new SingleRecipeInput(CrystalEssenceItem.of("aer",1)),world),"Blank focus accepted the wrong catalyst aspect");
        var buffer=new net.minecraft.network.RegistryFriendlyByteBuf(io.netty.buffer.Unpooled.buffer(),world.registryAccess());
        CrucibleRecipe.STREAM_CODEC.encode(buffer,focus);var decoded=CrucibleRecipe.STREAM_CODEC.decode(buffer);check(decoded.catalystAspect().equals("ordo")&&!decoded.matches(new SingleRecipeInput(crystal),world),"Network recipe lost its component catalyst requirement");buffer.release();
        var potPos=new BlockPos(5,1,2);h.setBlock(potPos,ModBlocks.CRUCIBLE.get());var pot=h.getBlockEntity(potPos,CrucibleBlockEntity.class);pot.mixture().fill();for(int i=0;i<151;i++)pot.mixture().heatTick(true);
        pot.mixture().dissolve(Map.of("vitreus",20,"praecantatio",10,"auram",5));
        check(pot.processOne(CrystalEssenceItem.of("ordo",1),player)&&pot.mixture().total()==0&&pot.mixture().water()==950&&research.crafted("thaumcraft:focus_1"),"Blank focus did not charge original crucible costs or record crafting");
        check(ResearchProgression.advance(research,"BASEAUROMANCY",1,cost->cost.isEmpty())&&research.stage("BASEAUROMANCY")==2,"Blank focus did not advance the original book stage");
        fire(player,world.damageSources().generic());check(!research.has("f_onfire"),"Non-fire damage granted fire discovery");
        fire(player,world.damageSources().onFire());check(research.has("f_onfire"),"Fire damage did not unlock the real second-stage discovery");
        int discoveries=research.researched().size();fire(player,world.damageSources().onFire());check(research.researched().size()==discoveries,"Repeated fire duplicated a discovery");
        check(!ResearchProgression.advance(research,"BASEAUROMANCY",2,cost->cost.isEmpty()),"Fire alone bypassed manipulator crafting");
        var result=bench.takeOutput(player,1);check(result.is(ModItems.BLOCK_WAND_WORKBENCH.get())&&aura.vis()==0&&bench.getItem(10).isEmpty()&&bench.getItem(12).isEmpty()&&research.crafted("thaumcraft:wand_workbench"),"Manipulator craft did not charge exactly 100 vis and two original crystals");
        check(ResearchProgression.advance(research,"BASEAUROMANCY",2,cost->cost.isEmpty())&&ResearchRules.complete(research,"BASEAUROMANCY"),"Original basic auromancy intro remained blocked");
        System.out.println("Early focus prerequisites passed: arcane stone/slabs/table recipes, aspect-specific blank focus, recipe network codec, fire discovery gate, exact manipulator costs and completion of original BASEAUROMANCY stages.");h.succeed();
    }
}



