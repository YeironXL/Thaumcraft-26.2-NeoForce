# Thaumcraft NeoForge 26.2 — fix33

Primer cierre de bloqueos de progresión del inicio.

- Los requisitos de cristales de investigación con NBT de TC6 se traducen al componente nativo de aspecto. Se conservan el aspecto y la cantidad exigidos.
- Los frascos llenos heredados de diez unidades se traducen a la variante nativa correspondiente. Un frasco de otro aspecto no satisface el requisito.
- El cobro de inventario valida todas las cantidades antes de retirar nada. Los requisitos específicos tienen prioridad sobre los genéricos para evitar contar dos veces la misma unidad.
- Se desbloquea el cumplimiento real de las dos primeras etapas de ESSENTIASMELTER con los seis cristales primales y diez compuestos originales. La siguiente etapa todavía requiere teorías, que dependen de la mesa de investigación pendiente.
- El Thaumonomicon muestra nombres de objetos, aspectos, conocimientos y etapas en lugar de claves de registro y NBT antiguo. Los requisitos de objetos aún no migrados se indican como no disponibles.
- Solo se aceptan las estructuras de NBT conocidas de cristales/frascos. No se ignoran condiciones no implementadas.
- Siete pruebas de servidor: etapas reales del horno, frascos correctos/incorrectos, cantidades, cobro atómico y demanda genérica/específica solapada.
- Prueba de cliente para los textos de requisitos y las pantallas/modelos existentes; compilación de producción y regresiones de migración.

Alcance acordado del siguiente recorrido: inicio, investigación, alquimia y primer guantelete/foco. La mesa de investigación, las teorías, la magia inicial y la prueba integral con jugador nuevo siguen pendientes. Fix33 no certifica aún que el early game esté completo.
