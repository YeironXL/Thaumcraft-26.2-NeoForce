# Estado del port — fix75

Añadidas páginas de alquimia en crisol al Thaumonomicon para referencias exactas migradas con catalizador simple y aspectos conocidos. Muestra catalizador, resultado, iconos/cantidades de aspectos y tooltips; conserva navegación de recetas y regreso al libro. La consulta no fabrica ni altera el progreso del servidor.

Diseño de GuiResearchPage.drawCruciblePage: atlas original gui_researchbook_overlay.png con segmentos UV0,3/56x17, UV0,20/56x48 y flecha UV100,84/11x13, escalados por2. Posiciones del catalizador, resultado y aspectos derivadas del original; contenedor y fuente serif adaptados a la interfaz actual. Aspectos ordenados por identificador latino y distribuidos en filas de3. Se aceptan hasta9 tipos de aspectos para no desbordar esta página.

Fuente de datos: JSON exacto del datapack incluido en la compilación, copiado a recursos del cliente en processResources. Catalizadores no resolubles, grupos, aliases y recetas no compatibles quedan fuera. Infusión, planos, ingredientes por tag, grupos y addenda siguen pendientes. No certifica todo el libro ni datapacks modificados de servidores externos.

Compilación y diez pruebas requeridas del servidor aprobadas. Cliente final aprobado: Nitor con polvo de piedra luminosa,10 Ignis/10 Lux/10 Potentia, omisión de grupos sin resolver, regresión de recetas normal/arcana y navegación. Captura final inspeccionada, incluidos tintes originales de los aspectos. La vista sin mundo incorpora un fixture del catalizador; sus componentes se cargan normalmente al entrar en un mundo.
