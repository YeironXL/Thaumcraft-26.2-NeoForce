# Estado del port — fix58

## Cambios

Selector del Thaumonomicon con acceso directo mediante los iconos y marcos originales de categoría. El marco marca la selección actual y el tooltip conserva la fuente serif e indica el progreso de investigación del jugador.

Las categorías solo aparecen al completar su UNLOCK correspondiente, siguiendo GuiResearchBrowser del original. Fundamentos siempre está disponible. Clic, rueda y selección directa respetan esta condición; abrir una categoría no concede investigación ni evita los requisitos del servidor.

## Verificación

Prueba de cliente: Auromancia bloqueada antes de completar su descubrimiento; Auromancia y Artificio accesibles tras recibir progreso completado; Eldritch permanece bloqueado. Capturas del inicio y de Artificio con cuatro categorías disponibles. Compilación de producción y diez pruebas requeridas del servidor.

## Límites

Barra horizontal adaptada al tamaño actual. Disposición lateral exacta, conexiones curvas, marcadores de novedades y recetas ilustradas pendientes. El porcentaje mostrado mide progreso del jugador, no porcentaje del contenido portado. No se acredita cierre de etapa ni paridad total. Escenas concretas de la guía de artificio documentadas.
