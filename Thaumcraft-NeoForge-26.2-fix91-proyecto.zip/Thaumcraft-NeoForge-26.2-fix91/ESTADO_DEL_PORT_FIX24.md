# Thaumcraft NeoForge 26.2 — fix24

Implementación por sistemas sobre fix23; el port completo continúa pendiente.

## Añadido

- Crystal Essence: componente de aspecto persistente, 37 variantes en creativo, nombres y colores nativos.
- Salis Mundus: receta de tres aspectos distintos, redstone, cuenco y pedernal. Devuelve cuenco y pedernal.
- Mesa arcana: inventario persistente, seis ranuras de cristales, cuadrícula, recetas arcanas con y sin patrón y fabricación vanilla. Comprueba investigación, ingredientes, cristales y vis en el servidor; almacena las salidas parciales para cobrar una sola vez.
- Pantalla de mesa arcana con vis disponible/coste y ranuras por aspecto; controles y nombres iniciales en español.
- Aura escalar de vis/flux por chunk, guardada en attachments. Consumo por mesa y recuperación lunar según las tasas originales. El cargador encima permite consumir aura de los nueve chunks cargados próximos.
- Cristales colocados: geometría original OBJ adaptada al cargador nativo, siete aspectos, cuatro tamaños, seis direcciones, soporte sobre piedra y gotas de Crystal Essence con aspecto y cantidad correspondientes. Crecimiento/reducción y propagación ligada a aura.
- Generación de cristales primales en cuevas de chunks nuevos.
- Crisol: agua, calentamiento, disolución de objetos con aspectos conocidos, introducción por la cara superior o mediante objetos arrojados, recetas por investigación, consumo de 50 mB por resultado, desbordamiento y contaminación del aura. Su contenido se guarda. Agacharse con la mano principal vacía lo vacía.
- Nitor: luz de nivel 15, sin colisión, apariencia visible con sprites originales de cada color y partículas nativas. Calienta el crisol. Ya no cae en el modelo vacío.
- 84 recetas nativas: 9 arcanas, 44 de crisol, 14 conversiones/planchas, 16 tintes de Nitor y Salis Mundus. Las recetas no significan que todos sus objetos de salida tengan sus funciones portadas; por ejemplo, el guantelete todavía requiere el sistema de focos.
- Escaneo de bloques, objetos arrojados y entidades con datos conocidos. Se migraron 53 entradas vanilla (incluidas variantes de estado) y el descubrimiento de aspectos `!tag`, con sus observaciones iniciales originales.
- Referencias antiguas de Nitor, placas, lingotes y pepitas vinculadas a variantes actuales; nombres vanilla renombrados explícitamente. Se puede reconocer la fabricación de Nitor amarillo para terminar la introducción de alquimia.
- Disparadores de Nether, End, profundidad y altura durante la introducción de auromancia. Los umbrales verticales se adaptan al mínimo/altura del mundo actual.
- Sonidos originales registrados; crisol con audio de burbujeo y vertido. Loot tables para las máquinas iniciales y Nitor.
- Inventario de 902 archivos Java de referencia con rutas/hashes y listado de sistemas pendientes.

## Comprobaciones de desarrollo

`gradlew.bat build --offline`: compilación y pruebas de persistencia, aura, crisol, investigación, metadatos y escaneo.

Servidor GameTest desechable: carga de recetas y worldgen, cobro del Thaumometer, rechazo por investigación/cristales/vis insuficientes, extracción por barra rápida y salida parcial, fabricación de Nitor y su progresión, gotas de cristales, luz/colisión de Nitor y loot de mesa. Usa un directorio nuevo de pruebas; no usa los mundos del jugador.

Cliente real: recetas y componentes, inventario guardado, variantes de cristales, modelo del horno en todos los contextos y geometría no vacía de 1.360 estados de cristales/Nitor. Capturas del Thaumonomicon y la mesa arcana. El panel de mesa se captura con un inventario de prueba; sus transacciones se comprueban en el servidor.

Las clases y recursos GameTest de verificación se excluyen del JAR final.

## Diferencias y pendientes

- La generación de cristales y su relación con los biomas son una adaptación inicial. Las agrupaciones usan una cara de apoyo; el renderizador original podía mostrar cristales en varias caras simultáneamente. La forma de selección todavía no sigue cada tamaño.
- La regeneración de aura no incluye todavía difusión entre chunks, generación de grietas o simulación global del flux. Los modificadores de bioma se aproximan con etiquetas modernas.
- Nitor usa partículas y planos nativos; falta reproducir el motor de partículas/renderizado original. El agua del crisol se representa en cuatro niveles visuales.
- El crisol todavía no expone el depósito a tuberías de fluidos. No están todas las recetas, la derivación de aspectos a partir de todas las recetas, los efectos originales ni las interacciones especiales de entidades.
- El escaneo no incluye inventarios, cielo, pociones/encantamientos ni todos los descubrimientos especiales. Las entidades propias del mod siguen pendientes.
- Los requisitos con NBT/metadatos sin conversión y etiquetas antiguas no soportadas siguen bloqueados; no se eliminan para saltar investigaciones.
- Faltan teorías/cartas, esencia y automatización, infusión, focos/hechizos, gólems, la mayor parte de dispositivos/equipamiento, estructuras/árboles/plantas y contenido eldritch.
- Persisten modelos/registros antiguos que necesitan depuración. Las pruebas anteriores no son una revisión general de bugs ni prueban ausencia de duplicaciones en todos los modos de inventario o en multijugador.
- Falta una partida manual completa de supervivencia y pruebas de varios jugadores, además de la revisión general posterior a la implementación.

Los historiales fix22/fix23 describen revisiones anteriores; este archivo refleja el estado actual. Fuentes e inventario detallado: `docs/PLAN_DE_PORT_TC6.md`.
