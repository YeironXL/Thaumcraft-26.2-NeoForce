# Thaumcraft NeoForge 26.2 — fix22

Esta entrega es un avance del port. No reproduce todavía todo el funcionamiento de Thaumcraft 6.

## Referencia

Thaumcraft 6.1.BETA26 para Minecraft 1.12.2. Se consultó la reconstrucción comunitaria del código en https://github.com/TheDarkTower314/Thaumcraft-6-Source-Code, commit 954022bb777b7546281fb36df8522f0ba6b43f81. No es una publicación oficial del código por Azanor. Los recursos y textos originales conservan sus derechos.

## Cambios incluidos

- Correcciones de compilación de fix20 y Gradle Wrapper completo; requiere Java 25.
- Orden temático de la pestaña creativa, con ciertos registros internos ocultos.
- Persistencia de descubrimientos, objetos escaneados, conocimiento y los tres tipos de warp mediante attachments de NeoForge; copia al reaparecer.
- Catálogo de 148 investigaciones originales, con sus textos, categorías, requisitos y etapas. Importar estos datos no implementa sus comportamientos.
- Thaumonomicon con categorías, búsqueda, paginación y diseño adaptable. El servidor envía el estado al abrirlo. La interfaz no concede investigaciones.
- Conversión de traducciones .lang a .json. Controles nuevos traducidos al español; los textos históricos dependen de las traducciones originales disponibles.
- 37 aspectos de TC6 con composición y colores originales. Asignaciones explícitas corregidas para una selección de materiales vanilla; falta el cálculo general de aspectos por recetas y entidades.
- Hungry Chest: 27 espacios, menú nativo, recogida de objetos al tocarlo, inserción parcial, guardado, orientación, señal de comparador y capability de transferencia. Conserva un modelo estático; falta la animación original de la tapa.
- Las variables existentes de las máquinas se guardan; esto no implementa sus ciclos de trabajo.
- Correcciones de recursos: rango del pack, textura del Hungry Chest, seis familias de losas con estados inferior/superior/doble y referencias a modelos OBJ existentes. Falta comprobar visualmente todos los bloques en un mundo.
- Se retiró la receta provisional de Alumentum en mesa común. La definición interna ahora usa las cantidades originales del crisol: 10 potentia, 10 ignis y 5 perditio, carbón o carbón vegetal. El motor del crisol todavía no está conectado.

## Verificación realizada

- `gradlew.bat build --offline`: compila y ejecuta las comprobaciones de migración.
- `verifyMigration`: persistencia y copia independiente de investigación, duplicados de escaneo, límites de conocimiento, prerrequisitos, aspectos y datos originales de investigación.
- `gradlew.bat runClient -PverifyUi --offline`: arranque del cliente, renderizado real del menú y captura nativa. Incluye pruebas del inventario del Hungry Chest (capacidad, resto, guardado/carga) con dos objetos de prueba cuyas propiedades se enlazan expresamente. No sustituye una prueba de recogida de entidades y tolvas en un mundo.
- Las clases de verificación se excluyen del JAR entregado.

## Pendiente para equivalencia funcional

1. Inicio original: sueño, cristales, Salis Mundus y validación por etapas. Los disparadores actuales de Salis Mundus todavía son provisionales.
2. Investigación: etapas persistentes, requisitos de objetos/fabricación/conocimiento, mesa y cartas, observaciones/teorías por categoría, escaneo de entidades y objetos.
3. Mesa arcana: inventario, recetas, cristales, consumo de vis y cargador.
4. Alquimia: crisol, agua/calor, aspectos, flux, alambique, tubos, frascos y Thaumatorium.
5. Infusión: estructura, pedestales, esencia, estabilidad, eventos y encantamientos.
6. Auromancia: guanteletes, focos, componentes, proyectiles y efectos.
7. Gólems: construcción, materiales, rasgos, IA, tareas y sellos.
8. Entidades, estructuras, árboles, vetas, aura, contaminación, grietas y contenido eldritch.
9. Equipamiento: estadísticas, habilidades, animaciones y modelos especiales.
10. Resto de recetas, menús de máquinas, renderizadores y pruebas de juego/servidor dedicado.

Muchos registros heredados siguen siendo esqueletos. Aparecer en creativo o tener textura no implica estar implementado.

## Uso

Instalar el JAR en `mods` con Minecraft 26.2 y NeoForge 26.2.0.88. Conservar una copia de seguridad de los mundos de prueba.

Para compilar el proyecto: `gradlew.bat build`. Para abrir el cliente de desarrollo: `gradlew.bat runClient`. No hace falta usar `-PverifyUi` para jugar.

## Última entrega fix65

Carta Programación funcional con costes y persistencia originales, desbloqueo de Golemancia y rechazo atómico de recursos insuficientes. Compilación, cliente y diez pruebas del servidor aprobados. Detalles: ESTADO_DEL_PORT_FIX65.md.

## Última entrega fix66

Carta Curiosidad con ocho variantes, consumo de objeto y recompensas originales, sorteos adicionales y variante persistida. Diez pruebas del servidor aprobadas, incluidas 160 comparaciones de resultados con TC6. Límites y validación final: ESTADO_DEL_PORT_FIX66.md.

## Última entrega fix67

Carta Revelación con recompensas, costes, tipos de distorsión y umbral de conversión originales. Diez pruebas del servidor aprobadas, incluidas 50 comparaciones de recompensa y conversión. Detalles y límites: ESTADO_DEL_PORT_FIX67.md.

## Última entrega fix68

Cartas Verdad y Comprensión funcionales con recompensas, robos adicionales y distorsión originales. Diez pruebas del servidor aprobadas, incluidas cien comparaciones de efectos de estas cartas. Detalles y límites: ESTADO_DEL_PORT_FIX68.md.

## Última entrega fix69

Agua del crisol con tinte original según la concentración de aspectos, contenido sincronizado y actualización de malla del cliente. Recetas, calor y pagos conservados; límites y evidencias: ESTADO_DEL_PORT_FIX69.md.

## Última entrega fix70

Burbujas del crisol con colores, vida y fotogramas originales, emitidas desde el cliente según la mezcla sincronizada. Diez pruebas del servidor aprobadas. Detalles y límites: ESTADO_DEL_PORT_FIX70.md.


# Estado del port — fix71

Rebose morado del crisol según TileCrucible.drawEffects y FXDispatcher.crucibleFrothDown de TC6 BETA26. Se activa con agua, calor superior a 150 y más de 500 aspectos; emite ocho partículas por tick de cliente desde los cuatro bordes. Conserva las burbujas por aspecto como efecto independiente.

Proveedor con vida de 12–23 ticks, color RGB 0.25/0/0.75, alfa 0.8, gravedad 0.05, fricción 0.98 y movimiento gaussiano de 0.001 por eje. Atlas original: fotograma 73 seguido de 66 y 65. La colisión se habilita cuando existe nivel de cliente; la vista de comprobación sin mundo la desactiva.

No altera recetas, consumo, calor ni flux. La capa translúcida moderna y brillo máximo son adaptaciones. Colisión real, iluminación, mezcla original y composición completa en mundo siguen pendientes de comprobación.

Validación: compilación de producción aprobada y diez pruebas requeridas del servidor aprobadas. Sincronización comprobada con 501 aspectos calientes, 500 tras el derrame original, calor 150 y crisol vacío. Cliente nativo: proveedor, geometría, duración y caducidad aprobados. Captura de los tres fotogramas inspeccionada. No certifica paridad visual ni early game completo.


# Estado del port — fix72

Corregida la sincronización del umbral de ebullición del crisol. El servidor notifica al cliente cuando pasa de calor 150 a 151 o de 151 a 150, aunque no cambien agua ni aspectos. Evita que los efectos condicionados por calor, incluido el rebose de fix71, conserven un estado de calor anterior.

Los ticks de calor que no cruzan el umbral continúan guardando el estado sin enviar actualizaciones visuales cada tick. Recetas, velocidad de calentamiento, consumo y derrames conservan sus reglas actuales.

Validación: compilación de producción aprobada; diez pruebas requeridas del servidor aprobadas. Prueba con ticks reales de la entidad y cambio de fuente de calor: 151→150→151, datos del paquete conservados y 30 aspectos intactos. No se instrumentó la recepción de paquetes en un cliente conectado. Presentación sin cambios respecto a la captura inspeccionada en fix71; no se generaron nuevas capturas ni se repitió la prueba de pantallas en esta revisión.

Pendientes: composición de efectos y colisiones en mundo, mezcla e iluminación exactas, y demás tareas de la auditoría. No certifica paridad ni early game completo.


# Estado del port — fix73

Primeras páginas ilustradas de fabricación arcana en el Thaumonomicon. Botón Recetas dentro de una investigación accesible con una receta arcana de cuadrícula disponible en su etapa actual. Muestra ingredientes, resultado, seis tipos de cristal cuando corresponda y coste vis; navegación entre recetas y regreso al libro. Fuente serif aprobada conservada.

processResources copia las recetas del datapack a recursos del cliente: la página utiliza exactamente el JSON enviado en la compilación, sin catálogo duplicado mantenido manualmente. Resolución por identificador exacto; no convierte automáticamente los aliases del original. Referencias ausentes, recetas ilustrativas, grupos y tipos todavía no compatibles no producen páginas ficticias.

Atlas gui_researchbook_overlay.png original: cuadrícula UV112,15 y marco de resultado UV20,3, escala2, disposición de ingredientes/resultados/cristales/coste según GuiResearchPage.drawArcaneCraftingPage. Contenedor y controles adaptados a la pantalla actual. Solo ingredientes simples de las recetas migradas actuales; rotación de ingredientes, grupos, addenda desbloqueadas, fabricación normal, crisol, infusión y planos pendientes.

Compilación de producción y diez pruebas requeridas del servidor aprobadas. Prueba de cliente verifica etapa actual, omisión de referencias ausentes, costes del taumómetro de20 vis/seis cristales y regreso/reapertura del libro. Cliente final aprobado y captura inspeccionada tras ajustar la altura al tamaño de interfaz de427x240; título, coste y controles visibles. No certifica igualdad de todo el libro, servidor remoto con datapack modificado ni paridad funcional. La página es de consulta, no fabrica ni altera investigación.


# Estado del port — fix74

Añadidas páginas de fabricación normal con cuadrícula al Thaumonomicon, junto a las arcanas de fix73. Usa la cuadrícula propia del atlas original gui_researchbook_overlay.png (UV60,15;51x52, escala2), resultado encima y cantidades nativas. Las páginas normales no dibujan costes de vis ni cristales.

Resolución exacta contra el JSON de recetas enviado en la compilación. Ingredientes simples comprobados contra el registro: referencias ausentes, tags todavía sin resolver o patrones fuera de3x3 se omiten completos. Evita presentar casillas vacías como una receta terminada. Acceso continúa limitado a la etapa actual de una investigación accesible y conserva el regreso al libro.

No implementa todavía ingredientes rotatorios por tag, fabricación sin forma, aliases, grupos, addenda, crisol, infusión ni planos. No certifica toda la lectura de recetas ni equivalencia de los datapacks de servidores externos.

Compilación de producción y diez pruebas requeridas del servidor aprobadas. Cliente nativo aprobado: placa de hierro con patrón BBB y resultado de3 unidades, omisión de referencias ausentes/tags sin resolver, regresión de página arcana y navegación. Captura final inspeccionada: título, cuadrícula, cantidad del resultado y controles visibles.


# Estado del port — fix75

Añadidas páginas de alquimia en crisol al Thaumonomicon para referencias exactas migradas con catalizador simple y aspectos conocidos. Muestra catalizador, resultado, iconos/cantidades de aspectos y tooltips; conserva navegación de recetas y regreso al libro. La consulta no fabrica ni altera el progreso del servidor.

Diseño de GuiResearchPage.drawCruciblePage: atlas original gui_researchbook_overlay.png con segmentos UV0,3/56x17, UV0,20/56x48 y flecha UV100,84/11x13, escalados por2. Posiciones del catalizador, resultado y aspectos derivadas del original; contenedor y fuente serif adaptados a la interfaz actual. Aspectos ordenados por identificador latino y distribuidos en filas de3. Se aceptan hasta9 tipos de aspectos para no desbordar esta página.

Fuente de datos: JSON exacto del datapack incluido en la compilación, copiado a recursos del cliente en processResources. Catalizadores no resolubles, grupos, aliases y recetas no compatibles quedan fuera. Infusión, planos, ingredientes por tag, grupos y addenda siguen pendientes. No certifica todo el libro ni datapacks modificados de servidores externos.

Compilación y diez pruebas requeridas del servidor aprobadas. Cliente final aprobado: Nitor con polvo de piedra luminosa,10 Ignis/10 Lux/10 Potentia, omisión de grupos sin resolver, regresión de recetas normal/arcana y navegación. Captura final inspeccionada, incluidos tintes originales de los aspectos. La vista sin mundo incorpora un fixture del catalizador; sus componentes se cargan normalmente al entrar en un mundo.


# Estado del port — fix76

Conectado el nombre legado thaumcraft:BrickArcane a la receta migrada thaumcraft:brickarcane dentro del libro. Comparado con ConfigRecipes líneas452–453: patrón KK/KK, cuatro piedras arcanas y resultado de cuatro ladrillos arcanos. Está disponible entre las recetas de FIRSTSTEPS etapa3, sujeto a la accesibilidad de esa entrada.

Alias explícito único; no convierte todos los nombres a minúsculas. StoneArcane, grupos inkwell, ingredientes por tag y demás referencias pendientes conservan su estado de revisión. No modifica recetas ni reglas del servidor.

Auditoría de enlaces actualizada con el alias contrastado. El empaquetado evita copiar el reporte de una prueba de servidor anterior cuando no hay ejecución de servidor en esta revisión.

Compilación de producción aprobada. Cliente aprobado: alias explícito, acceso a recetas de FIRSTSTEPS etapa3, patrón/cantidad conservados y referencias no verificadas omitidas. Captura final inspeccionada con cuatro piedras y cuatro ladrillos visibles; regresión de recetas arcana/normal/crisol aprobada. No se repitieron los diez tests de servidor de fix75 porque el cambio afecta exclusivamente a la consulta de recetas del cliente y la documentación; esos tests no se presentan como ejecutados en fix76.


# Estado del port — fix77

Ingredientes por etiquetas del registro del cliente para recetas de cuadrícula del Thaumonomicon. Rotación cada segundo con desplazamiento por ranura, como InventoryUtils.cycleItemStack del original. Usa las etiquetas recibidas del servidor, sin inventar variantes ni mantener un catálogo alternativo. Etiquetas vacías o sin cargar omiten la página hasta que sus ingredientes puedan resolverse.

Producción compilada. Prueba de cliente aprobada: recarga real de etiquetas del registro con fixture roble/abeto, ciclo y vuelta cada segundo, etiqueta inexistente rechazada y receta tablewood resuelta. Captura final inspeccionada. Regresiones de lectura y recetas previas aprobadas. No se repitieron pruebas de servidor: el cambio es exclusivamente de consulta del cliente.

Cerrado el cambio que estaba en curso al recibir hola. Automatización pausada. El nuevo pedido de interfaces1:1 requiere una revisión posterior; fix77 todavía conserva las composiciones adaptadas previas.


## Fix78 — composición original del libro y recetas

Restaurados proporciones del libro, ornamentos, flechas del atlas, papel cuadrado de recetas y fuente pixelada original. Producción y cliente aprobados; capturas inspeccionadas. Pendientes detallados en docs/INTERFACES_1_A_1_TC6.md; no se certifica paridad global. Automatización permanece pausada tras la señal hola.


## Fix79 — distribución del mapa y Taumómetro

Mapa a pantalla completa con categorías laterales, marco en teselas y botón de búsqueda con atlas correcto gui_research_browser.png. Recuperación del modelo OBJ del Taumómetro, alcance de entidades9, sonido privado y lectura del aura del servidor cada20 ticks con indicador original. Compilación y diez tests del servidor aprobados. No certificar paridad total: pendientes de efectos/objetivos especiales y comparación visual completa en docs/AUDITORIA_TAUMOMETRO_TC6.md.


## Fix80 — runas de escaneo

Animación FXBlockRunes portadas al uso local del Taumómetro: diez runas, dieciséis glifos, planos fijos, color/desvanecimiento/gravedad originales. Prueba del cliente aprobada: proveedor, geometría, vida45/90 y expiración. No se modifican recompensas del servidor; últimos diez tests de servidor en fix79. Resaltado pasivo, aspecto sobre objetivo y escaneos especiales siguen pendientes.


## Fix81 — investigación y manipulador originales

Restaurados fondos/ranuras de investigación255x255 y manipulador231x231 con inventario lateral. Controles de atlas nativo: crear/completar/descartar, flechas de ajustes, confirmar, ayudas por iconos y mazo clicable que usa tercera carta automáticamente con bonus. Conservados índices/transacciones. Diez tests del servidor aprobados. Editor completo y animaciones de cartas/requisitos siguen pendientes; no certificar1:1 global.
