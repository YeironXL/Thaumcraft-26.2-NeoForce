# Thaumcraft NeoForge 26.2 — fix44

Los fuelles reducen el tiempo de destilación del horno de esencia con la fórmula original.


## Fix44: fuelles conectados al horno de esencia

EssentiaSmelterBlockEntity cuenta hasta tres fuelles horizontales orientados hacia el horno, excluye la cara frontal y omite los vecinos alimentados por redstone, como la comprobación usada por depósitos nativos. Aplica la fórmula original de tiempo: entero de aspectos×2×(1−0,125×fuelles), mínimo1 para entrada válida. La interfaz y el procesamiento usan el mismo cálculo. La comprobación se actualiza desde los vecinos actuales, sin cachear una orientación obsoleta. No implementa todavía animación de fuelles ni SmelterAux.

Prueba viva con carbón: duración 40/35/30/25 según cero/uno/dos/tres fuelles, frontal excluido, mala orientación y redstone no cuentan. El carbón permanece hasta tick24 y se procesa en tick25 con tres; conserva los 20 aspectos entre depósito y flux. Diez pruebas pasan (`smelter-bellows-server.log`). El recorrido temprano conserva sus límites de materiales suministrados y jugador mock; no se certifica early game completo ni la etapa completa de alquimia.
