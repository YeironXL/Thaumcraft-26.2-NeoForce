# Estado del port — fix36

Manipulador inicial de focos funcional para el grafo Toque → Fuego del TC6 original. Incluye configuración de potencia 1–5 y duración 0–5 dentro de la complejidad máxima 15 del foco menor, menú e interfaz en español, costes de cristales por aspecto y niveles, consumo progresivo de aura y guardado del trabajo.

El servidor verifica investigación BASEAUROMANCY completada, proximidad y recursos antes de iniciar. Las acciones antiguas o repetidas no vuelven a pagar. La ranura queda bloqueada mientras fabrica, también frente a transferencias rápidas. El progreso y el temporizador de 20 ticks sobreviven al guardado/carga. Al terminar el foco guarda su configuración en un componente nativo persistente y sincronizado.

Se mantienen las fórmulas originales de complejidad, fabricación, daño, combustión, vis de lanzamiento y enfriamiento. El cobro verifica todos los recursos antes de modificar nada, evitando perder niveles cuando falta un cristal. El servicio de aura existente permite el cargador superior, aunque la distribución exacta entre nueve chunks queda pendiente de igualar al algoritmo histórico.

Verificación: diez pruebas de servidor superadas. Incluyen 28 configuraciones válidas, rechazo de datos inválidos, sincronización/persistencia, costes atómicos, aura parcial, límite de 20 vis por segundo, guardado a los 19 ticks, bloqueo de ranura y salida configurada. Cliente comprobado: pantalla, progreso y textos en español; captura inspeccionada sin solapamientos.

Pendiente: equipar y lanzar el foco con el guantelete; otros medios/efectos, nombres y grafos de focos avanzados; aspectos derivados de recetas; prueba integral desde jugador nuevo. El early game aún no está completo y el mid game no se declara portado.
