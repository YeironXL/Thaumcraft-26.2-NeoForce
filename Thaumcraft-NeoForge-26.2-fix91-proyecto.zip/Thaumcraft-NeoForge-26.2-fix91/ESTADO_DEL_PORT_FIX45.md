# Thaumcraft NeoForge 26.2 — fix45

Accesorios auxiliares del horno: receta, orientación y transferencia a columnas adicionales de alambiques.


## Fix45: accesorios auxiliares del horno de esencia

SmelterAux deja de ser un bloque genérico: tiene orientación horizontal y colocación solo contra caras laterales/posterior de un horno, rechazando frontal y vertical. El horno conserva su salida principal y añade hasta tres columnas de alambiques encima de accesorios orientados hacia él. Cada intervalo original de salida intenta transferir un aspecto por columna sin duplicarlo; no requiere combustible ni inventario separado del accesorio. Se añade la receta original de ImprovedSmelting: 100 vis, Aer1/Terra1, madera de greatwood, filtro, placas latón/hierro, fuelle y construcción alquímica. Estados del modelo rotados por orientación.

Diez pruebas pasan (`smelter-aux-full-server.log`): columnas principal/tres auxiliares, frontal excluido, conservación exacta y receta con puerta de investigación y consumo de costes. La prueba de receta usa un jugador independiente con investigación concedida para aislarla: no certifica la cadena natural de obtención de materiales/capítulo. Una fixture necesitaba ejecutar el tick en el intervalo real de salida; ajusta/restaura tiempo de mundo dentro de la misma llamada. La búsqueda de drop de mesa arcana se delimita al bloque destruido en lugar de incluir bloques vecinos. Pendientes animación/modelo y colisiones fieles del accesorio, pruebas de colocación manual y recorrido conectado. Early game sigue sin certificado manual.
