# Estado del port — fix66

Carta Curiosidad de TC6, según CardCurio: consume una unidad del curio elegido y 1 inspiración. Otorga 5 puntos de Fundamentos y 5 en una categoría aleatoria. Las variantes Básica, Arcana, Preservada, Antigua, Sobrenatural, Conocimiento y Retorcida conceden además 25–35 puntos en Fundamentos, Auromancia, Alquimia, Golemancia, Sobrenatural, Infusión y Artificio, respectivamente. Ritos concede 15–20 de Sobrenatural y 10–15 de Auromancia. Dos sorteos independientes pueden conceder cero, uno o dos robos adicionales.

Se selecciona entre las pilas de curios presentes en los 36 espacios principales del inventario, igual que el original; la cantidad de una pila no aumenta su peso. El port representa las siete variantes originales como registros de objetos separados. El registro básico adicional curio usa la rama por defecto de CardCurio, que concede Fundamentos; no se presenta como una octava variante del ItemCurio original. Se guarda la variante al extraer la carta y se consume únicamente al activarla. Si se retira el objeto del inventario, se rechaza sin puntos ni coste de inspiración. Una activación no puede repetirse.

Se conservan cartas verticales, fuente serif y reglas del servidor. La descripción española e inglesa especifica consumo y recompensas. Esta incorporación usa los objetos ya registrados, pero no certifica su obtención natural, botín original ni otros usos pendientes de curios.

El catálogo incorpora 18 de las 35 cartas inventariadas. No certifica Golemancia, Infusión ni early game completos.

Validación final: producción y migración aprobadas; diez pruebas requeridas del servidor aprobadas. Cliente nativo aprobado, texto de costes y recompensas localizado y captura de la carta inspeccionada. El primer intento del cliente coincidió con una actualización de recursos compilados y falló al cargar un fondo; la repetición secuencial pasó sin errores GUI.
