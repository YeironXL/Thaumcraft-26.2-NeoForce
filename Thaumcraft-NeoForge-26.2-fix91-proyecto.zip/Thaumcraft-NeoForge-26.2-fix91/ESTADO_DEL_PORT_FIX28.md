# Thaumcraft NeoForge 26.2 — fix28

Centrífuga de esencia funcional, conectada al transporte de fix27. El port completo continúa pendiente.

## Añadido

- La centrífuga recibe esencia compuesta por abajo y entrega esencia por arriba. No tiene conexiones laterales.
- Consume una unidad de un aspecto compuesto y, tras un ciclo de 39 ticks, devuelve una unidad de uno de sus dos componentes, elegido al azar. No devuelve ambos; esta es la regla de TC6 BETA26.
- Rechaza aspectos primales sin consumirlos. Entrada con succión 128 cuando está libre y 64 mientras procesa; la cara superior no genera succión.
- Redstone detiene la entrada y el procesamiento. La salida ya terminada sigue disponible, como en el original.
- Si la salida está ocupada, conserva el resultado y no consume otra entrada ni vuelve a sortear el componente.
- Entrada, salida y temporizador persisten al guardar/cargar.
- Sonido original de bombeo mientras procesa y consulta de estado mediante clic con mano vacía.
- Receta arcana de la centrífuga: investigación CENTRIFUGE, 100 vis, un cristal de ordo y uno de perditio, con los ingredientes originales.
- Recetas de los componentes que faltaban: resonador mórfico y construcción alquímica. Se conservan sus requisitos originales de investigación y vis.
- El depósito multi-aspecto ofrece aleatoriamente un aspecto cuando el receptor no pide uno concreto, como en el original. Esto evita que una centrífuga quede detenida indefinidamente porque el primer aspecto del depósito sea primal.

## Uso

1. Conecta un tarro o una línea de tubos a la cara inferior de la centrífuga.
2. Conecta la cara superior a la red de salida. Un depósito encima puede recibir los distintos componentes producidos; una red con filtros permite separarlos.
3. Usa redstone para pausar el procesamiento. Clic con mano vacía muestra entrada, salida y tiempo restante.

## Validación

- Tres GameTests de servidor: cadena de destilación, variantes de tubos y centrífuga.
- La prueba de centrífuga cubre rechazo de primales, pausa antes de consumir y durante el ciclo, conservación del temporizador y del resultado al guardar, salida solo superior, extracción única y detención con salida ocupada.
- Prueba de cuatro unidades de potentia: una extraída manualmente por la API de transporte y tres recogidas por un depósito; solo se admiten ordo o ignis como resultados.
- El cliente verifica la geometría de la centrífuga junto a los bloques anteriores: 6.548 estados de bloques.
- Build de producción y regresiones de migración; el JAR excluye los componentes de prueba.

## Límites actuales

- Se conserva el modelo original estático; la animación suave de rotación aún no está portada.
- Se implementa el transporte nativo de este port, no una capa de compatibilidad con otros mods de esencia.
- Las recetas mantienen los requisitos originales. La progresión completa para obtener teoría de investigación y ciertos materiales sigue dependiendo de sistemas pendientes del port.
- Esto no completa infusión, focos, gólems, mundo, criaturas ni las demás máquinas pendientes. La auditoría general de bugs continúa prevista para después de la implementación.

Referencia contrastada: TileCentrifuge.java y ConfigRecipes.java de la reconstrucción comunitaria TC6 BETA26 disponible en work/reference-tc6.
