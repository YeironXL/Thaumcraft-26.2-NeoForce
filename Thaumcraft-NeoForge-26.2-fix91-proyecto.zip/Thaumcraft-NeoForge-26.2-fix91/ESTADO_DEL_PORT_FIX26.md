# Thaumcraft NeoForge 26.2 — fix26

Implementa conjuntamente la cadena básica de destilación, transporte por tubo normal y líquido visible en tarros. Continúa sobre fix25; el port entero aún está incompleto.

## Destilación

- Hornos alquímicos básico, de thaumium y de vacío: combustible, entrada, temporizador persistente y reserva de hasta 256 unidades de aspectos.
- Tiempo de destilación: dos ticks por unidad de aspecto del objeto. Rendimiento nominal 80 %, 90 % y 95 %, respectivamente; para vitium se multiplica por 0,66. Cada unidad perdida pasa a flux.
- El combustible usa los valores nativos del juego; Alumentum dura 3.200 ticks. Se conserva el recipiente de combustible cuando corresponde.
- El horno entrega una unidad a la columna contigua de alambiques cada 15 ticks (básico/vacío) o 10 ticks (thaumium), según la implementación de referencia. Da prioridad a los alambiques que ya contienen el mismo aspecto.
- Alambiques de 128 unidades, contenido persistente, salida por caras distintas de la inferior y extracción manual con frascos. Los frascos llenos no introducen esencia en el alambique.
- Orientación al colocar el horno, frente encendido/apagado y luz cuando consume combustible.
- Recetas originales iniciales para horno básico, alambique, filtro y ocho tubos.

## Transporte

- Tubo normal funcional: almacena una unidad, conserva su contenido al guardar el mundo, propaga succión perdiendo un punto por tramo y extrae solamente hacia mayor succión.
- Comprueba aspecto, capacidad y succión mínima antes de transferir. No carga chunks vecinos para buscar conexiones.
- Recalcula succión cada dos ticks y mueve una unidad cada cinco. Los conflictos de aspecto/succión detienen temporalmente el tubo.
- Conexiones visuales y colisión por las seis caras.
- Tarro normal: succión 32 mientras tiene espacio; deja de atraer al llenarse. El mínimo 32 impide que un tubo normal vecino vacíe un tarro lleno.
- Tarro del vacío: sigue atrayendo al estar lleno, elimina el exceso y tiene una probabilidad de 1/250 de generar una unidad de flux por absorción excedente.

## Líquido visible

- Tarros normales y del vacío: vacío y cuatro niveles de llenado, con 37 colores de aspecto.
- El servidor sincroniza nivel/color mediante estados del bloque; se usan las texturas originales y modelos nativos con caras de líquido tintadas.
- La información se reconstruye al cargar el bloque y se conserva al recoger/colocar el tarro.

## Cómo usar la cadena

1. Coloca un horno alquímico y uno o más alambiques directamente encima.
2. Introduce un objeto con aspectos conocidos haciendo clic en la cara superior del horno. Introduce combustible por un lateral. Cada clic introduce una unidad.
3. Conecta el lateral del alambique a una línea de tubos normales que termine encima del tarro.
4. Clic con mano vacía en el horno muestra entrada, combustible, tiempo de combustión y reserva de esencia. Agachado con mano vacía, la cara superior devuelve la entrada y los laterales devuelven el combustible.
5. Los frascos vacíos extraen diez unidades del alambique o del tarro; los llenos introducen diez en el tarro.

## Validación

- Build y regresiones de migración.
- GameTest en mundo nuevo desechable: carga de recetas, entrada y combustible, destilación real, alambique, dos tubos y tarro. La prueba contabilizó las 20 unidades de entrada como esencia recibida más flux, con reserva y tubos vacíos al terminar.
- Persistencia del temporizador de combustible, persistencia previa de tarros, nivel visual, rechazo de extracción por succión insuficiente y absorción por tarro del vacío lleno.
- Cliente de desarrollo: modelos de 2.003 estados, incluyendo hornos, conexiones y tarros. Para todos los tarros llenos se comprobaron las seis caras tintadas del líquido y la altura de cada nivel.
- No se ha realizado aún una revisión visual manual de una partida completa ni la auditoría general de bugs del port.

## Pendiente y límites

- El horno acepta los objetos cuyo mapa de aspectos ya está implementado; aún falta deducir los aspectos de todas las recetas y cubrir todos los objetos del original.
- Pantalla propia del horno y carga por tolvas/capacidades: por ahora el manejo es mediante las caras del bloque.
- Fuelles, auxiliares, respiraderos y bonificación de velocidad de Alumentum.
- Tubos con filtro, válvula, restricción, dirección y buffer; etiquetas de tarros/alambiques, abrazaderas y partículas/sonidos completos de ventilación.
- Los dos hornos avanzados funcionan colocados, pero sus recetas de mejora todavía están pendientes.
- La disponibilidad de materiales y la progresión completa en supervivencia dependen de sistemas aún pendientes, como generación de árboles y teoría de investigación.
- El líquido añadido se muestra en los tarros colocados; el objeto de inventario conserva el contenido pero mantiene su modelo exterior.

Referencia de reglas: código comunitario descompilado TC6 BETA26, TileSmelter, TileAlembic, TileTube, TileJarFillable, TileJarFillableVoid y ConfigRecipes. No es una publicación oficial del código de Azanor.
