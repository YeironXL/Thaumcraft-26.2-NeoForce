# Thaumcraft NeoForge 26.2 — fix42

Verifica la receta existente del taumio y el inicio de metalurgia por progresión real.


## Fix42: receta nativa del taumio e inicio de metalurgia

Se confirma la receta existente `thaumiumingot.json`: crisol, METALLURGY@2, lingote de hierro, Praecantatio5/Terra5, un lingote de taumio. Coincide con ConfigRecipes de TC6. La búsqueda inicial omitió el archivo; comparar el ZIP fix41 confirma que la receta ya existía con esos mismos datos. El cambio de producción del JSON se limita a normalizar espacios/saltos; la novedad funcional de esta entrega es la prueba continua de metalurgia. No se dan por completas herramientas, armaduras, propiedades especiales ni infusión por registrar este material.

La prueba continua inicia METALLURGY sin conceder etapas; disuelve Salis y piedra, verifica que intentar hierro antes de etapa2 no produce taumio ni paga agua (se disuelve como material), disuelve pedernal y fabrica latón, cobra 16 observaciones Alchemy y avanza a etapa2. Fabrica taumio con los aspectos ya presentes, cobra exactamente cinco Magic/cinco Earth y 50 mB y comprueba un lingote físico. Diez pruebas pasan (`metallurgy-server.log`). La teoría requerida para completar el capítulo aún no se incorpora a este paso, ni se certifica abastecimiento natural/partida conectada. Los recursos base, calor/agua/aura y XP permanecen suministrados; early game completo sigue pendiente de comprobación manual y auditoría del suministro natural.
