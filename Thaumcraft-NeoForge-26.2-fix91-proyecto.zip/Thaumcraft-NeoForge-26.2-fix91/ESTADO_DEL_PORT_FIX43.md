# Thaumcraft NeoForge 26.2 — fix43

Receta de mejora del horno de esencia a taumio con costes originales y comprobación de pago atómico.


## Fix43: fabricación del horno de esencia de taumio

Se añade la receta ausente `smelter_thaumium.json`, contrastada con ConfigRecipes.EssentiaSmelterThaumium: ESSENTIASMELTERTHAUMIUM, 250 vis, Ignis2, patrón BFB/IGI/III, dos placas de latón, cinco de taumio, horno básico y construcción alquímica. Un horno de taumio por operación. El bloque/procesamiento ya existía; esta entrega habilita su fabricación, no completa accesorios ni toda la etapa.

Una fixture independiente verifica bloqueo sin investigación, fallo sin consumir materiales con 249 vis, éxito con 250, consumo de todos los ingredientes/cristales y craft history. Esta prueba concede el capítulo completado a un jugador separado para aislar la receta: no demuestra aún la cadena continua de obtención de teoría/tubos y desbloqueo del capítulo. Diez pruebas pasan (`smelter-upgrade-server.log`). Se mantienen los límites del recorrido temprano y de las entregas anteriores.
