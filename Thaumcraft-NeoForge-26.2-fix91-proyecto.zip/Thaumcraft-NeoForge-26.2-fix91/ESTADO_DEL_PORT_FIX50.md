# Thaumcraft NeoForge 26.2 — fix50

Letras más limpias: se elimina la sombra oscura de títulos, estados y paginación del Thaumonomicon y de los botones temáticos compartidos. Los botones usan peso normal; conservan centrado, recorte y desplazamiento de etiquetas largas, contraste de controles desactivados y navegación nativa.

La fuente base de Minecraft se conserva. No se añaden fuentes externas ni se cambian las mecánicas del mod. Hereda el contenido y los límites de fix49.

Validación completada: compilación de producción y cliente nativo con seis capturas, revisando legibilidad del libro y de la mesa de investigación. Las diez pruebas del servidor de fix49 son la última comprobación de mecánicas; esta revisión solo modifica presentación.
