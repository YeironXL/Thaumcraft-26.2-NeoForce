# Thaumcraft NeoForge 26.2 — fix41

Corrección de prioridad de recetas del crisol y ampliación de la comprobación de abastecimiento del primer foco.


## Fix41: prioridad del crisol y cristal Ignis producido

El crisol selecciona ahora la receta compatible, conocida y pagable con mayor suma de aspectos; en empate conserva la primera. Es la regla de ThaumcraftCraftingManager.findMatchingCrucibleRecipe en TC6. Antes tomaba la primera compatible sin comparar el coste. La suma usa long para evitar desbordamiento. Se verifican prioridad, empate y exclusión por elegibilidad, junto al recorrido continuo real.

El jugador produce ahora también Ignis: disuelve un carbón (Ignis10/Potentia10), usa las nueve pepitas de cuarzo producidas por receta, recoge nueve cristales incluyendo Ignis y conserva dos aspectos residuales. Se consumen 450 mB de agua. Se retira la fixture de Ignis de la preparación del foco; ambos cristales requeridos proceden ahora de objetos físicos producidos por crisol. Los aspectos del foco vacío proceden de la mesa arcana convertida/recuperada, Salis y vidrio, según la comprobación posterior a fix40.

Se reubican fixtures de crisol/mesa dentro del área inicial tras un ensayo donde no se recuperó el cristal esperado; no se atribuye ese fallo a una causa de producción no demostrada. Diez pruebas requeridas pasan (`fire-supply-server.log`). Siguen suministrados recursos base, cristales primales para catalizador/construcción, agua, aura y XP; ticks/desplazamientos/escaneos son simulados. No se cierra early game ni se certifica partida manual/conexión real/paridad completa. Última función corregida: prioridad de recetas del crisol. Próximas etapas: abastecimiento base y cobertura de aspectos; ampliación de alquimia/artificio hacia infusión sin convertir registros vacíos en contenido terminado.
