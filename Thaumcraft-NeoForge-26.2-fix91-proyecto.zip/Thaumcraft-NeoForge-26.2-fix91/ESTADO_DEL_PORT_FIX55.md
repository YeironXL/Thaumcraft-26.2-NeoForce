# Estado del port — fix55

## Cambios

- Opciones de investigación como cartas verticales de papel original, con títulos serif legibles, icono de categoría y coste de inspiración.
- Marco de selección al pasar el cursor o enfocar con teclado. Los detalles y requisitos completos continúan en el tooltip de cada carta.
- Totales por categoría presentados con sus iconos originales y cantidades; detalle al pasar el cursor, incluyendo categorías descartadas.
- Inventario, materiales, ayuda y acciones del servidor conservados.

## Verificación

Compilación de producción y pruebas de regresión, diez pruebas requeridas del servidor y revisión de capturas del cliente (cartas activas y selección de ayudas incluida).

## Límites

Las cartas usan una disposición compacta adaptada a la interfaz actual. No se afirma paridad visual total: siguen pendientes reparto animado, inclinación, efectos y detalles originales de las hojas. Esta entrega no amplía la cantidad de cartas funcionales ni cierra una etapa del juego.
