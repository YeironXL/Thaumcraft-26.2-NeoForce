# Estado del port — fix71

Rebose morado del crisol según TileCrucible.drawEffects y FXDispatcher.crucibleFrothDown de TC6 BETA26. Se activa con agua, calor superior a 150 y más de 500 aspectos; emite ocho partículas por tick de cliente desde los cuatro bordes. Conserva las burbujas por aspecto como efecto independiente.

Proveedor con vida de 12–23 ticks, color RGB 0.25/0/0.75, alfa 0.8, gravedad 0.05, fricción 0.98 y movimiento gaussiano de 0.001 por eje. Atlas original: fotograma 73 seguido de 66 y 65. La colisión se habilita cuando existe nivel de cliente; la vista de comprobación sin mundo la desactiva.

No altera recetas, consumo, calor ni flux. La capa translúcida moderna y brillo máximo son adaptaciones. Colisión real, iluminación, mezcla original y composición completa en mundo siguen pendientes de comprobación.

Validación: compilación de producción aprobada y diez pruebas requeridas del servidor aprobadas. Sincronización comprobada con 501 aspectos calientes, 500 tras el derrame original, calor 150 y crisol vacío. Cliente nativo: proveedor, geometría, duración y caducidad aprobados. Captura de los tres fotogramas inspeccionada. No certifica paridad visual ni early game completo.
