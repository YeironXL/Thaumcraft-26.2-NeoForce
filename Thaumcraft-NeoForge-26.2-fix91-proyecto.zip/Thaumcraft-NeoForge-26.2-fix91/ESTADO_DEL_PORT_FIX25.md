# Thaumcraft NeoForge 26.2 — fix25

Continúa sobre fix24. Esta entrega implementa almacenamiento y trasvase manual de esencia; no completa el sistema de transporte ni el mod.

## Implementado

- Tarros normal y del vacío: entidad nativa persistente con capacidad de 250 unidades de un único aspecto. Rechazan mezclas, cantidades negativas y desbordamiento durante el trasvase manual.
- Frascos vacíos y llenos: introducen/extraen exactamente 10 unidades, conservan el aspecto y devuelven el recipiente correspondiente. El servidor realiza el cambio; también se consume el recipiente en creativo, como en el código de referencia.
- 37 variantes de frascos llenos en creativo, con nombres por aspecto y capa de líquido coloreada sobre el vidrio original.
- El tarro conserva su esencia en el objeto que suelta al romperse y la recupera al colocarlo; usa componentes nativos, también persistidos al guardar el mundo.
- Clic sin objeto informa cantidad y aspecto. Agacharse con la mano vacía vierte el contenido y genera flux equivalente, según el original.
- Receta de ocho frascos con vidrio y arcilla. Receta arcana del tarro normal: investigación WARDEDJARS, 5 vis, paneles de vidrio y losa de madera.

## Pendiente en este sistema

- Destilación mediante horno alquímico y alambiques: todavía no existe una fuente automática de esencia para llenar estos tarros en supervivencia.
- Tuberías, succión, filtros, válvulas y conexión a las máquinas.
- El tarro del vacío comparte por ahora el trasvase manual del tarro normal. La absorción automática de exceso y su contaminación probabilística todavía no están implementadas.
- Etiquetas, abrazaderas y renderizado del nivel/color dentro del tarro colocado.
- Conversión de tarro normal a vacío conservando componentes: la receta especial original aún no está portada.
- Las demás limitaciones descritas en ESTADO_DEL_PORT_FIX24.md siguen vigentes, incluidas infusión, focos, gólems y sistemas de investigación avanzados.

## Referencia

Código comunitario descompilado TC6 BETA26 ya disponible en work/reference-tc6: ItemPhial, TileJarFillable, TileJarFillableVoid, BlockJar y ConfigRecipes. No es una publicación oficial del código de Azanor.

## Verificación

Se ejecutan build y regresiones de capacidad/serialización. GameTest en un mundo desechable comprueba trasvases de diez unidades, rechazo de mezclas, límite de capacidad, loot con componentes, restauración desde el objeto y carga del estado guardado. La prueba de cliente carga las 37 variantes de frascos en todos los contextos de objeto. Esto no sustituye la revisión visual manual dentro de una partida ni la auditoría general del mod pendiente.
