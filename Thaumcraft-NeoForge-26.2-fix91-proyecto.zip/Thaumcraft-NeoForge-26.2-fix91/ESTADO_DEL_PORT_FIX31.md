# Thaumcraft NeoForge 26.2 — fix31

Inventario automático de los tres hornos alquímicos.

- Los hornos básico, de taumio y del vacío implementan inventario nativo y la capacidad de transferencia de NeoForge.
- Reglas de TC6 TileSmelter: laterales exponen el material; la cara inferior expone el combustible; la superior no admite objetos, dejando el espacio para alambiques.
- Una tolva orientada hacia un lateral introduce materiales con aspectos conocidos. Una tolva debajo retira el combustible o su recipiente, como en el original. El combustible puede introducirse manualmente o mediante un sistema que inserte por la cara inferior; una tolva vanilla no empuja hacia arriba.
- Las transferencias respetan componentes y límites de pila. Los materiales sin aspectos conocidos y objetos sin tiempo de combustión se rechazan en sus respectivas ranuras.
- Las transacciones canceladas conservan inventario y progreso. Cambiar el material reinicia su procesamiento, incluso si se guarda antes del siguiente tick.
- Se conserva el formato anterior de guardado; se añade la identidad del material en proceso para evitar heredar progreso al cambiarlo.
- GameTest: tres variantes, caras, capacidad, mezclas, cancelación, guardado/carga y tolvas reales, incluido el recipiente de un cubo de lava.
- La prueba de automatización se ejecuta en un grupo separado, pues su contaminación por chunk interfería con la medición de conservación de esencia de otra prueba.
- Compilación de producción, regresiones de migración y cinco pruebas de servidor. No se modifica el apartado visual ni se repite la prueba de cliente.

Siguen pendientes la interfaz del horno, los accesorios, algunos usos de los fuelles, las recetas de mejora y las etiquetas de aspectos derivadas de todos los objetos.
