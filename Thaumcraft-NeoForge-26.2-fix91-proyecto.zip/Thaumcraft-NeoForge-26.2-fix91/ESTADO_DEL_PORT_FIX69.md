# Estado del port — fix69

El agua del crisol vuelve a usar los multiplicadores RGB de TileCrucibleRenderer.renderFluid de TC6 BETA26. La concentración depende de la suma de aspectos: recolor=n/500; para n>0 se transforma a 0.5+recolor/2 y se limita a 1. RGB: 1-recolor/3, 1-recolor, 1-recolor/2. Se conserva water_still animado y los cuatro niveles de agua existentes; se elimina la dependencia del color del bioma.

El servidor transmite el contenido del crisol al cargar el bloque y al cambiar agua o aspectos. También notifica las pérdidas por rebose. El cliente actualiza la malla después de recibir el contenido para evitar mantener un tinte anterior cuando el nivel de agua no cambia. Los cambios exclusivos de calor no envían una actualización visual cada tick.

No cambia recetas, pagos, cantidades, disolución, calor ni flux. Se verifican datos de actualización antes y después de fabricar Nitor y la paleta original de 0, 1, 250 y 500 aspectos; saturación y límites de los contadores incluidos. La captura de paleta representa los multiplicadores RGB, no una certificación de la apariencia completa del agua sobre el mundo.

Referencia visual: beta 25, fotograma 12:42, junto al contraste de código BETA26 documentado en REFERENCIA_VISUAL_VIDEO_TC6.md. Solo se inspeccionaron los fotogramas allí enumerados; no se afirma una revisión completa del video.

Vista integrada en mundo, mezcla/transparencia exacta del renderer original, burbujas coloreadas por aspecto y todos los efectos pendientes de la auditoría siguen sin certificarse. El contenido funcional conserva las 21 de 35 cartas implementadas de fix68; no certifica early game completo.

Validación final: compilación de producción y migración aprobadas; diez pruebas requeridas del servidor aprobadas. Datos de actualización del crisol verificados antes y después de pagar Nitor. Cliente nativo aprobado sin errores GUI; paleta original y límites comprobados. Captura de espuma y cuatro muestras de concentración inspeccionada. Vista completa en mundo pendiente.
