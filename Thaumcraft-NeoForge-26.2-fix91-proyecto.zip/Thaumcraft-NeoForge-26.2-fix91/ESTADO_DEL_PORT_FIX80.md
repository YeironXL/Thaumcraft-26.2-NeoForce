# Fix80 — animación de escaneo y runas

Portado FXBlockRunes a partículas nativas. Diez runas al pulsar el Taumómetro sobre un bloque o entidad; dieciséis glifos originales con color violeta variable, planos orientados a0/90/180/270, desplazamientos y tamaño originales, aparición gradual y desvanecimiento. Duración45 ticks en bloques y proporcional a la altura de entidades; caída por gravedad0.03. Efecto local del cliente, sin alterar recompensas ni autoridad del servidor.

Prueba de cliente aprobada: proveedor nativo, geometría, duraciones45/90 y expiración. La iluminación usa el modo fullbright moderno; no se certifica identidad de toda la tubería gráfica antigua. Sigue pendiente el resaltado pasivo de objetivos no escaneados, aspectos sobre el objetivo y escaneos especiales. No se afirma100% de paridad del Taumómetro.
