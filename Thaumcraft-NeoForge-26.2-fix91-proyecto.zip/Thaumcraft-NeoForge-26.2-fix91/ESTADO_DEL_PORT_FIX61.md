# Estado del port — fix61

El mapa de investigaciones dibuja las relaciones secundarias originales (`siblings`) sin flechas. Cuando una relación padre-hijo ya se representa como secundaria, no dibuja encima otra conexión de requisito. Respeta las referencias visuales ocultas con prefijo `~` y la orientación REVERSE.

Los requisitos recuperan los grises de GuiResearchBrowser (0.6 completado, 0.2 pendiente); los secundarios usan el gris azulado original. Los requisitos con una etapa `@` se colorean según esa etapa, sin exigir completar innecesariamente toda la investigación.

No cambia disponibilidad, costes ni progreso del servidor. La comprobación de alquimia completa todas las entradas solo en una instantánea ficticia de la pantalla, para revisar sus conexiones; no desbloquea contenido de jugadores reales. La prueba exige la referencia original ESSENTIASMELTER → WARDEDJARS y conserva una captura propia.

Animaciones, marcadores de novedades, recetas ilustradas y revisión integral en mundo siguen pendientes.

La instantánea gráfica añade el campo scanned_count requerido por el cliente. Antes de guardar la captura, comprueba que el selector muestra Alquimia y desplaza el mapa dos filas para incluir el enlace horno/frascos.

Validación: compilación de producción, comprobaciones de migración, revisión gráfica nativa y las diez pruebas requeridas del servidor aprobadas. Captura de Alquimia inspeccionada con el mapa desplazado; sin errores de tareas asíncronas del cliente en la ejecución final.
