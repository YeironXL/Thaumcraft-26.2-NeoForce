# Thaumcraft NeoForge 26.2 — fix52

El selector superior de categorías del Thaumonomicon (Fundamentos, Alquimia, etc.) adopta el botón original TC6, la fuente serif Alegreya, tinta marrón y borde de selección/hover del resto del libro. Sustituye el botón gris estándar en el diseño compacto. El diseño amplio ya usa botones temáticos.

Conserva el cambio hacia delante al pulsar, hacia atrás con Mayús y el cambio con rueda; restablece selección y paginación como antes. Hereda contenido y límites de fix51. Solo presentación del selector.

Validación: cliente nativo con seis vistas y revisión de captura del libro; compilación de producción. Última validación de mecánicas del servidor: diez pruebas de fix49.
