# Estado del port — fix72

Corregida la sincronización del umbral de ebullición del crisol. El servidor notifica al cliente cuando pasa de calor 150 a 151 o de 151 a 150, aunque no cambien agua ni aspectos. Evita que los efectos condicionados por calor, incluido el rebose de fix71, conserven un estado de calor anterior.

Los ticks de calor que no cruzan el umbral continúan guardando el estado sin enviar actualizaciones visuales cada tick. Recetas, velocidad de calentamiento, consumo y derrames conservan sus reglas actuales.

Validación: compilación de producción aprobada; diez pruebas requeridas del servidor aprobadas. Prueba con ticks reales de la entidad y cambio de fuente de calor: 151→150→151, datos del paquete conservados y 30 aspectos intactos. No se instrumentó la recepción de paquetes en un cliente conectado. Presentación sin cambios respecto a la captura inspeccionada en fix71; no se generaron nuevas capturas ni se repitió la prueba de pantallas en esta revisión.

Pendientes: composición de efectos y colisiones en mundo, mezcla e iluminación exactas, y demás tareas de la auditoría. No certifica paridad ni early game completo.
