# Fix91 — observaciones celestiales

Escaneo del cielo conectado al uso del taumómetro cuando no encuentra objeto. Exige CELESTIALSCANNING completada, Overworld, cielo visible y mirar hacia arriba. Selección angular de Sol/Luna y dirección de estrellas según ScanSky; reloj moderno de Overworld adaptado a la curva celeste1.12.2. Consume un papel y exige tintero sin desgastarlo, como la referencia. Una nota por objetivo/día de tiempo total; limpia claves antiguas. Inventario lleno deja caer la nota.

Trece variantes persistentes/sincronizadas: Sol, cuatro direcciones de estrellas y ocho fases lunares. Tooltip original y modelos por custom_model_data con papel base y símbolo original en dos capas. Componente celestial_note validado0..12. Se preservan todas las demás interacciones y canalización.

Diez pruebas del servidor aprobadas: puerta de investigación, cielo real de Overworld, puntería, gasto de papel, objeto físico con variante, duplicado diario sin coste, tintero conservado y dirección de estrellas. Prueba usa investigación concedida para aislar la función: no certifica el desbloqueo natural del capítulo.

Pendientes: carta Celestial consumiendo notas, pruebas de todas las fases/direcciones y revisión visual completa de los trece iconos. No se cierra early game ni paridad integral del sistema.
