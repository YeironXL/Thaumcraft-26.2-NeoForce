# Estado del port — fix64

El manipulador de focos genera los destellos centrales de TileFocalManipulator.update: fotogramas originales 448–456 del atlas, vida de 6–10 ticks, transparencia 0.8, tamaño y colores aleatorios en los intervalos originales. La posición se distribuye alrededor del centro, a altura 1.4 sobre el bloque.

Se emiten únicamente durante un trabajo activo con un foco válido. La densidad se adapta a cuatro emisiones por segundo desde el servidor, frente al efecto original cada tick de cliente. Se usa aleatoriedad visual separada de la del mundo; no modifica la secuencia aleatoria de las mecánicas.

El renderizado usa la capa translúcida moderna y brillo máximo; la mezcla aditiva exacta del motor original queda pendiente. Los haces entre cristales y centro, el anillo de cristales y la revisión visual completa en mundo no están implementados por este cambio.

No cambia vis, niveles, cristales, duración del trabajo ni su persistencia. La verificación nativa comprueba registro del proveedor, duración, geometría y caducidad; una vista de prueba conserva los nueve fotogramas originales.

Referencia funcional: TileFocalManipulator.update y FXGeneric de TC6 1.12.2 BETA26. La guía de auromancia en 14:11 documentada muestra haces; no se confunde ese efecto todavía pendiente con estos destellos centrales.

Validación: compilación de producción y migración aprobadas; proveedor, duración, geometría y caducidad de los destellos comprobados en el cliente nativo. Captura de nueve fotogramas inspeccionada. Las diez pruebas requeridas del servidor pasaron, incluidas fabricación, costes y persistencia del foco. No se ha certificado aún la apariencia integrada en mundo.
