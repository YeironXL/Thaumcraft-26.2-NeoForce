# Estado del port — fix70

Burbujas del crisol coloreadas según un aspecto presente en su mezcla. Contraste con TileCrucible.drawEffects y FXDispatcher.crucibleBubble de TC6 BETA26: probabilidad de 1/6 por tick de cliente, selección uniforme entre tipos de aspecto presentes, posición sobre el agua y dentro de la cuadrícula original de 32 unidades.

Proveedor nativo con vida de 15–24 ticks, tamaño base 0.3–0.6, gravedad -0.001, fricción 0.98 y movimiento gaussiano de 0.002 añadido cada tick. Usa el atlas original: fotograma 64 durante la burbuja y secuencia final 66, 66, 65, conforme la indexación inversa de finalFrames en FXGeneric.

El color se conserva como opción ARGB con codecs JSON y de red. Se emite en el cliente sobre el contenido sincronizado de fix69. No añade paquetes por burbuja ni consume aleatoriedad del servidor. Requiere agua y al menos un aspecto; no exige calor de ebullición, igual que el original. La altura se adapta a los cuatro niveles visibles de agua ya existentes.

No modifica recetas, concentración, disolución, costes, calor ni flux. Se conserva la espuma gris de ebullición como efecto separado. La capa translúcida moderna y brillo máximo son adaptaciones; iluminación y mezcla exactas del original no están certificadas.

Vista integrada en mundo, rebose por los laterales, efectos de disolución/cristalización y el resto indicado en la auditoría siguen pendientes. No se considera el sistema completo de efectos terminado ni se certifica early game completo.

Validación final: producción y migración aprobadas; diez pruebas requeridas del servidor aprobadas. Cliente nativo aprobado: 37 colores conservados tras codecs JSON/red, proveedor, geometría, duración 15–24 ticks y caducidad verificados. Captura de los seis aspectos primarios inspeccionada. No se certifica aún la composición completa dentro del mundo.
