# Thaumcraft NeoForge 26.2 — fix47

Gafas equipables, receta original, reparación y descuento de vis en lanzamiento. HUD de revelación todavía pendiente.


## Fix47: gafas equipables y descuento de lanzamiento

Goggles deja de ser un objeto genérico: equipamiento de cabeza nativo con armadura1, dureza1, durabilidad350, encantabilidad25 y reparación con lingote de latón, conforme ItemGoggles/ARMORMAT_SPECIAL. Usa un asset moderno de equipo con la textura heredada copiada sin alterar a la ruta humanoid. Receta original UNLOCKARTIFICE: 50 vis, sin cristales, cuero4/latón2/taumómetros2.

Nueva interfaz VisDiscountGear para equipo: el lanzamiento Toque/Fuego suma descuentos de las cuatro ranuras de armadura y aplica el límite mínimo original del10% de consumo. Por ahora el único implementado es Goggles5%; no incluye todavía baubles/otros equipos ni VisExhaust, descuento de banco arcano, HUD de aura/popup de aspectos o soporte de gafas en cascos. No considerar gafas totalmente completas.

La prueba del mismo jugador que abre artificio fabrica las gafas con recursos suministrados, verifica costes/consumo, ranura HEAD, durabilidad y reparación latón; una prueba separada verifica que llevar gafas en inventario no descuenta y equiparlas reduce el lanzamiento real mínimo de0,8 a0,76 vis. Diez pruebas pasan (`goggles-full-server.log`). Textura vestida aún requiere comprobación visual en jugador conectado. Se mantienen límites de obtención natural y sesión manual del recorrido temprano.
