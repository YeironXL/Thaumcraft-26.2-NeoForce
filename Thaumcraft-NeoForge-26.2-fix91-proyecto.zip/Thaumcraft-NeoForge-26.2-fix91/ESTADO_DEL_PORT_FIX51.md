# Thaumcraft NeoForge 26.2 — fix51

Tipografía estilizada de libro: Alegreya Regular, serif, aplicada al contenido del Thaumonomicon, títulos y etiquetas de las cuatro estaciones y botones temáticos. Peso normal sin sombras. Fuente propia del mod; no reemplaza la fuente global de Minecraft. Recurso TTF sobremuestreado a 4x, con referencia de respaldo a la fuente base para símbolos no disponibles.

La fuente original se distribuye sin modificar con su licencia SIL Open Font License 1.1 en assets/thaumcraft/font/ofl-alegreya.txt. Procedencia: https://github.com/google/fonts/tree/main/ofl/alegreya . El archivo de Google Fonts es variable; el proveedor nativo usa su peso predeterminado regular.

Hereda las mecánicas y límites de fix50. Esta entrega solo cambia tipografía. Comprobación: cliente nativo con seis capturas y compilación de producción; últimas diez pruebas de mecánicas del servidor: fix49.
