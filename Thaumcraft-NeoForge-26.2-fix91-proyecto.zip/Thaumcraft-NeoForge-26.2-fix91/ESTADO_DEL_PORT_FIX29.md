# Thaumcraft NeoForge 26.2 — fix29

Alumentum como combustible nativo y Thaumonomicon inicial.

- Cada jugador recibe un Thaumonomicon en el inventario al ingresar por primera vez con esta versión, también en multijugador.
- Una marca persistente, conservada al morir, evita repetir la entrega. Los jugadores que ya tienen el libro o su descubrimiento no reciben otro.
- Los jugadores de mundos anteriores sin libro ni descubrimiento también reciben esta entrega inicial al actualizar.
- Si el inventario está lleno, se reintenta en el siguiente ingreso con espacio. No se desbloquean las investigaciones avanzadas.
- GameTest verifica entrega inicial, reconexión sin duplicados, persistencia de la marca, propietario anterior e inventario lleno.

- Se registra como combustible de 4.800 ticks, el valor de CraftingEvents.java de TC6 BETA26.
- Funciona en hornos normales y consumidores nativos que consultan el tiempo de combustión del objeto.
- El horno alquímico usa ahora ese mismo valor; se elimina su excepción incorrecta de 3.200 ticks.
- GameTest comprueba la duración y funde mineral de hierro con Alumentum en un horno vanilla real. También se ejecutan las pruebas previas de tubos y centrífuga.
- Build de producción y regresiones de migración. No hay cambios visuales; no se repite la prueba de cliente ni se presentan capturas nuevas.

El lanzamiento explosivo del Alumentum sigue pendiente. Por eso el objeto completo continúa marcado como parcial en la lista de contenido, aunque su función de combustible ya está implementada.
