# Estado del port — fix54

## Cambios

- Thaumonomicon con mapa de investigación: posiciones e iconos del catálogo original, marcos de nodos, conexiones, categorías y búsqueda.
- Fondos JPG originales decodificados para la API gráfica moderna; los recursos originales permanecen intactos.
- Desplazamiento con arrastre, rueda y flechas; botón para volver al inicio de la categoría.
- Lectura en doble página con pergamino original, fuente serif aprobada, paginación y vuelta al mapa.
- El servidor conserva la autoridad sobre requisitos, etapas, costes y desbloqueos; abrir un nodo no concede investigación.

## Verificación

- Compilación de Java y comprobaciones del cliente.
- Diez pruebas de integración requeridas del servidor aprobadas.
- Capturas del mapa, lectura y cinco pantallas de estaciones conservadas junto a la entrega.

## Pendiente

Este mapa adapta la presentación del original, pero no certifica paridad visual total. Quedan enlaces y animaciones originales avanzados, páginas ilustradas de recetas, cartas verticales, traducción de textos heredados y comprobación manual del recorrido con un jugador conectado. Las demás limitaciones funcionales del port continúan documentadas en la lista de contenido.
