# Estado del port — fix59

El mapa de investigaciones usa el renderizador nativo de objetos también en vistas sin mundo. Se elimina una restricción innecesaria que sustituía los modelos por una textura plana o una interrogación en la comprobación desde el menú principal.

La comprobación gráfica proporciona componentes de objetos de prueba antes de abrir el libro. Estos componentes solo pertenecen al proceso de verificación y no se incluyen en el JAR de producción.

No cambia desbloqueos, costes ni reglas del servidor. No acredita que todos los modelos originales estén portados, ni corrige por sí solo los objetos que puedan verse mal en la mano.

Validación y capturas: consultar los registros de fix59 en outputs/validacion-fix59. La comparación completa dentro del mundo sigue pendiente.

Comprobación gráfica nativa completada con éxito: mapa, categorías, doble página, estaciones y partículas. Captura del mapa de artificio revisada: los nodos visibles recuperan los modelos de los objetos en vez de interrogaciones. Compilación y comprobación de migración aprobadas.

Servidor: las diez pruebas requeridas pasaron al repetir en un universo nuevo. La primera ejecución falló al localizar el objeto soltado por la mesa arcana recién destruida; no se modificó la prueba ni se identificó todavía la causa. Se conserva como incidencia intermitente pendiente de diagnóstico; no debe considerarse resuelta por el segundo resultado.

Seguimiento: se reprodujo un fallo equivalente con un cristal en una de cuatro ejecuciones adicionales. Tras añadir veinte ticks de preparación a early_focus, cuatro universos nuevos pasaron todas las pruebas. Solo se modifica la verificación; véase docs/INCIDENCIA_ENTIDADES_EARLY_GAME.md para resultados y límites.
