# Thaumcraft NeoForge 26.2 — fix40

Corrección de una fuente accesible de Aversio requerida para el primer foco. Mantiene las funciones de fix39 y sus límites.


## Fix40: suministro de Aversio para el primer foco

Se incorpora la adición compleja original de Aversio5 de las flechas (ConfigAspects.java de TC6). Su receta normal aporta Terra1, Instrumentum1, Aer1 y Volatus1 tras escalado por cuatro salidas; Herba del palo no alcanza el redondeo mínimo. El mapa activo pasa de 14 a 15 derivados. No se inventan aspectos de armas ni se amplía automáticamente toda la lista.

La prueba del mismo jugador abre BASEALCHEMY por ResearchProgression, ensambla flechas con pedernal/palo/pluma y nueve pepitas de cuarzo por receta cargada, disuelve una flecha en un crisol caliente, cataliza una pepita y recoge el cristal físico de Aversio. Se cobran dos Aversio y 50 mB y quedan tres Aversio. Ese cristal entra en su inventario y se consume después al preparar su primer foco; se elimina la fixture de Aversio para esa preparación. Siguen suministrados Ignis, materias primas, agua/calor, aura y XP, así como los aspectos de fabricación del foco vacío. No es aún prueba de abastecimiento natural completo ni sesión conectada.

Validación fix40: las diez pruebas requeridas pasan (`server-verification-fix40.log`), incluido el uso del cristal producido en el foco continuo; compilación de producción correcta (`build-verification-fix40.log`).
