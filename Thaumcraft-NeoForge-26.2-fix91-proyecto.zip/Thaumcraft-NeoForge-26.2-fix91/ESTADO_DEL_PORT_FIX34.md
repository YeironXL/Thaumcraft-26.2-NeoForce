# Thaumcraft NeoForge 26.2 — fix34

Mesa de investigación funcional, con las nueve cartas básicas de TC6.

- Mesa de madera: tres losas y dos tablones. Tintero: botella o frasco vacío, pluma y tinta negra. Recarga del tintero gastado sin perder sus componentes.
- Usar el tintero sobre una mesa de madera crea la mesa de investigación, orientada hacia el jugador, mueve el tintero y registra la fabricación para THEORYRESEARCH.
- Inventario nativo con dos ranuras, traslado rápido y pantalla en español. Inspiración inicial calculada con las investigaciones completadas.
- Cada extracción cobra un papel; cada carta elegida consume un uso de tinta. El tintero agotado permanece para recargarlo.
- Experimentación, Analizar, Reflexionar, Inspiración, Replantear, Descartar, Equilibrar, Estudiar y Anotar: costes y efectos básicos portados. La biblioteca próxima cuesta una inspiración y aporta su reserva ponderada de cartas.
- Porcentajes por categoría, categorías bloqueadas, extracciones adicionales y penalización final. Los porcentajes se convierten en conocimiento de teoría con la escala original de 32 unidades.
- La sesión y las cartas ya extraídas se guardan. Las acciones obsoletas se rechazan; otra persona no puede modificar o cobrar la sesión. La reclamación elimina la sesión para evitar cobros duplicados.
- Ocho pruebas de servidor, incluyendo 100 sesiones con semillas distintas y persistencia tras cada extracción. Se conserva la validación de las máquinas de versiones anteriores.

Pendiente: cartas específicas de alquimia y auromancia, sus ayudas, las demás cartas/ayudas del juego completo, configuración y lanzamiento del primer foco, aspectos derivados y prueba integral con jugador nuevo. No se declara cerrado el early game.
