# Thaumcraft NeoForge 26.2 — fix30

Alumentum lanzable como explosivo.

- Uso con cualquiera de las manos: consume una unidad en supervivencia, conserva el objeto en creativo y crea un único proyectil en el servidor.
- Conserva el propietario, el sonido de lanzamiento, la inclinación inicial de -5°, velocidad base de 0,75 y dispersión de 2 del original.
- Explota al impactar contra bloques o entidades, con potencia 1,1 y sin prender fuego. Destruye terreno mediante las reglas modernas de explosiones TNT y atribuye el daño a su lanzador.
- El proyectil muestra el objeto Alumentum y una estela de humo/llamas nativas. Las partículas adaptadas no reproducen exactamente el sistema FX antiguo.
- Mantiene el combustible de 4.800 ticks y la entrega inicial única del Thaumonomicon de fix29.
- GameTest de lanzamiento, consumo en supervivencia/creativo, propietario, velocidad, colisión con vidrio y daño a una criatura; también pruebas anteriores de progresión, tubos y centrífuga.
- Prueba de cliente: registro del renderer, carga de recursos, modelos existentes e interfaces. No sustituye una revisión visual manual del proyectil en partida.
- Compilación de producción y regresiones de migración.

La lista de contenido marca Alumentum y su proyectil en verde dentro de este alcance. El resto del port conserva las limitaciones anotadas en la lista y el plan de trabajo.
