# Fix79 — mapa original y Taumómetro

Mapa: pantalla completa, margen16, bordes originales en teselas y categorías a la izquierda. Eliminadas barra Fundamentals, título superpuesto y botones Center/Done. Búsqueda con icono original. Nodos: brillo pulsante600ms y bloqueo0.3; retiradas marcas y borde dorado añadidos. Control Complete del libro usa el atlas original y se oculta en investigaciones completas.

Taumómetro: modelo scanner.obj con cuerpo y cristal; rareza UNCOMMON, alcance de entidades9 bloques, sonido original privado para el jugador, sin chat de depuración. Actualización de aura cada20 ticks mientras se sostiene en una mano, desde el chunk cargado del servidor. Indicador de vis/flux/base con atlas hud.png, escala525 y valores al agacharse. Descubrimiento FLUX cuando flux supera vis o base/3. Limpieza del estado del HUD al desconectar.

Validación: compilación de producción aprobada; diez tests requeridos del servidor aprobados. Prueba de cliente aprobada; captura final del mapa inspeccionada con búsqueda texturizada y bordes/categorías originales. Modelo OBJ inspeccionado en vista GUI; comprobación de ambas manos pendiente. Los tests existentes comprueban progresión y escaneo real; no certifican por sí solos todos los objetivos especiales, HUD ni modelos en ambas manos.

Pendiente: runas originales y resaltado; aspectos sobre objetivo en el mundo; escaneo de inventarios y desencadenantes especiales; animación/brillo aditivo del HUD; comparación de transformaciones OBJ en ambas manos/tercera persona. Las demás interfaces conservan pendientes documentados. No se afirma100% ni identidad total.
