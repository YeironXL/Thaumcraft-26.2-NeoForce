# Estado del port — fix38

Aspectos iniciales ampliados: 23 registros base del original para las seis familias históricas de madera (troncos y bloques de madera), arena/arena roja y nueve materiales de inicio. Estos registros son comunes al horno, crisol y taumómetro.

Se activan catorce conjuntos derivados: seis tablones, papel, mesa de fabricación, estantería, antorcha, palo, pepitas de hierro y oro, y mesa arcana. La derivación usa las recetas cargadas, descuenta recipientes devueltos, aplica 75 % por unidades producidas y selecciona la receta positiva más barata. Se respetan las adiciones originales Cognitio2 del papel, Fabrico20 de la mesa, Cognitio8 de la estantería y Lux5 de la antorcha. La mesa arcana copia los aspectos de la mesa y añade Praecantatio5/Auram5.

El mapa derivado se reemplaza de forma atómica e inmutable al entrar o recargar datos, y se envía mediante un payload al cliente. Se limpia al cerrar servidor o desconectar. Los aspectos explícitos siguen separados y conservan prioridad.

Verificación de servidor: diez pruebas superadas, incluyendo recetas reales, ciclos, adiciones/copias, codec de sincronización, limpieza y destilación real. Una mesa arcana completa 78 ticks de horno básico y produce Auram; sus 39 aspectos se conservan entre essentia almacenada y flux perdido. El payload se comprobó mediante roundtrip de red y se registran los handlers del cliente; esto no sustituye una prueba de conexión real a servidor dedicado.

Pendiente: cobertura del resto de recetas y etiquetas originales, adaptadores arcanos/especiales y cristales por componente; comprobación integral desde jugador nuevo, conexión real y recarga en un cliente conectado. Siguen pendientes descuentos de equipo/agotamiento del guantelete y los demás grafos de focos. El early game no se considera cerrado y no se afirma paridad con el original.
