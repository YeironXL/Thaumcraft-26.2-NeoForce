# Thaumcraft NeoForge 26.2 — fix53

Revisión artística y auditoría de recursos de TC6 1.12.2–6.1.BETA26.

La mesa arcana recupera el atlas verde y madera original, su rejilla espaciada de 24 píxeles, salida y distribución circular original de cristales. El orden interno de ranuras del port se conserva: las posiciones se asignan por aspecto para no intercambiar aire, tierra, fuego, agua, orden y entropía. Costes y disponibilidad de vis siguen visibles, con detalle en tooltip.

El horno alquímico recupera su atlas compacto y posiciones originales de entrada, combustible e inventario. Llama de combustible y columnas de progreso/reserva usan los recortes originales. Los indicadores muestran valores actuales sincronizados, con tooltip de cantidad, tiempo, progreso y eficiencia.

La mesa de investigación usa madera original y papel en requisitos de las cartas; el manipulador usa el metal original. El inventario usa gui_base original. Estos dos diseños son adaptaciones a las funciones actuales del port, no reproducciones completas de los editores originales. Se mantiene la tipografía serif solicitada; el TC6 original usa fuente de Minecraft.

Auditoría completa de los recursos disponibles PNG/JPG/OBJ/MTL/OGG/JSON: 1422 archivos originales; 501 conservados en ruta, 524 reubicados con bytes idénticos, 397 modificados (principalmente JSON migrados). Las 774 imágenes, 27 OBJ y 111 sonidos tienen copias idénticas en el port. Los colores de los 37 aspectos coinciden. No hay recursos de ese inventario sin copia o versión migrada. Esto NO acredita uso en juego ni equivalencia de renderizado.

Pendiente de fidelidad: árbol del Thaumonomicon, grafo completo de focos, animaciones de cartas, renderizadores especiales de bloques y armaduras, criaturas/gólems, efectos mágicos, aura/HUD y shaders. Solo Alumentum tiene renderer de entidad registrado en el cliente actual. Lista detallada y 144 clases visuales originales inventariadas en docs/AUDITORIA_VISUAL_TC6.{md,json}.

Verificación de entrega: capturas de las seis vistas nativas revisadas; pruebas de servidor y compilación de producción. No se ha hecho una prueba manual conectada de todos los modelos del mundo.
