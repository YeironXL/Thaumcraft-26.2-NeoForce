# Thaumcraft NeoForge 26.2 — fix35

Investigación especializada y requisitos del primer foco de TC6 6.1.BETA26.

- Se añaden seis cartas: Concentrar, Reacciones, Síntesis, Concentración, Conciencia y Encantamiento. Junto a fix34 hay quince de las treinta y cinco cartas del original con mecánica portadas.
- Concentrar y Reacciones requieren los cristales correctos, sin consumirlos. Síntesis consume sus dos componentes y entrega el compuesto; si el inventario está lleno lo deja en el mundo.
- Costes atómicos por aspecto y cantidad: ningún material se retira cuando falta otra parte. Las cartas alquímicas conservan su probabilidad del 33 % de recuperar inspiración.
- Concentración añade progreso y extracción adicional; Conciencia puede añadir conocimiento arcano y una distorsión normal; Encantamiento consume hasta cinco niveles, a cambio de cinco puntos porcentuales por nivel.
- Ayudas próximas seleccionables: biblioteca, crisol y manipulador. Cada ayuda elegida cuesta una inspiración y conserva la reserva de cartas y los pesos originales. Las categorías de las cartas normales respetan sus desbloqueos.
- Las nuevas condiciones de cristal se guardan y se sincronizan con el menú. Se mantienen las sesiones guardadas por fix34. La interfaz muestra los costes y efectos en español.
- Recetas originales de piedra arcana, ladrillos, ambas losas, mesa de piedra y manipulador. La piedra admite las siete variantes modernas correspondientes a los metadatos originales; la mesa usa la losa de piedra lisa que corresponde a la losa antigua.
- Receta del foco vacío: cristal de Ordo, 20 Vitreus, 10 Praecantatio y 5 Auram. El catalizador comprueba su componente de aspecto, también después de sincronizar la receta por red.
- Descubrimiento de fuego al recibir ese tipo de daño en la segunda etapa de BASEAUROMANCY. Se puede completar el capítulo original después de fabricar el manipulador pagando 100 vis, un cristal de Terra y otro de Aqua.
- Foco básico y guantelete no se apilan. Ambos continúan pendientes de la configuración y lanzamiento de hechizos.

Validación: diez pruebas de servidor superadas, incluidas las cartas específicas, costes y probabilidades, inventario lleno, compatibilidad de sesión fix34 y el recorrido original BASEAUROMANCY. Prueba de cliente para cartas, textos de cristales, selección de ayudas y modelos/pantallas previos. Compilación de producción y regresiones de migración.

Pendiente para cerrar el alcance acordado del early game: configuración del foco y lanzamiento real con el guantelete, completar aspectos de objetos derivados de recetas y comprobación integral desde un jugador nuevo. Las otras veinte cartas, ayudas posteriores y demás sistemas avanzados siguen fuera de este bloque. No se declara completo el early game.
