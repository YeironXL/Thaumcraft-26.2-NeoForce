# Estado del port — fix77

Ingredientes por etiquetas del registro del cliente para recetas de cuadrícula del Thaumonomicon. Rotación cada segundo con desplazamiento por ranura, como InventoryUtils.cycleItemStack del original. Usa las etiquetas recibidas del servidor, sin inventar variantes ni mantener un catálogo alternativo. Etiquetas vacías o sin cargar omiten la página hasta que sus ingredientes puedan resolverse.

Producción compilada. Prueba de cliente aprobada: recarga real de etiquetas del registro con fixture roble/abeto, ciclo y vuelta cada segundo, etiqueta inexistente rechazada y receta tablewood resuelta. Captura final inspeccionada. Regresiones de lectura y recetas previas aprobadas. No se repitieron pruebas de servidor: el cambio es exclusivamente de consulta del cliente.

Cerrado el cambio que estaba en curso al recibir hola. Automatización pausada. El nuevo pedido de interfaces1:1 requiere una revisión posterior; fix77 todavía conserva las composiciones adaptadas previas.
