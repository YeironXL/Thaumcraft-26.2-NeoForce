# Estado del port — fix60

El mapa del Thaumonomicon recupera los tramos y esquinas curvas originales del atlas gui_research_browser, con flechas y orientación REVERSE, siguiendo GuiResearchBrowser.drawLine de TC6 BETA26. Sustituye las líneas diagonales simples. El recorte del mapa mantiene las conexiones dentro del panel.

Se conserva la fuente serif aprobada. El cambio no altera investigaciones, desbloqueos, costes ni progreso del servidor. Enlaces entre hermanos, animaciones, marcadores de novedades y recetas ilustradas siguen pendientes.

Se documentaron tres fotogramas realmente revisados de la guía de infusión: 07:35, 11:22 y 18:57. No se afirma haber visto el episodio entero ni completado el sistema de infusión.

La prueba inicial incluye la preparación de veinte ticks incorporada tras la incidencia de fix59; su estabilidad observada no confirma definitivamente la causa del fallo intermitente.

Revisión gráfica nativa aprobada: capturas de Fundamentos y Artificio inspeccionadas, con flechas, esquinas y límites del panel. Compilación de producción y comprobaciones de migración aprobadas.

Servidor: las diez pruebas requeridas pasaron en un universo nuevo, incluida la ruta inicial con preparación de veinte ticks. Registros conservados en outputs/validacion-fix60.
